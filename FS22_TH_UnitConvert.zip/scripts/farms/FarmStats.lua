-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THFarmStats = {}
function THFarmStats:initialize()
local farmStats = self:getParent()
self.currentUnit = {}
self.maxNumUnits = {}
for _, unitSetIndex in pairs(g_thMain.UNIT_SET) do
self.currentUnit[unitSetIndex] = 0
self.maxNumUnits[unitSetIndex] = 0
end
self.statistics = {
byId      = {},
byIndex   = {},
idToIndex = {}
}
self.STAT = self.statistics.idToIndex
table.insert(self.statistics.byIndex, {name = "fuelUsage"})
table.insert(self.statistics.byIndex, {name = "seedUsage"})
table.insert(self.statistics.byIndex, {name = "sprayUsage"})
local fillTypeList = g_thUtils:getFillTypeList()
local sprayTypeList = g_sprayTypeManager:getSprayTypes()
for idx, statInfo in pairs(self.statistics.byIndex) do
local statId = statInfo.name:upper()
if statId == "FUELUSAGE" or statId == "SEEDUSAGE" or statId == "SPRAYUSAGE" then
statInfo.id = statId
statInfo.index = idx
statInfo.values = farmStats.statistics[statInfo.name]
statInfo.currentUnit = {}
statInfo.maxNumUnits = {}
statInfo.validFillTypes = {}
statInfo.numValidFillTypes = 0
self.statistics.byId[statId] = statInfo
self.statistics.idToIndex[statId] = statInfo.index
if statId == "FUELUSAGE" then
if not statInfo.validFillTypes[FillType.DIESEL] then
statInfo.validFillTypes[FillType.DIESEL] = true
statInfo.numValidFillTypes = statInfo.numValidFillTypes + 1
end
elseif statId == "SEEDUSAGE" then
for _, fillTypeInfo in pairs(fillTypeList) do
local fillTypeId = fillTypeInfo.name:upper()
if fillTypeId == "SEEDS" or fillTypeId:find("^SEED_") then
if not statInfo.validFillTypes[fillTypeInfo.index] then
statInfo.validFillTypes[fillTypeInfo.index] = true
statInfo.numValidFillTypes = statInfo.numValidFillTypes + 1
end
end
end
elseif statId == "SPRAYUSAGE" then
for _, sprayTypeInfo in pairs(sprayTypeList) do
local fillTypeInfo = sprayTypeInfo.fillType
if type(fillTypeInfo) == "table" then
local fillTypeIndex = fillTypeInfo.index
if type(fillTypeIndex) == "number" and fillTypeIndex ~= FillType.UNKNOWN then
if not statInfo.validFillTypes[fillTypeIndex] then
statInfo.validFillTypes[fillTypeIndex] = true
statInfo.numValidFillTypes = statInfo.numValidFillTypes + 1
end
end
end
end
end
for _, unitSetIndex in pairs(g_thMain.UNIT_SET) do
local statMaxNumUnits = g_thMain:getFillTypeMaxNumUnits(statInfo.validFillTypes, unitSetIndex, nil, true)
local statCurrentUnit = 0
if statMaxNumUnits > 0 then
statCurrentUnit = 1
end
statInfo.currentUnit[unitSetIndex] = statCurrentUnit
statInfo.maxNumUnits[unitSetIndex] = statMaxNumUnits
self.maxNumUnits[unitSetIndex] = math.max(self.maxNumUnits[unitSetIndex], statInfo.maxNumUnits[unitSetIndex])
if self.maxNumUnits[unitSetIndex] > 0 then
self.currentUnit[unitSetIndex] = 1
end
end
end
end
return true
end
function THFarmStats:getStatistic(statistic, verbose, raise)
return g_thUtils:getTargetInfo(self, "statistics", statistic, verbose, raise)
end
function THFarmStats:getStatisticList(byId)
if byId == true then
return self.statistics.byId
end
return self.statistics.byIndex
end
function THFarmStats:getValidFillTypes(statistic)
local statInfo = self:getStatistic(statistic, true)
if statInfo ~= nil then
return statInfo.validFillTypes, statInfo.numValidFillTypes
end
return {}, 0
end
function THFarmStats:getUnitSelectionValues(unitSet, statistic)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local target = self
if statistic ~= nil then
target = self:getStatistic(statistic, true)
if target == nil then
return 0,0
end
end
local currentUnit = target.currentUnit[unitSetIndex]
local maxNumUnits = target.maxNumUnits[unitSetIndex]
return currentUnit, maxNumUnits
end
function THFarmStats:setCurrentUnit(value, unitSet, statistic)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local target = self
if statistic ~= nil then
target = self:getStatistic(statistic, true)
if target == nil then
return 0
end
end
local currentUnit = target.currentUnit[unitSetIndex]
local maxNumUnits = target.maxNumUnits[unitSetIndex]
if g_thUtils:argIsValid(type(value) == "number", "value", value) then
value = math.floor(math.max(0, value))
if maxNumUnits > 0 then
if value <= 0 or value > maxNumUnits then
value = 1
end
else
value = 0
end
target.currentUnit[unitSetIndex] = value
return value
end
return currentUnit
end
function THFarmStats.hook_new(superFunc, ...)
local function appendFunc(newEnv, ...)
local protectedChunk = function()
if newEnv ~= nil then
g_thMain:createDataTable(newEnv, true, THFarmStats)
end
end
g_thMain:call(protectedChunk)
return newEnv, ...
end
return appendFunc(superFunc(...))
end
function THFarmStats:hook_addStatistic(superFunc, name, unit, valueSession, valueTotal, stringFormat, ...)
local envData = g_thMain:call("getDataTable", self)
local function prependFunc()
local statInfo = envData:getStatistic(name)
if statInfo ~= nil then
local validFillTypes, numValidFillTypes = envData:getValidFillTypes(statInfo)
if numValidFillTypes > 0 then
local currentUnit, maxNumUnits = envData:getUnitSelectionValues()
local unitInfo, unitFactor, unitPrecision = g_thMain:getFillTypeUnitData(validFillTypes, currentUnit, maxNumUnits)
if unitInfo ~= nil then
unit = unitInfo.titleShort
if tonumber(valueSession) ~= nil then
valueSession = MathUtil.round(valueSession * unitFactor, unitPrecision)
end
if tonumber(valueTotal) ~= nil then
valueTotal = MathUtil.round(valueTotal * unitFactor, unitPrecision)
end
end
end
end
end
g_thMain:call(prependFunc)
return superFunc(self, name, unit, valueSession, valueTotal, stringFormat, ...)
end
local function runScript()
g_thMain:setProtectedHook("FarmStats", "new",          THFarmStats, nil, false)
g_thMain:setProtectedHook("FarmStats", "addStatistic", THFarmStats)
end
g_thMain:call(runScript)