-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THFillLevelsDisplay = {}
function THFillLevelsDisplay:initialize()
local display = self:getParent()
self.fillTypeTextSize = 0
self.actionEventIds = {}
self.lastVehicle = nil
self.maxNumUnits = {}
self.validFillTypes = {}
self.numValidFillTypes = 0
self.vehicleIsEmpty = true
for _, unitSetIndex in pairs(g_thMain.UNIT_SET) do
self.maxNumUnits[unitSetIndex] = 0
end
g_thMain:setProtectedHook(display, "updateFillLevelFrames", THFillLevelsDisplay)
g_thMain:setProtectedHook(display, "storeScaledValues",     THFillLevelsDisplay)
g_thMain:setProtectedHook(display, "draw",                  THFillLevelsDisplay)
display:storeScaledValues()
return true
end
function THFillLevelsDisplay:deleteDataTable()
self:restoreDefaultValue("updateFillLevelFrames")
self:restoreDefaultValue("storeScaledValues")
self:restoreDefaultValue("draw")
return true
end
function THFillLevelsDisplay:getValidFillTypes()
return self.validFillTypes, self.numValidFillTypes
end
function THFillLevelsDisplay:updateUnitSelectionValues(unitSet)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local fillTypeList, numValidFillTypes = self:getValidFillTypes()
local currentUnit, _, vehicleData = self:getUnitSelectionValues(unitSetIndex)
local maxNumUnits = 0
if numValidFillTypes > 0 then
maxNumUnits = g_thMain:getFillTypeMaxNumUnits(fillTypeList, unitSetIndex)
end
if vehicleData ~= nil then
if maxNumUnits > 0 then
if currentUnit == 0 or currentUnit > maxNumUnits then
currentUnit = 1
end
else
currentUnit = 0
end
vehicleData:setCurrentUnit(currentUnit, unitSetIndex)
end
self.maxNumUnits[unitSetIndex] = maxNumUnits
return currentUnit, maxNumUnits, vehicleData
end
function THFillLevelsDisplay:getUnitSelectionValues(unitSet)
local display = self:getParent()
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local vehicleData = g_thMain:getDataTable(display.vehicle)
local currentUnit = 0
local maxNumUnits = self.maxNumUnits[unitSetIndex]
if vehicleData ~= nil then
currentUnit = vehicleData:getUnitSelectionValues(unitSetIndex)
end
return currentUnit, maxNumUnits, vehicleData
end
function THFillLevelsDisplay:registerActionEvents()
if g_thMain.isClient then
self:unregisterActionEvents()
local contextName = Vehicle.INPUT_CONTEXT_NAME
local actionEventIds = self.actionEventIds
g_inputBinding:beginActionEventsModification(contextName)
local _, eventId = g_inputBinding:registerActionEvent(InputAction.UC_SELECT_UNIT, self, self.onActionSelectUnit, false, true, false, true)
g_inputBinding:setActionEventText(eventId, g_i18n:getText("ucAction_selectUnit"))
g_inputBinding:setActionEventTextPriority(eventId, GS_PRIO_VERY_LOW)
actionEventIds.selectUnit = eventId
g_inputBinding:endActionEventsModification()
end
end
function THFillLevelsDisplay:unregisterActionEvents()
if g_thMain.isClient then
for _, eventId in pairs(self.actionEventIds) do
g_inputBinding:removeActionEvent(eventId)
end
g_thUtils:clearTable(self.actionEventIds)
end
end
function THFillLevelsDisplay:updateActionEvents()
local display = self:getParent()
if g_thMain.isClient then
local vehicle = display.vehicle
local actionEventIds = self.actionEventIds
local selectUnitIsActive = false
if display:getVisible() and vehicle ~= nil and vehicle.getIsActiveForInput ~= nil then
if vehicle:getIsActiveForInput(true, true) then
local _, maxNumUnits = self:getUnitSelectionValues()
if not self.vehicleIsEmpty and maxNumUnits > 1 then
selectUnitIsActive = true
end
end
end
if actionEventIds.selectUnit ~= nil then
g_inputBinding:setActionEventActive(actionEventIds.selectUnit, selectUnitIsActive)
g_inputBinding:setActionEventTextVisibility(actionEventIds.selectUnit, selectUnitIsActive)
end
end
end
function THFillLevelsDisplay:onActionSelectUnit()
local function protectedFunc()
local currentUnit, maxNumUnits, vehicleData = self:getUnitSelectionValues()
if vehicleData ~= nil then
if maxNumUnits > 0 then
currentUnit = math.max(currentUnit, 1) + 1
if currentUnit > maxNumUnits then
currentUnit = 1
end
else
currentUnit = 0
end
vehicleData:setCurrentUnit(currentUnit)
end
end
g_thMain:call(protectedFunc)
end
function THFillLevelsDisplay:hook_update(superFunc, dt, ...)
local envData = g_thMain:call("getDataTable", self, true, THFillLevelsDisplay)
local function prependFunc()
if envData ~= nil then
if self.vehicle ~= envData.lastVehicle then
if self.vehicle == nil then
envData:unregisterActionEvents()
else
envData:registerActionEvents()
end
envData.lastVehicle = self.vehicle
end
end
end
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
envData:updateActionEvents()
end
end
g_thMain:call(protectedChunk)
return ...
end
g_thMain:call(prependFunc)
return appendFunc(superFunc(self, dt, ...))
end
function THFillLevelsDisplay:hook_updateFillLevelFrames(superFunc, ...)
local envData = g_thMain:call("getDataTable", self)
local changedFillTypes = {}
local function prependFunc()
if envData ~= nil then
local fillLevelBuffer = self.fillLevelBuffer
local validFillTypes = g_thUtils:clearTable(envData.validFillTypes)
local numFillTypes = 0
for _, bufferInfo in pairs(fillLevelBuffer) do
local fillType  = bufferInfo.fillType
local fillLevel = g_thUtils:getNoNil(bufferInfo.fillLevel, 0)
local capacity  = g_thUtils:getNoNil(bufferInfo.capacity, 0)
if fillType ~= nil and (fillLevel > 0 or capacity > 0) then
if validFillTypes[fillType] == nil then
validFillTypes[fillType] = true
numFillTypes = numFillTypes + 1
end
end
end
envData.vehicleIsEmpty = numFillTypes == 0 or (numFillTypes == 1 and validFillTypes[FillType.UNKNOWN] == true)
envData.numValidFillTypes = numFillTypes
if not envData.vehicleIsEmpty then
for _, bufferInfo in pairs(fillLevelBuffer) do
local fillTypeInfo, fillTypeData = g_thMain:getFillType(bufferInfo.fillType)
local fillLevel = bufferInfo.fillLevel
local capacity  = bufferInfo.capacity
if fillTypeData ~= nil and fillTypeInfo.index ~= FillType.UNKNOWN then
local currentUnit, maxNumUnits = envData:updateUnitSelectionValues()
if maxNumUnits > 0 then
local unitInfo, unitFactor, unitPrecision = g_thMain:getFillTypeUnitData(fillTypeInfo, currentUnit, maxNumUnits)
if unitInfo ~= nil and (fillLevel ~= nil or capacity ~= nil) then
if fillLevel ~= nil and fillLevel > 0 then
bufferInfo.fillLevel = MathUtil.round(fillLevel * unitFactor, unitPrecision)
end
if capacity ~= nil and capacity > 0 then
bufferInfo.capacity = MathUtil.round(capacity * unitFactor, unitPrecision)
end
bufferInfo.precision = unitPrecision
fillTypeInfo.unitShort = " "..unitInfo.titleShort
changedFillTypes[fillTypeInfo] = fillTypeData
end
end
end
end
end
end
end
g_thMain:call(prependFunc)
local function appendFunc(...)
for _, fillTypeData in pairs(changedFillTypes) do
fillTypeData:restoreDefaultValue("unitShort")
end
return ...
end
return appendFunc(superFunc(self, ...))
end
function THFillLevelsDisplay:hook_storeScaledValues(superFunc, ...)
local envData = g_thMain:call("getDataTable", self)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
local defaultTextSize = HUDElement.TEXT_SIZE.DEFAULT_TEXT
local fillTypeTextSize = defaultTextSize - 3
local fillLevelTextSize = defaultTextSize - 1
local fillTypeTextPosX, fillTypeTextPosY = g_thUtils:unpack(FillLevelsDisplay.POSITION.FILL_TYPE_TEXT)
local fillTypeTextPos = {fillTypeTextPosX, fillTypeTextPosY - 9}
local fillLevelTextPosX, fillLevelTextPosY = g_thUtils:unpack(FillLevelsDisplay.POSITION.FILL_LEVEL_TEXT)
local fillLevelTextPos = {fillLevelTextPosX, fillLevelTextPosY - 2}
envData.fillTypeTextSize = self:scalePixelToScreenHeight(fillTypeTextSize)
self.fillLevelTextSize = self:scalePixelToScreenHeight(fillLevelTextSize)
self.fillTypeTextOffsetX, self.fillTypeTextOffsetY = self:scalePixelToScreenVector(fillTypeTextPos)
self.fillLevelTextOffsetX, self.fillLevelTextOffsetY = self:scalePixelToScreenVector(fillLevelTextPos)
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
function THFillLevelsDisplay:hook_draw(superFunc, ...)
local envData = g_thMain:call("getDataTable", self)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil and self:getVisible() then
local baseX, baseY = self:getPosition()
local width = self:getWidth()
for idx = 1, #self.fillLevelTextBuffer do
local fillTypeText = self.fillTypeTextBuffer[idx]
if fillTypeText ~= nil then
local posX = baseX + width + self.fillTypeTextOffsetX
local posY = baseY + (idx - 1) * (self.frameHeight + self.frameOffsetY)
if idx == 1 then
posX = posX + self.firstFillTypeOffset
end
setTextColor(g_thUtils:unpack(FillLevelsDisplay.COLOR.FILL_LEVEL_TEXT))
setTextBold(false)
setTextAlignment(RenderText.ALIGN_RIGHT)
renderText(posX, posY + self.fillTypeTextOffsetY, envData.fillTypeTextSize, fillTypeText)
end
end
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
local function runScript()
g_thMain:setProtectedHook("FillLevelsDisplay", "update", THFillLevelsDisplay)
end
g_thMain:call(runScript)