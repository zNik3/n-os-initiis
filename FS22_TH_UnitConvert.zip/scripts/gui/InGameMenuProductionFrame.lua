-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THInGameMenuProductionFrame = {}
function THInGameMenuProductionFrame:initialize()
self.actionEventIds = {}
return true
end
function THInGameMenuProductionFrame:getUnitSelectionValues(unitSet)
local productionFrame = self:getParent()
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local prodPointData = g_thMain:getDataTable(productionFrame.selectedProductionPoint)
local currentUnit = 0
local maxNumUnits = 0
if prodPointData ~= nil then
currentUnit, maxNumUnits = prodPointData:getUnitSelectionValues(unitSetIndex)
end
return currentUnit, maxNumUnits, prodPointData
end
function THInGameMenuProductionFrame:registerActionEvents()
if g_thMain.isClient then
self:unregisterActionEvents()
local contextName = Gui.INPUT_CONTEXT_MENU
local actionEventIds = self.actionEventIds
g_inputBinding:beginActionEventsModification(contextName)
local _, eventId = g_inputBinding:registerActionEvent(InputAction.UC_SELECT_UNIT, self, self.onActionSelectUnit, false, true, false, true)
g_inputBinding:setActionEventTextVisibility(eventId, false)
g_inputBinding:setActionEventTextPriority(eventId, GS_PRIO_VERY_LOW)
actionEventIds.selectUnit = eventId
g_inputBinding:endActionEventsModification()
end
end
function THInGameMenuProductionFrame:unregisterActionEvents()
if g_thMain.isClient then
for _, eventId in pairs(self.actionEventIds) do
g_inputBinding:removeActionEvent(eventId)
end
g_thUtils:clearTable(self.actionEventIds)
end
end
function THInGameMenuProductionFrame:subscribeMessageCenterEvents()
self:unsubscribeMessageCenterEvents()
g_messageCenter:subscribe(MessageType.TH_SETTING_CHANGED.CURRENTUNITSET, self.onUnitSetChanged, self)
end
function THInGameMenuProductionFrame:unsubscribeMessageCenterEvents()
g_messageCenter:unsubscribe(MessageType.TH_SETTING_CHANGED.CURRENTUNITSET, self)
end
function THInGameMenuProductionFrame:onActionSelectUnit()
local function protectedFunc()
local productionFrame = self:getParent()
local currentUnit, maxNumUnits, prodPointData = self:getUnitSelectionValues()
if prodPointData ~= nil then
if maxNumUnits > 0 then
currentUnit = math.max(currentUnit, 1) + 1
if currentUnit > maxNumUnits then
currentUnit = 1
end
else
currentUnit = 0
end
prodPointData:setCurrentUnit(currentUnit)
productionFrame.storageList:reloadData()
end
end
g_thMain:call(protectedFunc)
end
function THInGameMenuProductionFrame:onUnitSetChanged()
local function protectedFunc()
local productionFrame = self:getParent()
productionFrame.storageList:reloadData()
end
g_thMain:call(protectedFunc)
end
function THInGameMenuProductionFrame:hook_onFrameOpen(superFunc, ...)
local envData = g_thMain:call("getDataTable", self, true, THInGameMenuProductionFrame)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
envData:registerActionEvents()
envData:subscribeMessageCenterEvents()
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
function THInGameMenuProductionFrame:hook_onFrameClose(superFunc, ...)
local envData = g_thMain:call("getDataTable", self)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
envData:unregisterActionEvents()
envData:unsubscribeMessageCenterEvents()
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
function THInGameMenuProductionFrame:hook_populateCellForItemInSection(superFunc, list, section, index, cell, ...)
local envData = g_thMain:call("getDataTable", self)
local _ = nil
local fillLevelElement, fillLevelSetTextFunc, oldFillLevelSetTextFunc = nil,nil,nil
local function prependFunc()
if envData ~= nil then
if list ~= self.productionList then
local currentUnit, maxNumUnits, prodPointData = envData:getUnitSelectionValues()
if prodPointData ~= nil then
local prodPoint = prodPointData:getParent()
local fillType = nil
if section == 1 then
fillType = prodPoint.inputFillTypeIdsArray[index]
else
fillType = prodPoint.outputFillTypeIdsArray[index]
end
if fillType ~= nil then
fillLevelElement = cell:getAttribute("fillLevel")
if fillLevelElement ~= nil then
local function hook_fillLevelSetText(pSuperFunc, pSelf, pText, ...)
local function vPrependFunc()
local vFillLevel = g_thUtils:getNumericValues(pText, 1)
if vFillLevel ~= nil then
pText = g_i18n:formatVolume(vFillLevel, 0, nil,nil,nil, fillType, currentUnit, maxNumUnits)
end
end
g_thMain:call(vPrependFunc)
return pSuperFunc(pSelf, pText, ...)
end
_, fillLevelSetTextFunc, oldFillLevelSetTextFunc = g_thUtils:hookFunction(fillLevelElement, "setText", hook_fillLevelSetText)
end
end
end
end
end
end
g_thMain:call(prependFunc)
local function appendFunc(...)
if fillLevelSetTextFunc ~= nil then rawset(fillLevelElement, "setText", oldFillLevelSetTextFunc) end
return ...
end
return appendFunc(superFunc(self, list, section, index, cell, ...))
end
local function runScript()
g_thMain:setProtectedHook("InGameMenuProductionFrame", "onFrameOpen",                  THInGameMenuProductionFrame)
g_thMain:setProtectedHook("InGameMenuProductionFrame", "onFrameClose",                 THInGameMenuProductionFrame)
g_thMain:setProtectedHook("InGameMenuProductionFrame", "populateCellForItemInSection", THInGameMenuProductionFrame)
end
g_thMain:call(runScript)