-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THInGameMenuPricesFrame = {}
function THInGameMenuPricesFrame:initialize()
self.actionEventIds = {}
self.currentUnit = {}
self.maxNumUnits = {}
for _, unitSetIndex in pairs(g_thMain.UNIT_SET) do
self.currentUnit[unitSetIndex] = 0
self.maxNumUnits[unitSetIndex] = 0
end
return true
end
function THInGameMenuPricesFrame:getValidFillTypes()
local pricesFrame = self:getParent()
if pricesFrame.fillTypes ~= nil then
return pricesFrame.fillTypes, #pricesFrame.fillTypes
end
return {}, 0
end
function THInGameMenuPricesFrame:updateUnitSelectionValues(unitSet)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local fillTypeList, numValidFillTypes = self:getValidFillTypes()
local currentUnit = self:getUnitSelectionValues(unitSetIndex)
local maxNumUnits = 0
if numValidFillTypes > 0 then
maxNumUnits = g_thMain:getFillTypeMaxNumUnits(fillTypeList, unitSetIndex)
end
if maxNumUnits > 0 then
if currentUnit == 0 or currentUnit > maxNumUnits then
currentUnit = 1
end
else
currentUnit = 0
end
self.currentUnit[unitSetIndex] = currentUnit
self.maxNumUnits[unitSetIndex] = maxNumUnits
return currentUnit, maxNumUnits
end
function THInGameMenuPricesFrame:getUnitSelectionValues(unitSet)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local currentUnit = self.currentUnit[unitSetIndex]
local maxNumUnits = self.maxNumUnits[unitSetIndex]
return currentUnit, maxNumUnits
end
function THInGameMenuPricesFrame:setCurrentUnit(value, unitSet)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local currentUnit, maxNumUnits = self:getUnitSelectionValues(unitSetIndex)
if g_thUtils:argIsValid(type(value) == "number", "value", value) then
value = math.floor(math.max(0, value))
if maxNumUnits > 0 then
if value <= 0 or value > maxNumUnits then
value = 1
end
else
value = 0
end
self.currentUnit[unitSetIndex] = value
return value
end
return currentUnit
end
function THInGameMenuPricesFrame:convertPriceElement(element, value, fillType, listIndex, maxListIndex)
if element.formatDecimalPlaces ~= 2 then
local elementData = g_thMain:getDataTable(element)
if elementData == nil then
g_thMain:createDataTable(element)
end
element.formatDecimalPlaces = 2
end
local unitInfo, factor = g_thMain:getFillTypeUnitData(fillType, listIndex, maxListIndex)
if unitInfo ~= nil then
if factor ~= 0 then
value = value / factor
else
value = 0
end
end
return value
end
function THInGameMenuPricesFrame:registerActionEvents()
if g_thMain.isClient then
self:unregisterActionEvents()
local contextName = Gui.INPUT_CONTEXT_MENU
local actionEventIds = self.actionEventIds
g_inputBinding:beginActionEventsModification(contextName)
local _, eventId = g_inputBinding:registerActionEvent(InputAction.UC_SELECT_UNIT, self, self.onActionSelectUnit, false, true, false, true)
g_inputBinding:setActionEventTextVisibility(eventId, false)
g_inputBinding:setActionEventTextPriority(eventId, GS_PRIO_VERY_LOW)
actionEventIds.selectUnit = eventId
g_inputBinding:endActionEventsModification()
end
end
function THInGameMenuPricesFrame:unregisterActionEvents()
if g_thMain.isClient then
for _, eventId in pairs(self.actionEventIds) do
g_inputBinding:removeActionEvent(eventId)
end
g_thUtils:clearTable(self.actionEventIds)
end
end
function THInGameMenuPricesFrame:subscribeMessageCenterEvents()
self:unsubscribeMessageCenterEvents()
g_messageCenter:subscribe(MessageType.TH_SETTING_CHANGED.CURRENTUNITSET, self.onUnitSetChanged, self)
end
function THInGameMenuPricesFrame:unsubscribeMessageCenterEvents()
g_messageCenter:unsubscribe(MessageType.TH_SETTING_CHANGED.CURRENTUNITSET, self)
end
function THInGameMenuPricesFrame:onActionSelectUnit()
local function protectedFunc()
local pricesFrame = self:getParent()
local currentUnit, maxNumUnits = self:getUnitSelectionValues()
if maxNumUnits > 0 then
currentUnit = math.max(currentUnit, 1) + 1
if currentUnit > maxNumUnits then
currentUnit = 1
end
else
currentUnit = 0
end
self:setCurrentUnit(currentUnit)
pricesFrame.productList:reloadData()
end
g_thMain:call(protectedFunc)
end
function THInGameMenuPricesFrame:onUnitSetChanged()
local function protectedFunc()
local pricesFrame = self:getParent()
pricesFrame.productList:reloadData()
end
g_thMain:call(protectedFunc)
end
function THInGameMenuPricesFrame:hook_onFrameOpen(superFunc, ...)
local envData = g_thMain:call("getDataTable", self, true, THInGameMenuPricesFrame)
local function prependFunc()
if envData ~= nil then
local pageTitleElement = envData.pageTitleElement
if pageTitleElement == nil then
pageTitleElement = g_thUtils:getElementByProfileName(self, "ingameMenuFrameHeaderText", true)
envData.pageTitleElement = pageTitleElement
end
local pageTitleText = g_i18n:getText("uc_inGameMenuPrices")
pageTitleElement:setText(pageTitleText)
end
end
g_thMain:call(prependFunc)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
envData:registerActionEvents()
envData:subscribeMessageCenterEvents()
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
function THInGameMenuPricesFrame:hook_onFrameClose(superFunc, ...)
local envData = g_thMain:call("getDataTable", self)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
envData:unregisterActionEvents()
envData:unsubscribeMessageCenterEvents()
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
function THInGameMenuPricesFrame:hook_rebuildTable(superFunc, ...)
local envData = g_thMain:call("getDataTable", self)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
for _, unitSetIndex in pairs(g_thMain.UNIT_SET) do
envData:updateUnitSelectionValues(unitSetIndex)
end
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
function THInGameMenuPricesFrame:hook_populateCellForItemInSection(superFunc, list, section, index, cell, ...)
local envData = g_thMain:call("getDataTable", self)
local _ = nil
local storageElement, storageSetTextFunc, oldStorageSetTextFunc = nil,nil,nil
local priceElement, priceSetValueFunc, oldPriceSetValueFunc = nil,nil,nil
local buyPriceElement, buyPriceSetValueFunc, oldBuyPriceSetValueFunc = nil,nil,nil
local function prependFunc()
if envData ~= nil then
local validFillTypes, numValidFillTypes = envData:getValidFillTypes()
local productList = self.productList
local fillType = nil
if numValidFillTypes ~= nil and productList ~= nil then
if list == self.productList then
fillType = validFillTypes[index]
else
fillType = validFillTypes[productList.selectedIndex]
end
end
if fillType ~= nil then
local currentUnit, maxNumUnits = envData:getUnitSelectionValues()
storageElement  = cell:getAttribute("storage")
priceElement    = cell:getAttribute("price")
buyPriceElement = cell:getAttribute("buyPrice")
if storageElement ~= nil then
local function hook_storageSetText(pSuperFunc, pSelf, pText, ...)
local function vPrependFunc()
local vStorageValue = g_thUtils:getNumericValues(pText, 1)
if vStorageValue == nil then
vStorageValue = 0
end
pText = g_i18n:formatVolume(vStorageValue, 0, nil,nil,nil, fillType, currentUnit, maxNumUnits)
end
g_thMain:call(vPrependFunc)
return pSuperFunc(pSelf, pText, ...)
end
_, storageSetTextFunc, oldStorageSetTextFunc = g_thUtils:hookFunction(storageElement, "setText", hook_storageSetText)
end
if priceElement ~= nil then
local function hook_priceSetValue(pSuperFunc, pSelf, pValue, ...)
local function vPrependFunc()
if type(pValue) == "number" then
pValue = envData:convertPriceElement(pSelf, pValue / 1000, fillType, currentUnit, maxNumUnits)
end
end
g_thMain:call(vPrependFunc)
return pSuperFunc(pSelf, pValue, ...)
end
_, priceSetValueFunc, oldPriceSetValueFunc = g_thUtils:hookFunction(priceElement, "setValue", hook_priceSetValue)
end
if buyPriceElement ~= nil then
local function hook_buyPriceSetValue(pSuperFunc, pSelf, pValue, ...)
local function vPrependFunc()
if type(pValue) == "number" then
pValue = envData:convertPriceElement(pSelf, pValue / 1000, fillType, currentUnit, maxNumUnits)
end
end
g_thMain:call(vPrependFunc)
return pSuperFunc(pSelf, pValue, ...)
end
_, buyPriceSetValueFunc, oldBuyPriceSetValueFunc = g_thUtils:hookFunction(buyPriceElement, "setValue", hook_buyPriceSetValue)
end
end
end
end
g_thMain:call(prependFunc)
local function appendFunc(...)
if storageSetTextFunc ~= nil   then rawset(storageElement, "setText", oldStorageSetTextFunc) end
if priceSetValueFunc ~= nil    then rawset(priceElement, "setValue", oldPriceSetValueFunc) end
if buyPriceSetValueFunc ~= nil then rawset(buyPriceElement, "setValue", oldBuyPriceSetValueFunc) end
return ...
end
return appendFunc(superFunc(self, list, section, index, cell, ...))
end
function THInGameMenuPricesFrame:hook_updateFluctuations(superFunc, list, section, index, cell, ...)
local envData = g_thMain:call("getDataTable", self)
local fluxLowElement, fluxLowSetValueFunc, oldFluxLowSetValueFunc = nil,nil,nil
local fluxHighElement, fluxHighSetValueFunc, oldFluxHighSetValueFunc = nil,nil,nil
local function prependFunc()
if envData ~= nil then
local validFillTypes, numValidFillTypes = envData:getValidFillTypes()
local productList = self.productList
local fillType = nil
if numValidFillTypes > 0 and productList ~= nil then
fillType = validFillTypes[productList.selectedIndex]
end
if fillType ~= nil then
local currentUnit, maxNumUnits = envData:getUnitSelectionValues()
local function hook_fluxLowSetValue(pSuperFunc, pSelf, pValue, ...)
local function vPrependFunc()
if type(pValue) == "number" then
pValue = envData:convertPriceElement(pSelf, pValue / 1000, fillType, currentUnit, maxNumUnits)
end
end
g_thMain:call(vPrependFunc)
return pSuperFunc(pSelf, pValue, ...)
end
local function hook_fluxHighSetValue(pSuperFunc, pSelf, pValue, ...)
local function vPrependFunc()
if type(pValue) == "number" then
pValue = envData:convertPriceElement(pSelf, pValue / 1000, fillType, currentUnit, maxNumUnits)
end
end
g_thMain:call(vPrependFunc)
return pSuperFunc(pSelf, pValue, ...)
end
fluxLowElement, fluxLowSetValueFunc, oldFluxLowSetValueFunc = g_thUtils:hookFunction(self.fluctuationLow, "setValue", hook_fluxLowSetValue)
fluxHighElement, fluxHighSetValueFunc, oldFluxHighSetValueFunc = g_thUtils:hookFunction(self.fluctuationHigh, "setValue", hook_fluxHighSetValue)
end
end
end
g_thMain:call(prependFunc)
local function appendFunc(...)
if fluxLowSetValueFunc ~= nil  then rawset(fluxLowElement, "setValue", oldFluxLowSetValueFunc) end
if fluxHighSetValueFunc ~= nil then rawset(fluxHighElement, "setValue", oldFluxHighSetValueFunc) end
return ...
end
return appendFunc(superFunc(self, list, section, index, cell, ...))
end
local function runScript()
g_thMain:setProtectedHook("InGameMenuPricesFrame", "onFrameOpen",                  THInGameMenuPricesFrame)
g_thMain:setProtectedHook("InGameMenuPricesFrame", "onFrameClose",                 THInGameMenuPricesFrame)
g_thMain:setProtectedHook("InGameMenuPricesFrame", "rebuildTable",                 THInGameMenuPricesFrame)
g_thMain:setProtectedHook("InGameMenuPricesFrame", "populateCellForItemInSection", THInGameMenuPricesFrame)
g_thMain:setProtectedHook("InGameMenuPricesFrame", "updateFluctuations",           THInGameMenuPricesFrame)
end
g_thMain:call(runScript)