-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THInGameMenuGeneralSettingsFrame = {}
function THInGameMenuGeneralSettingsFrame:initialize()
self.checkedElements = {}
self.multiOptionElements = {}
self.isMenuInitialized = false
return true
end
function THInGameMenuGeneralSettingsFrame:updateSettings()
local settingsList = g_thMain:getSettingsList()
for _, settingInfo in pairs(settingsList) do
local settingElement = settingInfo.element
local settingValue = settingInfo.values[settingInfo.changedValue]
if settingElement ~= nil and settingValue ~= nil then
if settingInfo.isCheckedOption then
settingElement:setIsChecked(settingValue)
else
settingElement:setState(settingInfo.changedValue)
end
end
end
end
function THInGameMenuGeneralSettingsFrame:onClickSettingOption(settingInfo, state, ...)
local function protectedFunc()
if settingInfo.values[state] ~= nil then
settingInfo.changedValue = state
if not settingInfo.restartRequired then
settingInfo.currentValue = state
if settingInfo.messageTypeId ~= nil then
g_messageCenter:publish(settingInfo.messageTypeId)
end
end
g_thMain:saveSettings()
end
end
g_thMain:call(protectedFunc)
end
function THInGameMenuGeneralSettingsFrame:hook_onFrameOpen(superFunc, ...)
local envData = g_thMain:call("getDataTable", self, true, THInGameMenuGeneralSettingsFrame)
local function prependFunc()
if envData ~= nil then
if not envData.isMenuInitialized then
local boxLayoutElement = self.boxLayout
local baseHeaderElement = g_thUtils:getElementByProfileName(boxLayoutElement, "settingsMenuSubtitle")
local baseCheckedOptionElement = self.checkUseMiles
local baseMultiOptionElement = self.multiMoneyUnit
if boxLayoutElement ~= nil and baseHeaderElement ~= nil and baseMultiOptionElement ~= nil then
local settingCategoryList = g_thMain:getSettingCategoryList()
if settingCategoryList ~= nil and #settingCategoryList > 0 then
for _, categoryInfo in ipairs(settingCategoryList) do
if #categoryInfo.settings > 0 then
local newHeaderElement = baseHeaderElement:clone(boxLayoutElement)
if newHeaderElement ~= nil then
newHeaderElement:setText(categoryInfo.title)
newHeaderElement:reloadFocusHandling(true)
categoryInfo.element = newHeaderElement
end
for _, settingIndex in ipairs(categoryInfo.settings) do
local settingInfo = g_thMain:getSetting(settingIndex, true)
if settingInfo ~= nil then
if settingInfo.isCheckedOption then
settingInfo.element = baseCheckedOptionElement:clone(boxLayoutElement)
else
settingInfo.element = baseMultiOptionElement:clone(boxLayoutElement)
end
if settingInfo.element ~= nil then
local elementData, element = g_thMain:getDataTable(settingInfo.element, true)
local titleElement = settingInfo.element.elements[4]
local toolTipElement = settingInfo.element.elements[6]
titleElement:setText(settingInfo.title)
toolTipElement:setText(settingInfo.toolTip)
if not elementData.isOnClickUpdated then
element.onClickCallback = function(pSelf, pState, ...)
return envData:onClickSettingOption(settingInfo, pState, pSelf, ...)
end
elementData.isOnClickUpdated = true
end
element:setTexts(settingInfo.valueTexts)
element:reloadFocusHandling(true)
end
end
end
end
end
end
envData.isMenuInitialized = true
end
end
envData:updateSettings()
end
end
g_thMain:call(prependFunc)
return superFunc(self, ...)
end
local function runScript()
g_thMain:setProtectedHook("InGameMenuGeneralSettingsFrame", "onFrameOpen", THInGameMenuGeneralSettingsFrame)
end
g_thMain:call(runScript)