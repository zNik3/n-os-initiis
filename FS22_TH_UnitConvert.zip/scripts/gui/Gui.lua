-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THGui = {}
function THGui:initialize()
return true
end
function THGui:hook_showSiloDialog(superFunc, args, ...)
local _, showDialogFunc, oldShowDialogFunc = nil,nil,nil
local function prependFunc()
if args ~= nil then
local dialogParams = {}
if type(args.target) == "table" then
local targetSource = args.target.source
if g_thUtils:getIsType(targetSource, LoadingStation) then
local stationData, station = g_thMain:getDataTable(targetSource)
if stationData ~= nil then
dialogParams.targetData = stationData
dialogParams.loadTrigger = args.target
dialogParams.loadingStation = station
dialogParams.placeable = station.owningPlaceable
end
end
end
local function hook_showDialog(pSuperFunc, pSelf, pGuiName, ...)
local function vAppendFunc(pRootElement, ...)
local vProtectedChunk = function()
if pGuiName == "SiloDialog" and pRootElement ~= nil and pRootElement.target ~= nil then
local vDialogData = g_thMain:getDataTable(pRootElement.target)
if vDialogData ~= nil then
dialogParams.rootElement = pRootElement
vDialogData:resetParameters(dialogParams)
end
end
end
g_thMain:call(vProtectedChunk)
return pRootElement, ...
end
return vAppendFunc(pSuperFunc(pSelf, pGuiName, ...))
end
_, showDialogFunc, oldShowDialogFunc = g_thUtils:hookFunction(self, "showDialog", hook_showDialog)
end
end
g_thMain:call(prependFunc)
local function appendFunc(...)
if showDialogFunc ~= nil then rawset(self, "showDialog", oldShowDialogFunc) end
return ...
end
return appendFunc(superFunc(self, args, ...))
end
local function runScript()
g_thMain:setProtectedHook("Gui", "showSiloDialog", THGui)
end
g_thMain:call(runScript)