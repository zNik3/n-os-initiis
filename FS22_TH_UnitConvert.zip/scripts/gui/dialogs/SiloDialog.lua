-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THSiloDialog = {}
function THSiloDialog:initialize()
self.params = {}
self.actionEventIds = {}
self.hasInfiniteCapacity = nil
return true
end
function THSiloDialog:resetParameters(newTable)
if newTable ~= nil then
self.params = newTable
else
g_thUtils:clearTable(self.params)
end
return self.params
end
function THSiloDialog:updateFillTypesElement()
local siloDialog = self:getParent()
local targetData = self.params.targetData
local fillTypesElement = siloDialog.fillTypesElement
local fillTypeMapping = siloDialog.fillTypeMapping
local fillLevels = siloDialog.fillLevels
if not self.hasInfiniteCapacity and targetData ~= nil and fillLevels ~= nil and fillTypeMapping ~= nil then
local elementTexts = fillTypesElement.texts
if #elementTexts > 0 then
local elementIsDirty = false
local selectedState = fillTypesElement:getState()
for idx = 1, #elementTexts do
local fillTypeInfo = g_thMain:getFillType(fillTypeMapping[idx])
if fillTypeInfo ~= nil then
local currentUnit = targetData:getUnitSelectionValues(fillTypeInfo.index)
local fillLevel = fillLevels[fillTypeInfo.index]
if fillLevel ~= nil then
elementTexts[idx] = fillTypeInfo.title..": "..g_i18n:formatVolume(fillLevel, 0, nil,nil,nil, fillTypeInfo, currentUnit)
elementIsDirty = true
end
end
end
if elementIsDirty then
fillTypesElement:setTexts(elementTexts)
fillTypesElement:setState(selectedState, true)
end
end
end
end
function THSiloDialog:getUnitSelectionValues(fillTypeIndex, unitSet)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local targetData = self.params.targetData
local currentUnit = 0
if targetData ~= nil then
currentUnit = targetData:getUnitSelectionValues(fillTypeIndex, unitSetIndex)
end
return currentUnit, targetData
end
function THSiloDialog:registerActionEvents()
local siloDialog = self:getParent()
if g_thMain.isClient then
self:unregisterActionEvents()
local dialogName = siloDialog.name
local contextName = Gui.INPUT_CONTEXT_DIALOG.."_"..dialogName
local actionEventIds = self.actionEventIds
g_inputBinding:beginActionEventsModification(contextName)
local _, eventId = g_inputBinding:registerActionEvent(InputAction.UC_SELECT_UNIT, self, self.onActionSelectUnit, false, true, false, true)
g_inputBinding:setActionEventTextVisibility(eventId, false)
actionEventIds.selectUnit = eventId
g_inputBinding:endActionEventsModification()
end
end
function THSiloDialog:unregisterActionEvents()
if g_thMain.isClient then
for _, eventId in pairs(self.actionEventIds) do
g_inputBinding:removeActionEvent(eventId)
end
g_thUtils:clearTable(self.actionEventIds)
end
end
function THSiloDialog:subscribeMessageCenterEvents()
self:unsubscribeMessageCenterEvents()
g_messageCenter:subscribe(MessageType.TH_SETTING_CHANGED.CURRENTUNITSET, self.onUnitSetChanged, self)
end
function THSiloDialog:unsubscribeMessageCenterEvents()
g_messageCenter:unsubscribe(MessageType.TH_SETTING_CHANGED.CURRENTUNITSET, self)
end
function THSiloDialog:onActionSelectUnit()
local function protectedFunc()
local siloDialog = self:getParent()
local fillTypeIndex = siloDialog.selectedFillType
if fillTypeIndex ~= nil then
local currentUnit, targetData = self:getUnitSelectionValues(fillTypeIndex)
if targetData ~= nil then
local maxNumUnits = g_thMain:getFillTypeMaxNumUnits(fillTypeIndex)
if maxNumUnits > 0 then
currentUnit = math.max(currentUnit, 1) + 1
if currentUnit > maxNumUnits then
currentUnit = 1
end
else
currentUnit = 0
end
targetData:setCurrentUnit(currentUnit, fillTypeIndex)
self:updateFillTypesElement()
end
end
end
g_thMain:call(protectedFunc)
end
function THSiloDialog:onUnitSetChanged()
local function protectedFunc()
self:updateFillTypesElement()
end
g_thMain:call(protectedFunc)
end
function THSiloDialog:hook_onOpen(superFunc, ...)
local envData = g_thMain:call("getDataTable", self, true, THSiloDialog)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
envData:registerActionEvents()
envData:subscribeMessageCenterEvents()
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
function THSiloDialog:hook_onClose(superFunc, ...)
local envData = g_thMain:call("getDataTable", self)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
envData:resetParameters()
envData:unregisterActionEvents()
envData:unsubscribeMessageCenterEvents()
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
function THSiloDialog:hook_setFillLevels(superFunc, fillLevels, hasInfiniteCapacity, ...)
local envData = g_thMain:call("getDataTable", self)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
envData.hasInfiniteCapacity = hasInfiniteCapacity
envData:updateFillTypesElement()
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, fillLevels, hasInfiniteCapacity, ...))
end
local function runScript()
local gui_siloDialog = g_gui.guis["SiloDialog"]
g_thMain:setProtectedHook(gui_siloDialog, "onOpenCallback",  THSiloDialog, "hook_onOpen")
g_thMain:setProtectedHook(gui_siloDialog, "onCloseCallback", THSiloDialog, "hook_onClose")
g_thMain:setProtectedHook("SiloDialog", "setFillLevels", THSiloDialog)
end
g_thMain:call(runScript)