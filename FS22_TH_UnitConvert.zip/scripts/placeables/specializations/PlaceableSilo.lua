-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THPlaceableSilo = {}
function THPlaceableSilo.prerequisitesPresent(specializations)
return SpecializationUtil.hasSpecialization(PlaceableSilo, specializations)
end
function THPlaceableSilo.initSpecialization()
g_storeManager:addSpecType("ucSiloFillTypes", "shopListAttributeIconFillTypes", THPlaceableSilo.loadSpecValueFillTypes, THPlaceableSilo.getSpecValueFillTypes, "placeable")
end
function THPlaceableSilo.registerOverwrittenFunctions(placeableType)
SpecializationUtil.registerOverwrittenFunction(placeableType, "updateInfo", THPlaceableSilo.updateInfo)
end
function THPlaceableSilo:updateInfo(superFunc, infoTable, ...)
local spec = self.spec_silo
local fillTypeManager, getFillTypeTitleByIndexFunc, oldGetFillTypeTitleByIndexFunc = nil,nil,nil
local function prependFunc()
local function hook_getFillTypeTitleByIndex(pSuperFunc, pSelf, pIndex, ...)
local function vAppendFunc(pTitle, ...)
local vProtectedChunk = function()
local vFillTypeInfo = g_thMain:getFillType(pIndex)
if vFillTypeInfo ~= nil then
pTitle = "ucHook_"..vFillTypeInfo.name
end
end
g_thMain:call(vProtectedChunk)
return pTitle, ...
end
return vAppendFunc(pSuperFunc(pSelf, pIndex, ...))
end
fillTypeManager, getFillTypeTitleByIndexFunc, oldGetFillTypeTitleByIndexFunc = g_thUtils:hookFunction("g_fillTypeManager", "getFillTypeTitleByIndex", hook_getFillTypeTitleByIndex)
end
g_thMain:call(prependFunc)
local function appendFunc(...)
if getFillTypeTitleByIndexFunc ~= nil then rawset(fillTypeManager, "getFillTypeTitleByIndex", oldGetFillTypeTitleByIndexFunc) end
local protectedChunk = function()
if infoTable ~= nil then
local loadingStationData = g_thMain:getDataTable(spec.loadingStation)
for _, infoItem in pairs(infoTable) do
if type(infoItem) == "table" and infoItem.title ~= nil and infoItem.text ~= nil then
local _,_, fillTypeName = string.find(infoItem.title, "ucHook_(.*)")
local fillTypeInfo = g_thMain:getFillType(fillTypeName)
if fillTypeInfo ~= nil then
infoItem.title = fillTypeInfo.title
if loadingStationData ~= nil then
local value = g_thUtils:getNumericValues(infoItem.text, 1)
local currentUnit = loadingStationData:getUnitSelectionValues(fillTypeInfo.index)
if value ~= nil then
infoItem.text = g_i18n:formatVolume(value, 0, nil,nil,nil, fillTypeInfo, currentUnit)
end
end
end
end
end
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, infoTable, ...))
end
function THPlaceableSilo.loadSpecValueFillTypes(xmlFile, customEnvironment, baseDirectory)
local storagesKey = "placeable.silo.storages.storage(0)"
local fillTypesList = {}
if xmlFile:hasProperty(storagesKey) then
local fillTypes = xmlFile:getValue(storagesKey.."#fillTypes")
local fillTypeCategories = xmlFile:getValue(storagesKey.."#fillTypeCategories")
local function addFillTypes(pFillTypesArray)
if pFillTypesArray ~= nil and #pFillTypesArray > 0 then
for _, vFillType in ipairs(pFillTypesArray) do
local vFillTypeInfo = g_thUtils:getFillType(vFillType)
if vFillTypeInfo ~= nil and vFillTypeInfo.index ~= FillType.UNKNOWN then
if not fillTypesList[vFillTypeInfo.name] then
fillTypesList[vFillTypeInfo.name] = true
end
end
end
end
end
if fillTypes ~= nil and fillTypes ~= "" then
local fillTypesArray = g_fillTypeManager:getFillTypesByNames(fillTypes)
addFillTypes(fillTypesArray)
end
if fillTypeCategories ~= nil and fillTypeCategories ~= "" then
local fillTypesArray = g_fillTypeManager:getFillTypesByCategoryNames(fillTypeCategories)
addFillTypes(fillTypesArray)
end
end
return fillTypesList
end
function THPlaceableSilo.getSpecValueFillTypes(storeItem, realItem)
if storeItem.specs.ucSiloFillTypes == nil then
return {}
end
return storeItem.specs.ucSiloFillTypes
end