-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THPlaceableSiloExtension = {}
function THPlaceableSiloExtension.prerequisitesPresent(specializations)
return SpecializationUtil.hasSpecialization(PlaceableSiloExtension, specializations)
end
function THPlaceableSiloExtension.initSpecialization()
g_storeManager:addSpecType("ucSiloExtensionFillTypes", "shopListAttributeIconFillTypes", THPlaceableSiloExtension.loadSpecValueFillTypes, THPlaceableSiloExtension.getSpecValueFillTypes, "placeable")
end
function THPlaceableSiloExtension.loadSpecValueFillTypes(xmlFile, customEnvironment, baseDirectory)
local storageKey = "placeable.siloExtension.storage"
local fillTypesList = {}
if xmlFile:hasProperty(storageKey) then
local fillTypes = xmlFile:getValue(storageKey.."#fillTypes")
local fillTypeCategories = xmlFile:getValue(storageKey.."#fillTypeCategories")
local function addFillTypes(pFillTypesArray)
if pFillTypesArray ~= nil and #pFillTypesArray > 0 then
for _, vFillType in ipairs(pFillTypesArray) do
local vFillTypeInfo = g_thUtils:getFillType(vFillType)
if vFillTypeInfo ~= nil and vFillTypeInfo.index ~= FillType.UNKNOWN then
if not fillTypesList[vFillTypeInfo.name] then
fillTypesList[vFillTypeInfo.name] = true
end
end
end
end
end
if fillTypes ~= nil and fillTypes ~= "" then
local fillTypesArray = g_fillTypeManager:getFillTypesByNames(fillTypes)
addFillTypes(fillTypesArray)
end
if fillTypeCategories ~= nil and fillTypeCategories ~= "" then
local fillTypesArray = g_fillTypeManager:getFillTypesByCategoryNames(fillTypeCategories)
addFillTypes(fillTypesArray)
end
end
return fillTypesList
end
function THPlaceableSiloExtension.getSpecValueFillTypes(storeItem, realItem)
if storeItem.specs.ucSiloExtensionFillTypes == nil then
return {}
end
return storeItem.specs.ucSiloExtensionFillTypes
end