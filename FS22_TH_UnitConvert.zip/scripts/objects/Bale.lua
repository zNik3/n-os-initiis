-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THBale = {}
function THBale:hook_showInfo(superFunc, box, ...)
local _, i18n = nil,nil
local formatVolumeFunc, oldFormatVolumeFunc = nil,nil
local formatMassFunc, oldFormatMassFunc = nil,nil
local function prependFunc()
if self.fillType ~= nil then
local function hook_formatVolume(pSuperFunc, pSelf, pValue, pPrecision, pUnit)
pPrecision = 0
return pSuperFunc(pSelf, pValue, pPrecision, pUnit, nil,nil, self.fillType)
end
local function hook_formatMass(pSuperFunc, pSelf, pMass, pMaxMass, pShowKg)
return pSuperFunc(pSelf, pMass, pMaxMass, pShowKg, 0, nil,nil, self.fillType)
end
i18n, formatVolumeFunc, oldFormatVolumeFunc = g_thUtils:hookFunction("g_i18n", "formatVolume", hook_formatVolume)
if i18n ~= nil then
_, formatMassFunc, oldFormatMassFunc = g_thUtils:hookFunction(i18n, "formatMass", hook_formatMass)
end
end
end
local function appendFunc(...)
if formatVolumeFunc ~= nil then rawset(i18n, "formatVolume", oldFormatVolumeFunc) end
if formatMassFunc ~= nil then rawset(i18n, "formatMass", oldFormatMassFunc) end
return ...
end
g_thMain:call(prependFunc)
return appendFunc(superFunc(self, box, ...))
end
local function runScript()
g_thMain:setProtectedHook("Bale", "showInfo", THBale)
end
g_thMain:call(runScript)