-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THBunkerSilo = {}
function THBunkerSilo:hook_update(superFunc, dt, ...)
local envData = g_thMain:call("getDataTable", self, true, THBunkerSilo)
local i18n, getTextFunc, oldGetTextFunc = nil,nil,nil
local fillTypeManager, getFillTypeByIndexFunc, oldGetFillTypeByIndexFunc = nil,nil,nil
local currentMission, addExtraPrintTextFunc, oldAddExtraPrintTextFunc = nil,nil,nil
local function prependFunc()
if envData ~= nil then
if self:getCanInteract(true) and g_currentMission ~= nil then
local fillLevelText = nil
local function hook_getFillTypeByIndex(pSuperFunc, pSelf, pIndex, ...)
local function vAppendFunc(pFillTypeDesc, ...)
local vProtectedChunk = function()
if pFillTypeDesc ~= nil and self.fillLevel ~= nil then
fillLevelText = "("..pFillTypeDesc.title.."): "..g_i18n:formatVolume(self.fillLevel, 0, nil,nil,nil, pFillTypeDesc)
end
end
g_thMain:call(vProtectedChunk)
return pFillTypeDesc, ...
end
return vAppendFunc(pSuperFunc(pSelf, pIndex, ...))
end
local function hook_getText(pSuperFunc, pSelf, pKey, ...)
local function vAppendFunc(pText, ...)
local vProtectedChunk = function()
if pKey == "info_fillLevel" and fillLevelText ~= nil then
fillLevelText = pText.." "..fillLevelText
pText = pKey.."_"..pText
end
end
g_thMain:call(vProtectedChunk)
return pText, ...
end
return vAppendFunc(pSuperFunc(pSelf, pKey, ...))
end
local function hook_addExtraPrintText(pSuperFunc, pSelf, pText, ...)
local function vPrependFunc()
if type(pText) == "string" then
local _,_, vRealText = string.find(pText, "^info_fillLevel_(.*)")
if vRealText ~= nil then
if fillLevelText ~= nil then
pText = fillLevelText
else
pText = vRealText
end
end
end
end
g_thMain:call(vPrependFunc)
return pSuperFunc(pSelf, pText, ...)
end
i18n, getTextFunc, oldGetTextFunc = g_thUtils:hookFunction("g_i18n", "getText", hook_getText)
fillTypeManager, getFillTypeByIndexFunc, oldGetFillTypeByIndexFunc = g_thUtils:hookFunction("g_fillTypeManager", "getFillTypeByIndex", hook_getFillTypeByIndex)
currentMission, addExtraPrintTextFunc, oldAddExtraPrintTextFunc = g_thUtils:hookFunction("g_currentMission", "addExtraPrintText", hook_addExtraPrintText)
end
end
end
g_thMain:call(prependFunc)
local function appendFunc(...)
if getTextFunc ~= nil then rawset(i18n, "getText", oldGetTextFunc) end
if addExtraPrintTextFunc ~= nil then rawset(currentMission, "addExtraPrintText", oldAddExtraPrintTextFunc) end
if getFillTypeByIndexFunc ~= nil then rawset(fillTypeManager, "getFillTypeByIndex", oldGetFillTypeByIndexFunc) end
return ...
end
return appendFunc(superFunc(self, dt, ...))
end
local function runScript()
g_thMain:setProtectedHook("BunkerSilo", "update", THBunkerSilo)
end
g_thMain:call(runScript)