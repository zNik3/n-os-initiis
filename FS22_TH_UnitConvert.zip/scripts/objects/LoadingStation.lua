-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THLoadingStation = {}
function THLoadingStation:initialize()
self.currentUnit = {}
for _, unitSetIndex in pairs(g_thMain.UNIT_SET) do
self.currentUnit[unitSetIndex] = {}
end
return true
end
function THLoadingStation:getUnitSelectionValues(fillTypeIndex, unitSet)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local currentUnit = self.currentUnit[unitSetIndex][fillTypeIndex]
if currentUnit ~= nil then
return currentUnit
end
return 0
end
function THLoadingStation:setCurrentUnit(value, fillType, unitSet)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local fillTypeInfo = g_thMain:getFillType(fillType, true)
if fillTypeInfo ~= nil then
local currentUnit = g_thUtils:getNoNil(self.currentUnit[unitSetIndex][fillTypeInfo.index], 0)
local maxNumUnits = g_thMain:getFillTypeMaxNumUnits(fillTypeInfo, unitSetIndex)
if g_thUtils:argIsValid(type(value) == "number", "value", value) then
value = math.floor(math.max(0, value))
if maxNumUnits > 0 then
if value <= 0 or value > maxNumUnits then
value = 1
end
else
value = 0
end
self.currentUnit[unitSetIndex][fillTypeInfo.index] = value
return value
end
return currentUnit
end
return 0
end
function THLoadingStation:hook_load(superFunc, ...)
local function prependFunc()
if g_thMain:getDataTable(self) == nil then
g_thMain:createDataTable(self, nil, THLoadingStation)
end
end
g_thMain:call(prependFunc)
return superFunc(self, ...)
end
local function runScript()
g_thMain:setProtectedHook("LoadingStation", "load", THLoadingStation)
end
g_thMain:call(runScript)