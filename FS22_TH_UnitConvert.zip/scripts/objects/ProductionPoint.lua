-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THProductionPoint = {}
function THProductionPoint:initialize()
self.currentUnit = {}
self.maxNumUnits = {}
self.validFillTypes = {}
self.numValidFillTypes = 0
for _, unitSetIndex in pairs(g_thMain.UNIT_SET) do
self.currentUnit[unitSetIndex] = 0
self.maxNumUnits[unitSetIndex] = 0
end
return true
end
function THProductionPoint:updateValidFillTypes()
local productionPoint = self:getParent()
local validFillTypes = g_thUtils:clearTable(self.validFillTypes)
local numFillTypes = 0
if productionPoint.inputFillTypeIds ~= nil then
for fillType, isValid in pairs(productionPoint.inputFillTypeIds) do
if validFillTypes[fillType] == nil and isValid == true then
validFillTypes[fillType] = true
numFillTypes = numFillTypes + 1
end
end
end
if productionPoint.outputFillTypeIds ~= nil then
for fillType, isValid in pairs(productionPoint.outputFillTypeIds) do
if validFillTypes[fillType] == nil and isValid == true then
validFillTypes[fillType] = true
numFillTypes = numFillTypes + 1
end
end
end
self.numValidFillTypes = numFillTypes
for _, unitSetIndex in pairs(g_thMain.UNIT_SET) do
self:updateUnitSelectionValues(unitSetIndex)
end
return validFillTypes, numFillTypes
end
function THProductionPoint:getValidFillTypes()
return self.validFillTypes, self.numValidFillTypes
end
function THProductionPoint:updateUnitSelectionValues(unitSet)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local validFillTypes, numValidFillTypes = self:getValidFillTypes()
local currentUnit = self:getUnitSelectionValues(unitSet)
local maxNumUnits = 0
if numValidFillTypes > 0 then
maxNumUnits = g_thMain:getFillTypeMaxNumUnits(validFillTypes, unitSetIndex)
end
if maxNumUnits > 0 then
if currentUnit == 0 or currentUnit > maxNumUnits then
currentUnit = 1
end
else
currentUnit = 0
end
self.currentUnit[unitSetIndex] = currentUnit
self.maxNumUnits[unitSetIndex] = maxNumUnits
return currentUnit, maxNumUnits
end
function THProductionPoint:getUnitSelectionValues(unitSet)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local currentUnit = self.currentUnit[unitSetIndex]
local maxNumUnits = self.maxNumUnits[unitSetIndex]
return currentUnit, maxNumUnits
end
function THProductionPoint:setCurrentUnit(value, unitSet)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local currentUnit = self.currentUnit[unitSetIndex]
local maxNumUnits = self.maxNumUnits[unitSetIndex]
if g_thUtils:argIsValid(type(value) == "number", "value", value) then
value = math.floor(math.max(0, value))
if maxNumUnits > 0 then
if value <= 0 or value > maxNumUnits then
value = 1
end
else
value = 0
end
self.currentUnit[unitSetIndex] = value
return value
end
return currentUnit
end
function THProductionPoint:hook_load(superFunc, ...)
local envData = g_thMain:call("getDataTable", self, true, THProductionPoint)
local function appendFunc(success, ...)
local protectedChunk = function()
if envData ~= nil then
envData:updateValidFillTypes()
end
end
g_thMain:call(protectedChunk)
return success, ...
end
return appendFunc(superFunc(self, ...))
end
function THProductionPoint:hook_updateInfo(superFunc, superFunc2, infoTable, ...)
local envData = g_thMain:call("getDataTable", self)
local fillTypeManager, getFillTypeTitleByIndexFunc, oldGetFillTypeTitleByIndexFunc = nil,nil,nil
local function prependFunc()
if envData ~= nil then
local function hook_getFillTypeTitleByIndex(pSuperFunc, pSelf, pIndex, ...)
local function vAppendFunc(pTitle, ...)
local vProtectedChunk = function()
local vFillTypeInfo = g_thMain:getFillType(pIndex)
if vFillTypeInfo ~= nil then
pTitle = "ucHook_"..vFillTypeInfo.name
end
end
g_thMain:call(vProtectedChunk)
return pTitle, ...
end
return vAppendFunc(pSuperFunc(pSelf, pIndex, ...))
end
fillTypeManager, getFillTypeTitleByIndexFunc, oldGetFillTypeTitleByIndexFunc = g_thUtils:hookFunction("g_fillTypeManager", "getFillTypeTitleByIndex", hook_getFillTypeTitleByIndex)
end
end
g_thMain:call(prependFunc)
local function appendFunc(...)
if getFillTypeTitleByIndexFunc ~= nil then rawset(fillTypeManager, "getFillTypeTitleByIndex", oldGetFillTypeTitleByIndexFunc) end
local protectedChunk = function()
if envData ~= nil and infoTable ~= nil then
local currentUnit, maxNumUnits = envData:getUnitSelectionValues()
for _, infoItem in pairs(infoTable) do
if type(infoItem) == "table" and infoItem.title ~= nil and infoItem.text ~= nil then
local _,_, fillTypeName = string.find(infoItem.title, "ucHook_(.*)")
local fillTypeInfo = g_thMain:getFillType(fillTypeName)
if fillTypeInfo ~= nil then
infoItem.title = fillTypeInfo.title
local value = g_thUtils:getNumericValues(infoItem.text, 1)
if value ~= nil then
infoItem.text = g_i18n:formatVolume(value, 0, nil,nil,nil, fillTypeInfo, currentUnit, maxNumUnits)
end
end
end
end
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, superFunc2, infoTable, ...))
end
local function runScript()
g_thMain:setProtectedHook("ProductionPoint", "load",       THProductionPoint)
--g_thMain:setProtectedHook("ProductionPoint", "updateInfo", THProductionPoint)
end
g_thMain:call(runScript)