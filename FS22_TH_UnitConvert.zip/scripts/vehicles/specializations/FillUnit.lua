-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THFillUnit = {}
function THFillUnit.prerequisitesPresent(specializations)
return SpecializationUtil.hasSpecialization(FillUnit, specializations)
end
function THFillUnit.registerOverwrittenFunctions(vehicleType)
SpecializationUtil.registerOverwrittenFunction(vehicleType, "showInfo", THFillUnit.showInfo)
end
function THFillUnit:showInfo(superFunc, box, ...)
local spec = g_thMain:call("getSpecTable", self, "fillUnit", false)
local _ = nil
local addLineFunc, oldAddLineFunc = nil,nil
local fillTypeManager, getFillTypeByIndexFunc, oldGetFillTypeByIndexFunc = nil,nil,nil
local changedFillTypes = {}
local function prependFunc()
if spec.isInfoDirty then
local function hook_getFillTypeByIndex(pSuperFunc, pSelf, pIndex, ...)
local function vAppendFunc(pFillTypeDesc, ...)
local vProtectedChunk = function()
if pFillTypeDesc ~= nil then
local vFillTypeData = g_thMain:getDataTable(pFillTypeDesc)
if vFillTypeData ~= nil then
pFillTypeDesc.title = "ucHook_"..pFillTypeDesc.name
changedFillTypes[pFillTypeDesc] = vFillTypeData
end
end
end
g_thMain:call(vProtectedChunk)
return pFillTypeDesc, ...
end
return vAppendFunc(pSuperFunc(pSelf, pIndex, ...))
end
fillTypeManager, getFillTypeByIndexFunc, oldGetFillTypeByIndexFunc = g_thUtils:hookFunction("g_fillTypeManager", "getFillTypeByIndex", hook_getFillTypeByIndex)
end
local function hook_addLine(pSuperFunc, pSelf, pTitle, pText, ...)
local function vPrependFunc()
local _, _, vFillTypeName = string.find(pTitle, "ucHook_(.*)")
for _, vInfo in pairs(spec.fillUnitInfos) do
local vInfoData = g_thMain:getDataTable(vInfo, true)
if (vInfoData.fillType ~= nil and pTitle == vInfoData.fillType.name)
or (vFillTypeName ~= nil and pTitle == vInfo.title)
then
if vFillTypeName ~= nil then
local vFillTypeInfo = g_thMain:getFillType(vFillTypeName, true)
vInfo.title = vFillTypeInfo.name
vInfoData.fillType = vFillTypeInfo
end
pTitle = vInfoData.fillType.title
pText = g_i18n:formatVolume(vInfo.fillLevel, 0, nil,nil,nil, vInfoData.fillType)
break
end
end
end
g_thMain:call(vPrependFunc)
return pSuperFunc(pSelf, pTitle, pText, ...)
end
_, addLineFunc, oldAddLineFunc = g_thUtils:hookFunction(box, "addLine", hook_addLine)
end
g_thMain:call(prependFunc)
local function appendFunc(...)
if getFillTypeByIndexFunc ~= nil then rawset(fillTypeManager, "getFillTypeByIndex", oldGetFillTypeByIndexFunc) end
if addLineFunc ~= nil then rawset(box, "addLine", oldAddLineFunc) end
for _, fillTypeData in pairs(changedFillTypes) do
fillTypeData:restoreDefaultValue("title")
end
return ...
end
return appendFunc(superFunc(self, box, ...))
end