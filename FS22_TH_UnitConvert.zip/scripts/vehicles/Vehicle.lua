-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THVehicle = {}
function THVehicle:initialize()
self.currentUnit = {}
for _, unitSetIndex in pairs(g_thMain.UNIT_SET) do
self.currentUnit[unitSetIndex] = 0
end
return true
end
function THVehicle:getUnitSelectionValues(unitSet)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
return self.currentUnit[unitSetIndex]
end
function THVehicle:setCurrentUnit(value, unitSet)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local currentUnit = self.currentUnit[unitSetIndex]
if g_thUtils:argIsValid(type(value) == "number", "value", value) then
value = math.floor(math.max(0, value))
self.currentUnit[unitSetIndex] = value
return value
end
return currentUnit
end
function THVehicle:hook_load(superFunc, ...)
local function prependFunc()
if g_thMain:getDataTable(self) == nil then
g_thMain:createDataTable(self, nil, THVehicle)
end
end
g_thMain:call(prependFunc)
return superFunc(self, ...)
end
local function runScript()
g_thMain:setProtectedHook("Vehicle", "load", THVehicle)
end
g_thMain:call(runScript)