-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THCore = {}
local THCore_mt = Class(THCore)
THCore.SPEC_TYPE = {
VEHICLE   = "vehicle",
PLACEABLE = "placeable"
}
function THCore:new(dataKey, mt)
mt = Utils.getNoNil(mt, THCore_mt)
local newEnv = setmetatable({}, mt)
if newEnv ~= nil then
local missionInfo = g_mpLoadingScreen.missionInfo
local missionDynamicInfo = g_mpLoadingScreen.missionDynamicInfo
if g_thUtils:argIsValid(type(dataKey) == "string", "dataKey", dataKey) then
newEnv.isServer = g_server ~= nil
newEnv.isClient = g_client ~= nil
newEnv.dataKey  = dataKey
newEnv.actionEventIds = {}
newEnv.isMultiplayer  = missionDynamicInfo.isMultiplayer
newEnv.isEnabled      = true
newEnv.modInfo = nil
newEnv.modName = g_currentModName
newEnv.modPath = g_currentModDirectory
newEnv.modList = missionDynamicInfo.mods
newEnv.modSettingsPath = g_currentModSettingsDirectory
newEnv.sdkPath = newEnv.modPath.."sdk/"
createFolder(newEnv.modSettingsPath)
createFolder(newEnv.modSettingsPath.."maps/")
newEnv.loadedMods = {
byId    = {},
byIndex = {}
}
local mapInfo = missionInfo.map
local mapName = mapInfo.id
if mapInfo.isModMap then
if g_thUtils:getNoNil(mapInfo.customEnvironment, "") ~= "" then
mapName = mapInfo.customEnvironment
end
end
if g_thUtils:getNoNil(mapName, "") ~= "" then
newEnv.mapName = mapName
newEnv.mapSettingsPath = newEnv.modSettingsPath.."maps/"..mapName.."/"
createFolder(newEnv.mapSettingsPath)
end
newEnv.mapInfo = mapInfo
newEnv.mapIsMod = mapInfo.isModMap
newEnv.mapXMLFile = mapInfo.mapXMLFilename
newEnv.mapModInfo = nil
if newEnv.mapIsMod then
newEnv.mapPath = mapInfo.baseDirectory
end
newEnv.settingsXMLFile = newEnv.modSettingsPath.."settings.xml"
newEnv.settings = {
byId       = {},
byIndex    = {},
byCategory = {},
idToIndex  = {}
}
newEnv.SETTING = newEnv.settings.idToIndex
newEnv.settingCategories = {
byId      = {},
byIndex   = {},
idToIndex = {}
}
newEnv.SETTING_CATEGORY = newEnv.settingCategories.idToIndex
newEnv.specializations = {
byId      = {},
byType    = {},
byIndex   = {},
idToIndex = {}
}
newEnv.SPECIALIZATION = newEnv.specializations.idToIndex
for _, typeName in pairs(THCore.SPEC_TYPE) do
newEnv.specializations.byType[typeName] = {}
end
end
return newEnv
end
end
function THCore:call(target, arg1, ...)
local function getRetValues(pSuccess, p1, ...)
if pSuccess then
return p1, ...
end
self.isEnabled = false
if type(p1) == "string" then
g_thUtils:errorMsg(false, p1)
else
printCallstack()
end
end
if self.isEnabled then
if type(target) == "string" then
return getRetValues(g_thUtils:pcall(self, target, arg1, ...))
end
return getRetValues(g_thUtils:pcall(target, arg1, ...))
end
end
function THCore:setProtectedHook(srcClass, srcFuncKey, tgtClass, tgtFuncKey, useSelf)
useSelf = g_thUtils:getNoNil(useSelf, true)
if type(srcClass) == "string" then
local globalEnv = g_thUtils:getGlobalEnv()
srcClass = globalEnv[srcClass]
end
if tgtFuncKey == nil then
if type(srcFuncKey) == "string" then
tgtFuncKey = "hook_"..srcFuncKey
end
end
local srcFunc = srcClass[srcFuncKey]
local tgtFunc = tgtClass[tgtFuncKey]
if  g_thUtils:assert(type(srcFunc) == "function", nil, "Invalid source function %q", srcFuncKey)
and g_thUtils:assert(type(tgtFunc) == "function", nil, "Invalid target function %q", tgtFuncKey)
then
rawset(srcClass, srcFuncKey, function(p1, ...)
if self.isEnabled then
if useSelf then
return tgtFunc(p1, srcFunc, ...)
else
return tgtFunc(srcFunc, p1, ...)
end
else
return srcFunc(p1, ...)
end
end)
return true
end
return false
end
function THCore:createDataTable(parent, clear, upValue, ...)
if parent == nil then
return
end
local dataTable = parent[self.dataKey]
if dataTable == nil or clear then
if dataTable == nil then
dataTable = {}
parent[self.dataKey] = dataTable
clear = false
else
if dataTable.delete ~= nil then
dataTable:delete()
end
for k in pairs(dataTable) do
dataTable[k] = nil
end
end
dataTable.parentTable = parent
dataTable.defaultValues = {}
dataTable.isInitialized = false
dataTable.getParent = function(pSelf)
return pSelf.parentTable
end
dataTable.getParentValue = function(pSelf, pKey)
local vParent = pSelf:getParent()
return vParent[pKey]
end
dataTable.updateDefaultValues = function(pSelf, pReset)
local vParent = pSelf:getParent()
if pReset then
g_thUtils:clearTable(pSelf.defaultValues)
end
for key, val in pairs(vParent) do
local vValType = type(val)
if vValType == "string"
or vValType == "number"
or vValType == "boolean"
or vValType == "function"
then
pSelf.defaultValues[key] = val
end
end
end
dataTable.getDefaultValue = function(pSelf, pKey)
return pSelf.defaultValues[pKey]
end
dataTable.restoreDefaultValue = function(pSelf, pKey)
local vParent = pSelf:getParent()
local vParentValue = rawget(vParent, pKey)
local vDefaultValue = pSelf.defaultValues[pKey]
local vParentValType = type(vParentValue)
if vParentValType == "nil"
or vParentValType == "string"
or vParentValType == "number"
or vParentValType == "boolean"
or vParentValType == "function"
then
if vDefaultValue ~= vParentValue then
rawset(vParent, pKey, vDefaultValue)
end
end
end
dataTable.restoreDefaultValues = function(pSelf)
local vParent = pSelf:getParent()
for key, val in pairs(pSelf.defaultValues) do
rawset(vParent, key, val)
end
end
if upValue == nil then
if clear then
setmetatable(dataTable, nil)
end
else
if g_thUtils:argIsValid(type(upValue) == "table", "upValue", upValue) then
setmetatable(dataTable, {__index = upValue})
end
end
dataTable:updateDefaultValues(true)
if dataTable.initialize ~= nil then
if not dataTable.isInitialized then
if dataTable:initialize(...) then
dataTable.isInitialized = true
end
end
end
end
return dataTable, parent
end
function THCore:getDataTable(parent, create, upValue, ...)
if parent == nil then
return
end
local dataTable = parent[self.dataKey]
if dataTable == nil and create then
dataTable = self:createDataTable(parent, false, upValue, ...)
end
return dataTable, parent
end
function THCore:initializeLoadedMods()
for _, modInfo in ipairs(self.modList) do
local modName = g_thUtils:getNoNil(modInfo.modName, "")
if modName ~= "" then
local modEntry = {
id    = modName:upper(),
info  = modInfo,
name  = modName,
path  = modInfo.modDir,
file  = modInfo.modFile,
index = #self.loadedMods.byIndex + 1,
title = modInfo.title
}
self.loadedMods.byId[modEntry.id] = modEntry
self.loadedMods.byIndex[modEntry.index] = modEntry
if modName == self.modName then
self.modInfo = modEntry
end
if self.mapIsMod and self.mapName ~= nil and modName == self.mapName then
self.mapModInfo = modEntry
end
end
end
end
function THCore:getLoadedMod(modName, verbose, raise)
local valType = type(modName)
local modInfo = nil
if valType == "string" then
modInfo = self.loadedMods.byId[modName:upper()]
elseif modName ~= nil then
verbose = true
end
raise = g_thUtils:getNoNil(raise, verbose)
g_thUtils:msgOnTrue(modInfo == nil and verbose, raise, THUtils.MSG.ARGUMENT_INVALID, "modName", modName)
return modInfo
end
function THCore:getLoadedModList(byId)
if byId == true then
return self.loadedMods.byId
end
return self.loadedMods.byIndex
end
function THCore:initializeSettings()
return true
end
function THCore:loadSettings()
if fileExists(self.settingsXMLFile) then
local baseKey = "settings"
local xmlFile = loadXMLFile("THSettings", self.settingsXMLFile)
if g_thUtils:getNoNil(xmlFile, 0) ~= 0 then
local idx = 0
while true do
local settingKey = string.format("%s.setting(%d)", baseKey, idx)
if not hasXMLProperty(xmlFile, settingKey) then
break
end
local settingName = getXMLString(xmlFile, settingKey.."#name")
local settingInfo = self:getSetting(settingName)
if settingInfo ~= nil then
local valIndex = getXMLInt(xmlFile, settingKey.."#value")
if valIndex ~= nil and settingInfo.values[valIndex] ~= nil then
settingInfo.currentValue = valIndex
settingInfo.changedValue = valIndex
settingInfo.savedValue = valIndex
end
end
idx = idx + 1
end
delete(xmlFile)
end
end
return true
end
function THCore:saveSettings()
local settingsList = self:getSettingsList()
local baseKey = "settings"
local xmlFile = createXMLFile("THSettings", self.settingsXMLFile, baseKey)
if g_thUtils:getNoNil(xmlFile, 0) ~= 0 then
for i, settingInfo in ipairs(settingsList) do
local settingKey = string.format("%s.setting(%d)", baseKey, i-1)
setXMLString(xmlFile, settingKey.."#name",  settingInfo.name)
setXMLInt(xmlFile,    settingKey.."#value", settingInfo.changedValue)
settingInfo.savedValue = settingInfo.changedValue
end
saveXMLFile(xmlFile)
delete(xmlFile)
end
return true
end
function THCore:finalizeSettings()
return true
end
function THCore:addSettingCategory(name, title, customEnv, basePath)
customEnv = g_thUtils:getNoNil(customEnv, self.modName, true)
basePath  = g_thUtils:getNoNil(basePath, self.modPath, true)
local modInfo = self:getLoadedMod(customEnv, true)
if modInfo == nil then
return
end
if  g_thUtils:argIsValid(type(name) == "string", "name", name)
and (title == nil or g_thUtils:argIsValid(type(title) == "string", "title", title))
then
local categoryInfo = self:getSettingCategory(name)
if categoryInfo == nil then
categoryInfo = {
id             = name:upper(),
name           = name,
index          = #self.settingCategories.byIndex + 1,
customEnv      = modInfo.name,
settings       = {},
settingMapping = {}
}
if title == nil or title == "" then
if g_i18n:hasText("thTitle_"..categoryInfo.name, categoryInfo.customEnv) then
categoryInfo.title = g_i18n:getText("thTitle_"..categoryInfo.name, categoryInfo.customEnv)
else
categoryInfo.title = categoryInfo.name
end
else
categoryInfo.title = g_i18n:convertText(title, categoryInfo.customEnv)
end
self.settingCategories.byId[categoryInfo.id] = categoryInfo
self.settingCategories.byIndex[categoryInfo.index] = categoryInfo
self.settingCategories.idToIndex[categoryInfo.id] = categoryInfo.index
end
return categoryInfo
end
end
function THCore:getSettingCategory(target, verbose, raise)
return g_thUtils:getTargetInfo(self, "settingCategories", target, verbose, raise)
end
function THCore:getSettingCategoryList()
return self.settingCategories.byIndex
end
function THCore:addSetting(name, title, toolTip, category, customEnv, basePath, isCheckedOption, restartRequired)
category  = g_thUtils:getNoNil(category, 1)
customEnv = g_thUtils:getNoNil(customEnv, self.modName, true)
basePath  = g_thUtils:getNoNil(basePath, self.modPath, true)
isCheckedOption = g_thUtils:getNoNil(isCheckedOption, false)
restartRequired = g_thUtils:getNoNil(restartRequired, false)
local categoryInfo = self:getSettingCategory(category, true)
local modInfo = self:getLoadedMod(customEnv, true)
if categoryInfo == nil or modInfo == nil then
return
end
if  g_thUtils:argIsValid(type(name) == "string", "name", name)
and (title == nil or g_thUtils:argIsValid(type(title) == "string", "title", title))
and (toolTip == nil or g_thUtils:argIsValid(type(toolTip) == "string", "toolTip", toolTip))
and (not isCheckedOption or g_thUtils:argIsValid(isCheckedOption == true, "isCheckedOption", isCheckedOption))
and (not restartRequired or g_thUtils:argIsValid(restartRequired == true, "restartRequired", restartRequired))
then
local settingInfo = self:getSetting(name)
if settingInfo == nil then
settingInfo = {
id              = name:upper(),
name            = name,
index           = #self.settings.byIndex + 1,
isCheckedOption = false,
restartRequired = restartRequired,
customEnv       = modInfo.name,
values          = {},
valueTexts      = {},
valueMapping    = {},
currentValue    = 0,
changedValue    = 0,
savedValue      = 0,
}
if title == nil or title == "" then
if g_i18n:hasText("thTitle_"..settingInfo.name, settingInfo.customEnv) then
settingInfo.title = g_i18n:getText("thTitle_"..settingInfo.name, settingInfo.customEnv)
else
settingInfo.title = settingInfo.name
end
else
settingInfo.title = g_i18n:convertText(title, settingInfo.customEnv)
end
if toolTip == nil then
if g_i18n:hasText("thTooltip_"..settingInfo.name, settingInfo.customEnv) then
settingInfo.toolTip = g_i18n:getText("thTooltip_"..settingInfo.name, settingInfo.customEnv)
else
settingInfo.toolTip = ""
end
else
settingInfo.toolTip = g_i18n:convertText(toolTip, settingInfo.customEnv)
end
self.settings.byId[settingInfo.id] = settingInfo
self.settings.byIndex[settingInfo.index] = settingInfo
self.settings.idToIndex[settingInfo.id] = settingInfo.index
table.insert(categoryInfo.settings, settingInfo.index)
categoryInfo.settingMapping[settingInfo.index] = #categoryInfo.settings
if isCheckedOption then
if  self:addSettingValue(settingInfo, false, "$l10n_ui_off")
and self:addSettingValue(settingInfo, true, "$l10n_ui_on")
then
settingInfo.isCheckedOption = true
end
end
MessageType.TH_SETTING_CHANGED = g_thUtils:getNoNil(MessageType.TH_SETTING_CHANGED, {})
MessageType.TH_SETTING_CHANGED[settingInfo.id] = nextMessageTypeId()
settingInfo.messageTypeId = MessageType.TH_SETTING_CHANGED[settingInfo.id]
end
return settingInfo
end
end
function THCore:getSetting(target, verbose, raise)
return g_thUtils:getTargetInfo(self, "settings", target, verbose, raise)
end
function THCore:getSettingsList()
return self.settings.byIndex
end
function THCore:addSettingValue(setting, value, title, customEnv, basePath)
customEnv = g_thUtils:getNoNil(customEnv, self.modName, true)
basePath  = g_thUtils:getNoNil(basePath, self.modPath, true)
local settingInfo = self:getSetting(setting, true)
local modInfo = self:getLoadedMod(customEnv, true)
if settingInfo == nil or modInfo == nil then
return false
end
if  g_thUtils:argIsValid(value ~= nil, "value", value)
and g_thUtils:argIsValid(type(title) == "string" and title ~= "", "title", title)
then
if settingInfo.isCheckedOption then
g_thUtils:errorMsg(nil, "Cannot add value to checked setting %q", settingInfo.name)
return false
end
title = g_i18n:convertText(title, customEnv)
local valueFound = false
local titleFound = false
for idx = 1, #settingInfo.values do
local chkValue = settingInfo.values[idx]
local chkTitle = settingInfo.valueTexts[idx]
if not valueFound and value == chkValue then
valueFound = true
end
if not titleFound and title == chkTitle then
titleFound = true
end
if valueFound and titleFound then
break
end
end
if valueFound then
g_thUtils:errorMsg(nil, "Value %q already added to setting %q", value, settingInfo.name)
return false
end
if titleFound then
g_thUtils:errorMsg(nil, "Title %q already added to setting %q", title, settingInfo.name)
return false
end
local valueIndex = #settingInfo.values + 1
settingInfo.values[valueIndex] = value
settingInfo.valueTexts[valueIndex] = title
settingInfo.valueMapping[value] = valueIndex
if valueIndex == 1 then
settingInfo.currentValue = 1
settingInfo.changedValue = 1
settingInfo.savedValue = 1
end
return true
end
return false
end
function THCore:getSettingValue(setting, getChanged, verbose, raise)
local settingInfo = self:getSetting(setting, verbose, raise)
if settingInfo ~= nil then
local valueIndex = settingInfo.currentValue
if getChanged then
valueIndex = settingInfo.changedValue
end
local retValue = settingInfo.values[valueIndex]
if retValue == nil and verbose == true then
raise = g_thUtils:getNoNil(raise, verbose)
g_thUtils:errorMsg(raise, "Setting %q, return value not found", settingInfo.name)
end
return retValue
end
end
function THCore:loadConfiguration(typeKey, xmlSchema)
if g_thUtils:argIsValid(g_thUtils:getIsType(xmlSchema, XMLSchema), "xmlSchema", xmlSchema) then
local typeKeyProper = g_thUtils:properCase(typeKey)
local typeFilename = typeKey..".xml"
local loadFunc = self["load"..typeKeyProper.."FromXMLFile"]
local sdkFilename = self.sdkPath.."xml/"..typeFilename
if fileExists(sdkFilename) then
copyFile(sdkFilename, self.modSettingsPath..typeFilename, false)
end
local dataFilename, dataPath, dataModName = self:getConfigFile(typeFilename)
if dataFilename ~= nil then
local dataXMLFile = XMLFile.loadIfExists("THModData", dataFilename, xmlSchema)
if g_thUtils:getNoNil(dataXMLFile, 0) ~= 0 then
loadFunc(self, dataXMLFile, dataModName, dataPath)
dataXMLFile:delete()
end
end
return true
end
return false
end
function THCore:getConfigFile(target)
local filename, basePath, modName = nil,nil,nil
if g_thModSettings ~= nil then
filename, basePath, modName = g_thModSettings:getConfigFile(target)
if filename ~= nil then
return filename, basePath, modName
end
end
if self.mapSettingsPath ~= nil then
filename = g_thUtils:getFilename(target, self.mapSettingsPath)
if filename ~= nil and fileExists(filename) then
return filename, self.mapSettingsPath
end
end
filename = g_thUtils:getFilename(target, self.modSettingsPath)
if filename ~= nil and fileExists(filename) then
return filename, self.modSettingsPath
end
end
function THCore:addSpecialization(typeName, specName, className, parentName, filename)
local modName = self.modName
local modPath = self.modPath
local specManager = nil
if type(typeName) == "string" then
typeName = THCore.SPEC_TYPE[typeName:upper()]
end
if typeName == THCore.SPEC_TYPE.VEHICLE then
specManager = g_specializationManager
elseif typeName == THCore.SPEC_TYPE.PLACEABLE then
specManager = g_placeableSpecializationManager
else
g_thUtils:errorMsg(nil, THUtils.MSG.ARGUMENT_INVALID, "typeName", typeName)
return
end
local internalSpecName = modName.."."..specName
local specEntry = specManager:getSpecializationByName(internalSpecName)
local parentSpecEntry = nil
filename = modPath..filename
if parentName ~= nil then
parentSpecEntry = specManager:getSpecializationByName(parentName)
if parentSpecEntry == nil then
g_thUtils:errorMsg(nil, "Parent specialization %q not found", parentName)
return
end
parentName = parentSpecEntry.name
end
if  g_thUtils:assert(fileExists(filename), nil, "Cannot load filename %s", filename)
and g_thUtils:assert(specEntry == nil, nil, "Specialization %q already exists", specName)
then
local specInfo = self:getSpecialization(specName)
if specInfo == nil then
specInfo = {
id    = specName:upper(),
name  = specName,
type  = typeName,
index = #self.specializations.byIndex + 1,
parentName = parentName,
parentEntry = parentSpecEntry
}
specManager:addSpecialization(specName, className, filename, modName)
specEntry = specManager:getSpecializationByName(internalSpecName)
local specClass = _G[className]
if g_thUtils:msgOnTrue(specEntry == nil, nil, "Specialization %q was not added correctly", specName)
or g_thUtils:msgOnTrue(specClass == nil, nil, THUtils.MSG.ARGUMENT_INVALID, "className", className)
then
return
end
specInfo.entry = specEntry
specInfo.class = specClass
self.specializations.byId[specInfo.id] = specInfo
self.specializations.byIndex[specInfo.index] = specInfo
self.specializations.idToIndex[specInfo.id] = specInfo.index
table.insert(self.specializations.byType[specInfo.type], specInfo)
end
return specInfo
end
end
function THCore:getSpecialization(target, verbose, raise)
return g_thUtils:getTargetInfo(self, "specializations", target, verbose, raise)
end
function THCore:getSpecializationsList()
return self.specializations.byIndex
end
function THCore:getSpecializationsByType(typeName)
if type(typeName) == "string" then
typeName = THCore.SPEC_TYPE[typeName:upper()]
end
if g_thUtils:argIsValid(typeName ~= nil, "typeName", typeName) then
return self.specializations.byType[typeName]
end
end
function THCore:getSpecTable(target, specName, modName)
if modName == nil or modName == true then
modName = self.modName
end
if modName ~= false then
specName = modName.."."..specName
end
return target["spec_"..specName]
end