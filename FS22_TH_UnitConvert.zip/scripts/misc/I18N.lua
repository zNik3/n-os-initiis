-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THI18N = {}
function THI18N:hook_formatNumber(superFunc, value, precision, forcePrecision, extraArg1, extraArg2, ...)
local function prependFunc()
local minPrecision, maxPrecision, threshold = nil,nil,nil
if type(forcePrecision) == "number" then
minPrecision   = g_thUtils:getNoNil(precision, 0)
maxPrecision   = math.max(0, forcePrecision)
forcePrecision = extraArg1
threshold      = g_thUtils:getNoNil(extraArg2, 0)
if minPrecision > maxPrecision then
local oldMinPrecision = minPrecision
minPrecision = maxPrecision
maxPrecision = oldMinPrecision
end
end
if type(value) == "number" then
if maxPrecision ~= nil and maxPrecision > minPrecision then
value = g_thUtils:round(value, maxPrecision)
local absValue = math.abs(value)
local absThreshold = math.abs(threshold)
if absValue >= absThreshold then
local precisionOffset = string.len(math.floor(absValue)) - string.len(math.floor(threshold))
precisionOffset = MathUtil.clamp(precisionOffset, 0, maxPrecision)
precision = math.floor(math.max(0, minPrecision, maxPrecision - precisionOffset))
else
precision = math.floor(maxPrecision)
end
elseif precision ~= nil then
value = g_thUtils:round(value, precision)
end
end
end
g_thMain:call(prependFunc)
local function appendFunc(valueText, ...)
local protectedChunk = function()
if type(valueText) == "string" and forcePrecision == true and g_thUtils:getNoNil(precision, 0) > 0 then
local _, _, decimalSymbol, decimalText = string.find(valueText, "(["..self.decimalSeparator.."])(%d*)")
if decimalText == nil then
if decimalSymbol == nil then
valueText = valueText..self.decimalSeparator..string.rep("0", precision)
else
valueText = valueText..string.rep("0", precision)
end
else
local decimalLength = decimalText:len()
if precision > decimalLength then
valueText = valueText..string.rep("0", precision - decimalLength)
end
end
end
end
g_thMain:call(protectedChunk)
return valueText, ...
end
return appendFunc(superFunc(self, value, precision, forcePrecision, extraArg1, extraArg2, ...))
end
function THI18N:hook_formatVolume(superFunc, value, precision, unit, extraArg1, extraArg2, fillTypeList, unitIndex, maxUnitIndex, unitSet)
local _, formatNumberFunc, oldFormatNumberFunc = nil,nil,nil
local function prependFunc()
local unitInfo, unitFactor, unitPrecision = nil,nil,nil
if type(fillTypeList) == "boolean" then
unitInfo, unitFactor, unitPrecision = g_thMain:getDefaultUnitData(g_thMain.UNIT_TYPE.VOLUME, unitIndex, unitSet)
elseif fillTypeList ~= nil then
unitInfo, unitFactor, unitPrecision = g_thMain:getFillTypeUnitData(fillTypeList, unitIndex, maxUnitIndex, unitSet)
end
if unitInfo ~= nil then
local minPrecision = g_thUtils:getNoNil(precision, unitPrecision)
local maxPrecision = math.max(minPrecision, unitPrecision)
local forcePrecision = extraArg1
local threshold = extraArg2
local function hook_formatNumber(pSuperFunc, pSelf, pValue, p1, p2, p3, p4, ...)
p1 = minPrecision
p2 = maxPrecision
p3 = forcePrecision
p4 = threshold
return pSuperFunc(pSelf, pValue, p1, p2, p3, p4, ...)
end
_, formatNumberFunc, oldFormatNumberFunc = g_thUtils:hookFunction(self, "formatNumber", hook_formatNumber)
value = value * unitFactor
unit = g_thUtils:getNoNil(unit, self:getVolumeUnit())
local unitTitleInfo = g_thMain:getUnitTitleInfo(unit)
local isTitleShort = true
if unitTitleInfo ~= nil then
isTitleShort = unitTitleInfo.isTitleShort
end
if isTitleShort then
unit = unitInfo.titleShort
else
unit = unitInfo.title
end
else
unit = ""
end
return true
end
local prependSuccess = g_thMain:call(prependFunc)
local function appendFunc(valueText, ...)
if formatNumberFunc ~= nil then rawset(self, "formatNumber", oldFormatNumberFunc) end
local protectedChunk = function()
if prependSuccess then
if type(valueText) == "string" then
valueText = valueText:gsub(" +$", "")
end
end
end
g_thMain:call(protectedChunk)
return valueText, ...
end
return appendFunc(superFunc(self, value, precision, unit, extraArg1, extraArg2))
end
function THI18N:hook_formatMass(superFunc, value, maxValue, showKg, extraArg1, extraArg2, extraArg3, fillTypeList, unitIndex, maxUnitIndex, unitSet)
local _ = nil
local formatNumberFunc, oldFormatNumberFunc = nil,nil
local getTextFunc, oldGetTextFunc = nil,nil
local function prependFunc()
local unitInfo, unitFactor, unitPrecision, maxFillTypeMass = nil,nil,nil,nil
if type(fillTypeList) == "boolean" then
unitInfo, unitFactor, unitPrecision = g_thMain:getDefaultUnitData(g_thMain.UNIT_TYPE.WEIGHT, unitIndex, unitSet)
elseif fillTypeList ~= nil then
unitInfo, unitFactor, unitPrecision, _,_, maxFillTypeMass = g_thMain:getFillTypeUnitData(fillTypeList, unitIndex, maxUnitIndex, unitSet, g_thMain.UNIT_TYPE.WEIGHT)
end
if unitInfo ~= nil then
local minPrecision = g_thUtils:getNoNil(extraArg1, unitPrecision)
local maxPrecision = math.max(minPrecision, unitPrecision)
local forcePrecision = extraArg2
local threshold = extraArg3
local valFactor = 10 ^ maxPrecision
if maxFillTypeMass == nil then
value = (value * 1000) * valFactor * unitFactor
if maxValue ~= nil then
maxValue = (maxValue * 1000) * valFactor * unitFactor
end
elseif maxFillTypeMass == 0 then
value = 0
if maxValue ~= nil then
maxValue = 0
end
else
value = ((value * 1000) / maxFillTypeMass) * valFactor * unitFactor
if maxValue ~= nil then
maxValue = ((maxValue * 1000) / maxFillTypeMass) * valFactor * unitFactor
end
end
local function hook_formatNumber(pSuperFunc, pSelf, pValue, p1, p2, p3, p4, ...)
local function vPrependFunc()
if valFactor ~= 0 then
pValue = pValue / valFactor
end
p1 = minPrecision
p2 = maxPrecision
p3 = forcePrecision
p4 = threshold
end
g_thMain:call(vPrependFunc)
return pSuperFunc(pSelf, pValue, p1, p2, p3, p4, ...)
end
local function hook_getText(pSuperFunc, pSelf, pKey, ...)
if pKey == "unit_tonsShort" then
return unitInfo.titleShort
end
return pSuperFunc(pSelf, pKey, ...)
end
_, formatNumberFunc, oldFormatNumberFunc = g_thUtils:hookFunction(self, "formatNumber", hook_formatNumber)
_, getTextFunc, oldGetTextFunc = g_thUtils:hookFunction(self, "getText", hook_getText)
showKg = false
end
end
local function appendFunc(valueText, ...)
if formatNumberFunc ~= nil then rawset(self, "formatNumber", oldFormatNumberFunc) end
if getTextFunc ~= nil then rawset(self, "getText", oldGetTextFunc) end
return valueText, ...
end
g_thMain:call(prependFunc)
return appendFunc(superFunc(self, value, maxValue, showKg, extraArg1, extraArg2, extraArg3))
end
function THI18N:hook_formatMoney(superFunc, value, precision, addCurrency, currencySymbol, ...)
local _, formatNumberFunc, oldFormatNumberFunc = nil,nil,nil
local function prependFunc()
local function hook_formatNumber(pSuperFunc, pSelf, pValue, pPrecision, pForcePrecision, ...)
if g_thUtils:getNoNil(pPrecision, 0) > 0 then
pForcePrecision = true
end
return pSuperFunc(pSelf, pValue, pPrecision, pForcePrecision, ...)
end
_, formatNumberFunc, oldFormatNumberFunc = g_thUtils:hookFunction(self, "formatNumber", hook_formatNumber)
end
local function appendFunc(valueText, ...)
if formatNumberFunc ~= nil then rawset(self, "formatNumber", oldFormatNumberFunc) end
return valueText, ...
end
g_thMain:call(prependFunc)
return appendFunc(superFunc(self, value, precision, addCurrency, currencySymbol, ...))
end
local function runScript()
g_thMain:setProtectedHook("I18N", "formatNumber", THI18N)
g_thMain:setProtectedHook("I18N", "formatVolume", THI18N)
g_thMain:setProtectedHook("I18N", "formatMass",   THI18N)
g_thMain:setProtectedHook("I18N", "formatMoney",  THI18N)
end
g_thMain:call(runScript)