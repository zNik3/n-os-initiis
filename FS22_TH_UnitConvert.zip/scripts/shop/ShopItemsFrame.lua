-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THShopItemsFrame = {}
THShopItemsFrame.ATTRIBUTE_PROFILE = {
CAPACITY = "shopListAttributeIconCapacity"
}
function THShopItemsFrame:initialize()
self.actionEventIds = {}
return true
end
function THShopItemsFrame:updateDisplayItemAttributes(displayItem)
local shopItemsFrame = self:getParent()
if displayItem == nil then
displayItem = shopItemsFrame:getSelectedDisplayItem()
end
local displayItemData = g_thMain:getDataTable(displayItem)
if displayItemData ~= nil then
if displayItemData:updateAttributeValues() then
shopItemsFrame:updateItemAttributeData()
return true
end
end
return false
end
function THShopItemsFrame:registerActionEvents()
if g_thMain.isClient then
self:unregisterActionEvents()
local contextName = Gui.INPUT_CONTEXT_MENU
local actionEventIds = self.actionEventIds
g_inputBinding:beginActionEventsModification(contextName)
local _, eventId = g_inputBinding:registerActionEvent(InputAction.UC_SELECT_UNIT, self, self.onActionSelectUnit, false, true, false, true)
g_inputBinding:setActionEventTextVisibility(eventId, false)
g_inputBinding:setActionEventTextPriority(eventId, GS_PRIO_VERY_LOW)
actionEventIds.selectUnit = eventId
g_inputBinding:endActionEventsModification()
end
end
function THShopItemsFrame:unregisterActionEvents()
if g_thMain.isClient then
for _, eventId in pairs(self.actionEventIds) do
g_inputBinding:removeActionEvent(eventId)
end
g_thUtils:clearTable(self.actionEventIds)
end
end
function THShopItemsFrame:subscribeMessageCenterEvents()
self:unsubscribeMessageCenterEvents()
g_messageCenter:subscribe(MessageType.TH_SETTING_CHANGED.CURRENTUNITSET, self.onUnitSetChanged, self)
end
function THShopItemsFrame:unsubscribeMessageCenterEvents()
g_messageCenter:unsubscribe(MessageType.TH_SETTING_CHANGED.CURRENTUNITSET, self)
end
function THShopItemsFrame:onActionSelectUnit()
local function protectedFunc()
local shopItemsFrame = self:getParent()
local displayItem = shopItemsFrame:getSelectedDisplayItem()
if displayItem ~= nil then
local storeItemData = g_thMain:getDataTable(displayItem.storeItem)
if storeItemData ~= nil then
local currentUnit, maxNumUnits = storeItemData:getUnitSelectionValues()
if maxNumUnits > 0 then
currentUnit = math.max(currentUnit, 1) + 1
if currentUnit > maxNumUnits then
currentUnit = 1
end
else
currentUnit = 0
end
storeItemData:setCurrentUnit(currentUnit)
self:updateDisplayItemAttributes(displayItem)
end
end
end
g_thMain:call(protectedFunc)
end
function THShopItemsFrame:onUnitSetChanged()
local function protectedFunc()
self:updateDisplayItemAttributes()
end
g_thMain:call(protectedFunc)
end
function THShopItemsFrame:hook_onFrameOpen(superFunc, ...)
local envData = g_thMain:call("getDataTable", self, true, THShopItemsFrame)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
envData:registerActionEvents()
envData:subscribeMessageCenterEvents()
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
function THShopItemsFrame:hook_onFrameClose(superFunc, ...)
local envData = g_thMain:call("getDataTable", self)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
envData:unregisterActionEvents()
envData:unsubscribeMessageCenterEvents()
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
local function runScript()
g_thMain:setProtectedHook("ShopItemsFrame", "onFrameOpen",  THShopItemsFrame)
g_thMain:setProtectedHook("ShopItemsFrame", "onFrameClose", THShopItemsFrame)
end
g_thMain:call(runScript)