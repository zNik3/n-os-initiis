-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THConstructionScreen = {}
function THConstructionScreen:initialize()
self.actionEventIds = {}
return true
end
function THConstructionScreen:getSelectedItem()
local envParent = self:getParent()
if envParent.items ~= nil then
local selectedCategory = g_thUtils:getNoNil(envParent.currentCategory, 0)
local selectedTab = g_thUtils:getNoNil(envParent.currentTab, 0)
local selectedIndex = g_thUtils:getNoNil(envParent.itemList.selectedIndex, 0)
if selectedCategory > 0 and selectedTab > 0 and selectedIndex > 0 then
if  envParent.items[selectedCategory] ~= nil
and envParent.items[selectedCategory][selectedTab] ~= nil
then
return envParent.items[selectedCategory][selectedTab][selectedIndex]
end
end
end
end
function THConstructionScreen:updateDisplayItemAttributes(displayItem)
local envParent = self:getParent()
if displayItem == nil then
local selectedItem = self:getSelectedItem()
if selectedItem ~= nil then
displayItem = selectedItem.displayItem
end
end
local displayItemData = g_thMain:getDataTable(displayItem)
if displayItemData ~= nil then
if displayItemData:updateAttributeValues() then
envParent:refreshDetails()
return true
end
end
return false
end
function THConstructionScreen:registerActionEvents()
if g_thMain.isClient then
self:unregisterActionEvents()
local contextName = ConstructionScreen.INPUT_CONTEXT
local actionEventIds = self.actionEventIds
g_inputBinding:beginActionEventsModification(contextName)
local _, eventId = g_inputBinding:registerActionEvent(InputAction.UC_SELECT_UNIT, self, self.onActionSelectUnit, false, true, false, true)
g_inputBinding:setActionEventTextVisibility(eventId, false)
g_inputBinding:setActionEventTextPriority(eventId, GS_PRIO_VERY_LOW)
actionEventIds.selectUnit = eventId
g_inputBinding:endActionEventsModification()
end
end
function THConstructionScreen:unregisterActionEvents()
if g_thMain.isClient then
for _, eventId in pairs(self.actionEventIds) do
g_inputBinding:removeActionEvent(eventId)
end
g_thUtils:clearTable(self.actionEventIds)
end
end
function THConstructionScreen:subscribeMessageCenterEvents()
self:unsubscribeMessageCenterEvents()
g_messageCenter:subscribe(MessageType.TH_SETTING_CHANGED.CURRENTUNITSET, self.onUnitSetChanged, self)
end
function THConstructionScreen:unsubscribeMessageCenterEvents()
g_messageCenter:unsubscribe(MessageType.TH_SETTING_CHANGED.CURRENTUNITSET, self)
end
function THConstructionScreen:onActionSelectUnit()
local function protectedFunc()
local selectedItem = self:getSelectedItem()
if selectedItem ~= nil then
local storeItemData = g_thMain:getDataTable(selectedItem.storeItem)
if storeItemData ~= nil then
local currentUnit, maxNumUnits = storeItemData:getUnitSelectionValues()
if maxNumUnits > 0 then
currentUnit = math.max(currentUnit, 1) + 1
if currentUnit > maxNumUnits then
currentUnit = 1
end
else
currentUnit = 0
end
storeItemData:setCurrentUnit(currentUnit)
self:updateDisplayItemAttributes(selectedItem.displayItem)
end
end
end
g_thMain:call(protectedFunc)
end
function THConstructionScreen:onUnitSetChanged()
local function protectedFunc()
self:updateDisplayItemAttributes()
end
g_thMain:call(protectedFunc)
end
function THConstructionScreen:hook_onOpen(superFunc, ...)
local envData = g_thMain:call("getDataTable", self, true, THConstructionScreen)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
envData:registerActionEvents()
envData:subscribeMessageCenterEvents()
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
function THConstructionScreen:hook_onClose(superFunc, ...)
local envData = g_thMain:call("getDataTable", self)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
envData:unregisterActionEvents()
envData:unsubscribeMessageCenterEvents()
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
local function runScript()
local gui_constructionScreen = g_gui.guis["ConstructionScreen"]
g_thMain:setProtectedHook(gui_constructionScreen, "onOpenCallback",  THConstructionScreen, "hook_onOpen")
g_thMain:setProtectedHook(gui_constructionScreen, "onCloseCallback", THConstructionScreen, "hook_onClose")
end
g_thMain:call(runScript)