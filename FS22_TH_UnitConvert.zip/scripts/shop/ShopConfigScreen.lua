-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THShopConfigScreen = {}
function THShopConfigScreen:initialize()
self.actionEventIds = {}
self.attributeValues = {}
return true
end
function THShopConfigScreen:registerActionEvents()
if g_thMain.isClient then
self:unregisterActionEvents()
local contextName = ShopConfigScreen.INPUT_CONTEXT_NAME
local actionEventIds = self.actionEventIds
g_inputBinding:beginActionEventsModification(contextName)
local _, eventId = g_inputBinding:registerActionEvent(InputAction.UC_SELECT_UNIT, self, self.onActionSelectUnit, false, true, false, true)
g_inputBinding:setActionEventTextVisibility(eventId, false)
g_inputBinding:setActionEventTextPriority(eventId, GS_PRIO_VERY_LOW)
actionEventIds.selectUnit = eventId
g_inputBinding:endActionEventsModification()
end
end
function THShopConfigScreen:unregisterActionEvents()
if g_thMain.isClient then
for _, eventId in pairs(self.actionEventIds) do
g_inputBinding:removeActionEvent(eventId)
end
g_thUtils:clearTable(self.actionEventIds)
end
end
function THShopConfigScreen:subscribeMessageCenterEvents()
self:unsubscribeMessageCenterEvents()
g_messageCenter:subscribe(MessageType.TH_SETTING_CHANGED.CURRENTUNITSET, self.onUnitSetChanged, self)
end
function THShopConfigScreen:unsubscribeMessageCenterEvents()
g_messageCenter:unsubscribe(MessageType.TH_SETTING_CHANGED.CURRENTUNITSET, self)
end
function THShopConfigScreen:onActionSelectUnit()
local function protectedFunc()
local configScreen = self:getParent()
local storeItem = configScreen.storeItem
local saleItem = configScreen.saleItem
local vehicle = configScreen.vehicle
local storeItemData = g_thMain:getDataTable(storeItem)
if storeItemData ~= nil then
local currentUnit, maxNumUnits = storeItemData:getUnitSelectionValues()
if maxNumUnits > 0 then
currentUnit = math.max(currentUnit, 1) + 1
if currentUnit > maxNumUnits then
currentUnit = 1
end
else
currentUnit = 0
end
storeItemData:setCurrentUnit(currentUnit)
configScreen:updateData(storeItem, vehicle, saleItem)
end
end
g_thMain:call(protectedFunc)
end
function THShopConfigScreen:onUnitSetChanged()
local function protectedFunc()
local configScreen = self:getParent()
local storeItem = configScreen.storeItem
local saleItem = configScreen.saleItem
local vehicle = configScreen.vehicle
configScreen:updateData(storeItem, vehicle, saleItem)
end
g_thMain:call(protectedFunc)
end
function THShopConfigScreen:hook_onOpen(superFunc, ...)
local envData = g_thMain:call("getDataTable", self, true, THShopConfigScreen)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
envData:registerActionEvents()
envData:subscribeMessageCenterEvents()
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
function THShopConfigScreen:hook_onClose(superFunc, ...)
local envData = g_thMain:call("getDataTable", self)
local function appendFunc(...)
local protectedChunk = function()
if envData ~= nil then
envData:unregisterActionEvents()
envData:unsubscribeMessageCenterEvents()
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
function THShopConfigScreen:hook_processAttributeData(superFunc, storeItem, vehicle, saleItem, ...)
local storeItemData = g_thMain:call("getDataTable", storeItem)
local attributesLayout, invalidateLayoutFunc, oldInvalidateLayoutFunc = nil,nil,nil
local function prependFunc()
attributesLayout, invalidateLayoutFunc, oldInvalidateLayoutFunc = g_thUtils:getFunctionData(self.attributesLayout, "invalidateLayout")
rawset(attributesLayout, "invalidateLayout", function(...) end)
end
g_thMain:call(prependFunc)
local function appendFunc(...)
if invalidateLayoutFunc ~= nil then rawset(attributesLayout, "invalidateLayout", oldInvalidateLayoutFunc) end
local protectedChunk = function()
if attributesLayout.elements ~= nil then
for _, attrElement in pairs(attributesLayout.elements) do
local iconElement = attrElement:getDescendantByName("icon")
local textElement = attrElement:getDescendantByName("text")
if iconElement ~= nil and textElement ~= nil then
local attrProfile = iconElement.profile
local attrText = textElement:getText()
local newAttrText = nil
if attrProfile == ShopConfigScreen.GUI_PROFILE.CAPACITY then
local capacityValues = g_thUtils:getNumericValues(attrText)
local minCapacity = capacityValues[1]
local maxCapacity = capacityValues[2]
newAttrText = storeItemData:formatCapacity(minCapacity, maxCapacity)
elseif attrProfile == ShopConfigScreen.GUI_PROFILE.FUEL then
local fuelCapacityValues = g_thUtils:getNumericValues(attrText)
local fuelCapacity = fuelCapacityValues[1]
local defCapacity = fuelCapacityValues[2]
newAttrText = storeItemData:formatFuelCapacity(fuelCapacity, defCapacity, FillType.DIESEL)
end
if newAttrText ~= nil then
textElement:setText(newAttrText)
end
end
end
end
end
g_thMain:call(protectedChunk)
if invalidateLayoutFunc ~= nil then
attributesLayout:invalidateLayout()
end
return ...
end
return appendFunc(superFunc(self, storeItem, vehicle, saleItem, ...))
end
local function runScript()
local gui_shopConfigScreen = g_gui.guis["ShopConfigScreen"]
g_thMain:setProtectedHook(gui_shopConfigScreen, "onOpenCallback",  THShopConfigScreen, "hook_onOpen")
g_thMain:setProtectedHook(gui_shopConfigScreen, "onCloseCallback", THShopConfigScreen, "hook_onClose")
g_thMain:setProtectedHook("ShopConfigScreen", "processAttributeData", THShopConfigScreen)
end
g_thMain:call(runScript)