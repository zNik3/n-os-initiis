-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THStoreManager = {}
function THStoreManager:initialize()
return true
end
function THStoreManager:initializeStoreItems()
local storeManager = self:getParent()
local storeItemList = storeManager:getItems()
for _, storeItem in pairs(storeItemList) do
g_thMain:createDataTable(storeItem, true, THStoreItem)
end
end