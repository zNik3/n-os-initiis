-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THShopController = {}
function THShopController:hook_makeDisplayItem(superFunc, storeItem, realItem, configurations, saleItem, ...)
local storeManager, getSpecTypeByNameFunc, oldGetSpecTypeByNameFunc = nil,nil,nil
local capacityFillTypes, numCapacityFillTypes = {}, 0
local changedSpecTypes = {}
local function addCapacityFillType(pFillType)
local vFillTypeInfo = g_thUtils:getFillType(pFillType)
if vFillTypeInfo ~= nil and vFillTypeInfo.index ~= FillType.UNKNOWN then
if not capacityFillTypes[vFillTypeInfo.name] then
capacityFillTypes[vFillTypeInfo.name] = true
numCapacityFillTypes = numCapacityFillTypes + 1
end
end
end
local function prependFunc()
local function hook_getSpecValueFillTypes(pSuperFunc, pSpecTypeId, pStoreItem, pRealItem, ...)
local function vAppendFunc(vFillTypeList, ...)
local protectedChunk = function()
if vFillTypeList ~= nil then
if g_thUtils:getTableIsArray(vFillTypeList) then
for _, vFillType in pairs(vFillTypeList) do
addCapacityFillType(vFillType)
end
else
for vFillType in pairs(vFillTypeList) do
addCapacityFillType(vFillType)
end
end
end
end
g_thMain:call(protectedChunk)
if  pSpecTypeId ~= "UCSILOFILLTYPES"
and pSpecTypeId ~= "UCSILOEXTENSIONFILLTYPES"
then
return vFillTypeList, ...
end
end
return vAppendFunc(pSuperFunc(pStoreItem, pRealItem, ...))
end
local function hook_getSpecTypeByName(pSuperFunc, pSelf, pSpecName, ...)
local function vAppendFunc(vSpecTypeDesc, ...)
local vProtectedChunk = function()
if vSpecTypeDesc ~= nil and type(pSpecName) == "string" then
local vSpecTypeData = g_thMain:getDataTable(vSpecTypeDesc, true)
local vSpecTypeId = pSpecName:upper()
if changedSpecTypes[vSpecTypeId] == nil then
if vSpecTypeId == "FILLTYPES"
or vSpecTypeId == "UCSILOFILLTYPES"
or vSpecTypeId == "UCSILOEXTENSIONFILLTYPES"
then
local oldGetValueFunc = rawget(vSpecTypeDesc, "getValueFunc")
if type(oldGetValueFunc) == "function" then
rawset(vSpecTypeDesc, "getValueFunc", function(...)
return hook_getSpecValueFillTypes(oldGetValueFunc, vSpecTypeId, ...)
end)
changedSpecTypes[vSpecTypeId] = vSpecTypeData
end
end
if vSpecTypeId == "CAPACITY"
or vSpecTypeId == "SILOVOLUME"
or vSpecTypeId == "SILOEXTENSIONVOLUME"
or vSpecTypeId == "MANUREHEAPCAPACITY"
or vSpecTypeId == "FUEL"
then
vSpecTypeDesc.profile = vSpecTypeDesc.name
changedSpecTypes[vSpecTypeId] = vSpecTypeData
end
end
end
end
g_thMain:call(vProtectedChunk)
return vSpecTypeDesc, ...
end
return vAppendFunc(pSuperFunc(pSelf, pSpecName, ...))
end
storeManager, getSpecTypeByNameFunc, oldGetSpecTypeByNameFunc = g_thUtils:hookFunction(self.storeManager, "getSpecTypeByName", hook_getSpecTypeByName)
end
local function appendFunc(displayItem, ...)
if getSpecTypeByNameFunc ~= nil then rawset(storeManager, "getSpecTypeByName", oldGetSpecTypeByNameFunc) end
for _, specTypeData in pairs(changedSpecTypes) do
specTypeData:restoreDefaultValue("profile")
specTypeData:restoreDefaultValue("getValueFunc")
end
local protectedChunk = function()
if displayItem ~= nil then
local displayItemData = g_thMain:createDataTable(displayItem, true, THShopDisplayItem)
local attrProfileList = displayItem.attributeIconProfiles
local attrValueList = displayItem.attributeValues
local attributesDirty = false
if attrProfileList ~= nil and attrValueList ~= nil then
if #attrProfileList > 0 then
for idx = 1, #attrProfileList do
local specTypeName = attrProfileList[idx]
if type(specTypeName) == "string" then
local specTypeId = specTypeName:upper()
local specTypeData = changedSpecTypes[specTypeId]
if specTypeData ~= nil then
local attrValue = attrValueList[idx]
if attrValue ~= nil then
local valueInfo = nil
if specTypeId == "CAPACITY"
or specTypeId == "SILOVOLUME"
or specTypeId == "SILOEXTENSIONVOLUME"
or specTypeId == "MANUREHEAPCAPACITY"
or specTypeId == "FUEL"
then
local capacityValues = g_thUtils:getNumericValues(attrValue)
valueInfo = {
capacity = capacityValues[1]
}
if specTypeId == "CAPACITY" then
valueInfo.maxCapacity = capacityValues[2]
elseif specTypeId == "FUEL" then
valueInfo.defCapacity = capacityValues[2]
end
end
if valueInfo ~= nil then
valueInfo.attrTable    = attrValueList
valueInfo.attrIndex    = idx
valueInfo.specTypeId   = specTypeId
valueInfo.specTypeName = specTypeName
table.insert(displayItemData.attributeValues, valueInfo)
attributesDirty = true
if specTypeId == "MANUREHEAPCAPACITY" then
addCapacityFillType(FillType.MANURE)
end
end
end
attrProfileList[idx] = specTypeData:getDefaultValue("profile")
end
end
end
end
end
local storeItemData = g_thMain:getDataTable(displayItem.storeItem)
if storeItemData ~= nil then
storeItemData.capacityFillTypes = capacityFillTypes
storeItemData.numCapacityFillTypes = numCapacityFillTypes
storeItemData:updateUnitSelectionValues()
end
if attributesDirty then
displayItemData:updateAttributeValues()
end
end
end
g_thMain:call(protectedChunk)
return displayItem, ...
end
g_thMain:call(prependFunc)
return appendFunc(superFunc(self, storeItem, realItem, configurations, saleItem, ...))
end
THShopDisplayItem = {}
function THShopDisplayItem:initialize()
self.attributeValues = {}
return true
end
function THShopDisplayItem:updateAttributeValues()
local displayItem = self:getParent()
local storeItemData = g_thMain:getDataTable(displayItem.storeItem)
local success = false
if storeItemData ~= nil then
if #self.attributeValues > 0 then
for idx = 1, #self.attributeValues do
local attrValueInfo = self.attributeValues[idx]
local specTypeId = attrValueInfo.specTypeId
local valueTable = attrValueInfo.attrTable
local valueIndex = attrValueInfo.attrIndex
local capacity   = attrValueInfo.capacity
if capacity ~= nil and capacity >= 0 then
local valueText = nil
if specTypeId == "FUEL" then
local defCapacity = attrValueInfo.defCapacity
valueText = storeItemData:formatFuelCapacity(capacity, defCapacity, FillType.DIESEL)
else
local maxCapacity = attrValueInfo.maxCapacity
valueText = storeItemData:formatCapacity(capacity, maxCapacity)
end
if valueText ~= nil then
valueTable[valueIndex] = valueText
success = true
end
end
end
end
end
return success
end
THStoreItem = {}
function THStoreItem:initialize()
self.currentUnit = {}
self.maxNumUnits = {}
self.capacityFillTypes = {}
self.numCapacityFillTypes = 0
for _, unitSetIndex in pairs(g_thMain.UNIT_SET) do
self.currentUnit[unitSetIndex] = 0
self.maxNumUnits[unitSetIndex] = 0
end
return true
end
function THStoreItem:getCapacityFillTypes()
return self.capacityFillTypes, self.numCapacityFillTypes
end
function THStoreItem:updateUnitSelectionValues(unitSet)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local capacityFillTypes, numCapacityFillTypes = self:getCapacityFillTypes()
local currentUnit = self.currentUnit[unitSetIndex]
local maxNumUnits = 0
if numCapacityFillTypes > 0 then
maxNumUnits = g_thMain:getFillTypeMaxNumUnits(capacityFillTypes, unitSetIndex, nil, true)
end
if maxNumUnits > 0 then
if currentUnit <= 0 or currentUnit > maxNumUnits then
currentUnit = 1
end
else
currentUnit = 0
end
self.currentUnit[unitSetIndex] = currentUnit
self.maxNumUnits[unitSetIndex] = maxNumUnits
return currentUnit, maxNumUnits
end
function THStoreItem:getUnitSelectionValues(unitSet)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local currentUnit = self.currentUnit[unitSetIndex]
local maxNumUnits = self.maxNumUnits[unitSetIndex]
return currentUnit, maxNumUnits
end
function THStoreItem:setCurrentUnit(value, unitSet)
local unitSetIndex = g_thMain:getTargetOrCurrentUnitSet(unitSet)
local currentUnit = self.currentUnit[unitSetIndex]
local maxNumUnits = self.maxNumUnits[unitSetIndex]
if g_thUtils:argIsValid(type(value) == "number", "value", value) then
value = math.floor(math.max(value, 0))
if maxNumUnits > 0 then
if value <= 0 or value > maxNumUnits then
value = 1
end
else
value = 0
end
self.currentUnit[unitSetIndex] = value
return value
end
return currentUnit
end
function THStoreItem:formatCapacity(minCapacity, maxCapacity)
local fillTypeList, numFillTypes = self:getCapacityFillTypes()
local capacityText = nil
if numFillTypes > 0 then
local currentUnit = self:getUnitSelectionValues()
local unitInfo, unitFactor, unitPrecision = g_thMain:getFillTypeUnitData(fillTypeList, currentUnit)
if unitInfo ~= nil then
local minText = g_i18n:formatNumber(minCapacity * unitFactor, 0, unitPrecision)
if maxCapacity ~= nil and maxCapacity > 0 and maxCapacity ~= minCapacity then
local maxText = g_i18n:formatNumber(maxCapacity * unitFactor, 0, unitPrecision)
capacityText = string.format("%s-%s %s", minText, maxText, unitInfo.titleShort)
else
capacityText = minText.." "..unitInfo.titleShort
end
end
end
return capacityText
end
function THStoreItem:formatFuelCapacity(fuelCapacity, defCapacity, fuelFillType)
local fuelFillTypeInfo = g_thMain:getFillType(fuelFillType)
if fuelFillTypeInfo ~= nil then
local fuelFillTypeIndex = fuelFillTypeInfo.index
local capacityText = g_i18n:formatVolume(fuelCapacity, 0, nil,nil,nil, fuelFillTypeIndex)
if fuelFillTypeIndex == FillType.DIESEL then
if defCapacity ~= nil and defCapacity > 0 then
local defCapacityText  = g_i18n:formatVolume(defCapacity, 0, nil,nil,nil, FillType.DEF)
capacityText = capacityText.." | "..defCapacityText.." "..g_i18n:getText("fillType_def_short")
end
end
return capacityText
end
end
local function runScript()
g_thMain:setProtectedHook("ShopController", "makeDisplayItem", THShopController)
end
g_thMain:call(runScript)