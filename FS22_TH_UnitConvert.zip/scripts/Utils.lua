-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THUtils = {
MOD_NAME = g_currentModName,
MSG = {
ARGUMENT_INVALID = "Invalid argument %q (%s) in function call"
}
}
g_thUtils = THUtils
function THUtils:displayMsg(text, ...)
if type(text) ~= "string" then
text = string.format("ERROR: Invalid displayMsg text, %q", text)
else
text = string.format(text, ...)
end
local modName = THUtils.MOD_NAME
local msgString = string.format(">> %s: %s", modName, text)
print(msgString)
end
function THUtils:warningMsg(text, ...)
if type(text) == "string" then
text = "WARNING: "..text
end
self:displayMsg(text, ...)
end
function THUtils:errorMsg(raise, text, ...)
if raise == nil or raise == true then
raise = 2
end
if type(raise) == "number" then
if type(text) == "string" then
text = string.format(text, ...)
end
error(text, raise)
elseif raise == false then
if type(text) == "string" then
text = "ERROR: "..text
end
self:displayMsg(text, ...)
printCallstack()
else
self:displayMsg("ERROR: ".. THUtils.MSG.ARGUMENT_INVALID, "raise", raise)
error(nil, 1)
end
end
function THUtils:assert(expression, raise, text, ...)
if not expression then
if raise == false then
self:warningMsg(text, ...)
else
if raise == nil or raise == true then
raise = 3
end
self:errorMsg(raise, text, ...)
end
end
return expression
end
function THUtils:msgOnTrue(expression, raise, text, ...)
if expression then
if raise == false then
self:warningMsg(text, ...)
else
if raise == nil or raise == true then
raise = 3
end
self:errorMsg(raise, text, ...)
end
return true
end
return false
end
function THUtils:argIsValid(expression, name, arg, raise)
if not expression then
if raise == false then
self:warningMsg(THUtils.MSG.ARGUMENT_INVALID, name, arg)
else
if raise == nil or raise == true then
raise = 3
end
self:errorMsg(raise, THUtils.MSG.ARGUMENT_INVALID, name, arg)
end
return false
end
return true
end
function THUtils:pack(...)
return {n = select("#", ...), ...}
end
function THUtils:unpack(target, index)
local numEntries = self:getNoNil(target.n, #target)
index = self:getNoNil(index, 1)
if index <= numEntries then
return unpack(target, index, numEntries)
end
end
function THUtils:pcall(target, arg1, ...)
local function protectedFunc(pTarget, p1, ...)
local vTargetType = type(pTarget)
local vFunc = nil
if vTargetType == "function" then
vFunc = pTarget
return vFunc(p1, ...)
elseif vTargetType == "table" then
vFunc = pTarget[p1]
return vFunc(pTarget, ...)
else
local vErrMsg = string.format(THUtils.MSG.ARGUMENT_INVALID, "target", target)
error(vErrMsg, 4)
end
end
return pcall(protectedFunc, target, arg1, ...)
end
function THUtils:call(target, arg1, ...)
local function getRetValues(pSuccess, p1, ...)
if pSuccess then
return p1, ...
end
if type(p1) == "string" then
self:errorMsg(false, p1)
else
printCallstack()
end
end
return getRetValues(self:pcall(target, arg1, ...))
end
function THUtils:toBoolean(value)
if value == true or value == false then
return value
else
local valType = type(value)
if valType == "string" then
local valString = value:upper()
if valString == "TRUE" then
return true
elseif valString == "FALSE" then
return false
end
end
end
end
function THUtils:getNoNil(target, replacement, includeEmptyStrings)
if target == nil or (target == "" and includeEmptyStrings == true) then
return replacement
end
return target
end
function THUtils:getIsType(value, arg)
local valType = type(value)
local argType = type(arg)
if valType == argType then
return true
end
if argType == "table" then
if valType == "table" and value.isa ~= nil and value:isa(arg) then
return true
end
elseif argType == "string" then
if string.find(arg, "^"..valType.." ")
or string.find(arg, " "..valType.."$")
or string.find(arg, " "..valType.." ")
then
return true
end
else
self:errorMsg(nil, THUtils.MSG.ARGUMENT_INVALID, "arg", arg)
end
return false
end
function THUtils:getGlobalEnv()
local globalEnv = _G
local mt = getmetatable(_G)
if mt ~= nil and mt.__index ~= nil then
globalEnv = mt.__index
end
return globalEnv
end
function THUtils:floor(value, precision)
precision = self:getNoNil(precision, 0)
local factor = 10 ^ precision
return math.floor(value * factor) / factor
end
function THUtils:round(value, precision)
precision = self:getNoNil(precision, 0)
local factor = 10 ^ precision
return math.floor((value * factor) + 0.5) / factor
end
function THUtils:splitString(text, separator)
return string.split(text, separator)
end
function THUtils:getNumericValues(text, index)
text = self:getNoNil(text, "")
local currencyChar = "%"..g_i18n:getCurrencySymbol(true)
local groupingChar = "%"..g_i18n.thousandsGroupingChar
local decimalChar = "%"..g_i18n.decimalSeparator
local n = nil
local valText = string.gsub(text, currencyChar, "")
valText = string.gsub(valText, decimalChar, ".")
while true do
valText, n = string.gsub(valText, "(%d)"..groupingChar.."(%d%d%d)", "%1%2")
if n == nil or n <= 0 then
break
end
end
valText = string.gsub(valText, "([^ ])(%-)", "%1 %2 ")
valText = string.gsub(valText, "(%d+)(%a)", "%1 %2")
valText = string.gsub(valText, "([%-%a%d%.]+)", " %1 ")
valText = string.gsub(valText, " +", " ")
local valArray = self:splitString(valText, " ")
local numValues = #valArray
if numValues > 0 then
local valIndex = 1
while true do
local value = valArray[valIndex]
if value == nil then
break
end
local numValue = tonumber(value)
if numValue == nil then
table.remove(valArray, valIndex)
else
valArray[valIndex] = numValue
valIndex = valIndex + 1
end
end
end
if index ~= nil then
return valArray[index]
end
return valArray
end
function THUtils:properCase(text, removeSpaces)
if text == nil then
return
end
local retText = text
retText = string.gsub(retText, "^%l", string.upper)
retText = string.gsub(retText, " %l", string.upper)
if removeSpaces then
retText = string.gsub(retText, " ", "")
end
return retText
end
function THUtils:getFilename(filename, filePath)
if filename == nil then
return
end
filename = string.gsub(filename, "\\", "/")
local _, ePos, prefix = string.find(filename, "^%$([%w_]+)%$")
local customEnv = nil
if prefix ~= nil then
local retFilename = string.sub(filename, ePos+1)
local prefixLower = string.lower(prefix)
local requireModIsLoaded = true
filePath = nil
if string.sub(retFilename, 1, 1) == "!" then
retFilename = string.sub(retFilename, 2)
requireModIsLoaded = false
end
if string.sub(retFilename, 1, 1) == "/" then
retFilename = string.sub(retFilename, 2)
end
if prefixLower == "data" then
filePath = getAppBasePath()
elseif prefixLower == "mapdir" then
local missionInfo = nil
if g_currentMission ~= nil then
missionInfo = g_currentMission.missionInfo
elseif g_mpLoadingScreen ~= nil then
missionInfo = g_mpLoadingScreen.missionInfo
end
if missionInfo ~= nil and missionInfo.map ~= nil then
if missionInfo.map.isModMap then
filePath = missionInfo.map.mapXMLFilename
customEnv = missionInfo.map.customEnvironment
else
filePath = getAppBasePath()
end
end
elseif g_modManager ~= nil then
local modName = nil
if prefixLower == "moddir" or prefixLower == "pdlcdir" then
local fPos = retFilename:find("/")
if fPos ~= nil and fPos > 1 then
modName = retFilename:sub(1, fPos - 1)
if modName ~= nil and prefixLower == "pdlcdir" then
if g_dlcModNameHasPrefix[modName] then
modName = g_uniqueDlcNamePrefix..modName
end
retFilename = retFilename:sub(fPos + 1)
end
end
else
modName = prefix
end
if modName ~= nil then
local modInfo = g_modManager:getModByName(modName)
if modInfo ~= nil then
if not requireModIsLoaded
or (g_modIsLoaded ~= nil and g_modIsLoaded[modInfo.name] == true)
then
filePath = modInfo.modDir
customEnv = modInfo.modName
end
end
end
end
if filePath ~= nil then
local fullFilename, isAbsolute = Utils.getFilename(retFilename, filePath)
return fullFilename, isAbsolute, customEnv
end
else
return Utils.getFilename(filename, filePath)
end
end
function THUtils:printTable(...)
if g_thDebugger ~= nil then
g_thDebugger:printTable(...)
end
end
function THUtils:clearTable(target)
for key in pairs(target) do
target[key] = nil
end
return target
end
function THUtils:getTableLength(target)
local numEntries = 0
for _ in pairs(target) do
numEntries = numEntries + 1
end
return numEntries
end
function THUtils:getTableIsArray(target)
local isArray = target[1] ~= nil
local i = 1
for _ in pairs(target) do
if target[i] == nil then
isArray = false
break
end
i = i + 1
end
if isArray then
local numEntries = #target
if numEntries > 0 and type(target[1]) == "boolean" then
if numEntries > 2 or type(target[2]) ~= "boolean" or target[1] == target[2] then
isArray = false
end
end
end
return isArray
end
function THUtils:createOverlayTable(parent)
if self:argIsValid(type(parent) == "table", "parent", parent) then
local function callFunc(pSelf, pCommand, ...)
local vParent = parent
if pCommand == "getParent" then
return vParent
elseif pCommand == "setValue" then
return rawset(pSelf, ...)
end
self:errorMsg(3, "Invalid command %q sent to overlay table", pCommand)
end
local overlayTable = setmetatable({}, {__index = parent, __newindex = parent, __call = callFunc})
return overlayTable, parent
end
end
function THUtils:getTargetInfo(env, tableName, target, verbose, raise)
local valType = type(target)
local targetInfo = nil
if valType == "table" then
targetInfo = env[tableName].byId[target.id]
if targetInfo ~= target then
targetInfo = nil
end
elseif valType == "string" then
targetInfo = env[tableName].byId[target:upper()]
elseif valType == "number" then
targetInfo = env[tableName].byIndex[target]
elseif target ~= nil then
verbose = true
end
if targetInfo == nil and verbose == true then
raise = self:getNoNil(raise, verbose)
self:errorMsg(raise, THUtils.MSG.ARGUMENT_INVALID, "target", target)
end
return targetInfo
end
function THUtils:getFunctionData(target, funcKey, recursive)
local targetName = target
if type(targetName) == "string" then
local globalEnv = self:getGlobalEnv()
target = globalEnv[targetName]
end
local trueTable = target
local superFunc = trueTable[funcKey]
local trueFunc  = rawget(trueTable, funcKey)
if type(superFunc) == "function" then
if not recursive or trueFunc == superFunc then
return trueTable, superFunc, trueFunc
end
if type(trueTable.class) == "function" then
trueTable = trueTable:class()
while type(trueTable) == "table" do
trueFunc = rawget(trueTable, funcKey)
if trueFunc == superFunc then
return trueTable, superFunc, trueFunc
end
if type(trueTable.superClass) ~= "function" then
break
end
trueTable = trueTable:superClass()
end
end
end
end
function THUtils:hookFunction(srcTable, srcFuncKey, tgtFunc, addSelf, extraArg)
local trueTable, superFunc, trueFunc = self:getFunctionData(srcTable, srcFuncKey)
if trueTable == nil or superFunc == nil then
return
end
if self:argIsValid(type(tgtFunc) == "function", "tgtFunc", tgtFunc) then
rawset(trueTable, srcFuncKey, function(p1, ...)
if extraArg ~= nil then
if addSelf == true then
return tgtFunc(p1, superFunc, extraArg, ...)
else
return tgtFunc(superFunc, extraArg, p1, ...)
end
else
if addSelf == true then
return tgtFunc(p1, superFunc, ...)
else
return tgtFunc(superFunc, p1, ...)
end
end
end)
return trueTable, superFunc, trueFunc
end
end
function THUtils:getElementByProfileName(baseElement, profileName, recursive)
if profileName == nil then
return
end
if profileName == baseElement.profile then
return baseElement
end
local elementList = baseElement.elements
if elementList and #elementList > 0 then
for idx = 1, #elementList do
local element = elementList[idx]
if recursive then
local foundElement = self:getElementByProfileName(element, profileName, recursive)
if foundElement then
return foundElement
end
elseif profileName == element.profile then
return element
end
end
end
end
function THUtils:getPlayerFarmId(connection)
if g_currentMission ~= nil then
return g_currentMission:getFarmId(connection)
end
end
function THUtils:getIsMasterUser()
if g_currentMission ~= nil then
return g_currentMission.isMasterUser
end
return false
end
function THUtils:getHasPlayerPermission(permission, connection, farmId, checkClient)
if g_currentMission ~= nil then
return g_currentMission:getHasPlayerPermission(permission, connection, farmId, checkClient)
end
return false
end
function THUtils:getFillType(target, verbose, raise)
local manager = g_fillTypeManager
local valType = type(target)
local fillTypeInfo = nil
if valType == "table" then
if type(target.name) == "string" then
fillTypeInfo = manager:getFillTypeByName(target.name)
if fillTypeInfo ~= target then
fillTypeInfo = nil
end
end
elseif valType == "string" then
fillTypeInfo = manager:getFillTypeByName(target)
elseif valType == "number" then
fillTypeInfo = manager:getFillTypeByIndex(target)
elseif target ~= nil then
verbose = true
end
raise = self:getNoNil(raise, verbose)
self:msgOnTrue(fillTypeInfo == nil and verbose, raise, THUtils.MSG.ARGUMENT_INVALID, "target", target)
return fillTypeInfo
end
function THUtils:getFillTypeList()
if g_fillTypeManager ~= nil then
return g_fillTypeManager:getFillTypes()
end
return {}
end
function THUtils:getFillTypeCategories(fillType)
local manager = g_fillTypeManager
local fillTypeInfo = self:getFillType(fillType, true)
local categoryList = {}
local numCategories = 0
if fillTypeInfo ~= nil then
for categoryName, fillTypeList in pairs(manager.categoryNameToFillTypes) do
local categoryId = categoryName:upper()
if fillTypeList[fillTypeInfo.index] then
categoryList[categoryId] = true
numCategories = numCategories + 1
end
end
end
return categoryList, numCategories
end