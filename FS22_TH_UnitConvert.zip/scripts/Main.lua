-- Copyright �2023 by Todd Hundersmarck (ThundR)
-- All Rights Reserved

THMain = {}
local THMain_mt = Class(THMain, THCore)
function THMain:new(dataKey, mt)
mt = Utils.getNoNil(mt, THMain_mt)
local newEnv = THCore:new(dataKey, mt)
if newEnv then
newEnv.units = {
byId      = {},
byType    = {},
byIndex   = {},
idToIndex = {}
}
newEnv.UNIT = newEnv.units.idToIndex
newEnv.unitSets = {
byId      = {},
byIndex   = {},
idToIndex = {}
}
newEnv.UNIT_SET = newEnv.unitSets.idToIndex
newEnv.unitTypes = {
byId      = {},
byIndex   = {},
idToIndex = {}
}
newEnv.UNIT_TYPE = newEnv.unitTypes.idToIndex
table.insert(newEnv.unitTypes.byIndex, {name = "volume"})
table.insert(newEnv.unitTypes.byIndex, {name = "weight"})
for i, unitTypeInfo in ipairs(newEnv.unitTypes.byIndex) do
unitTypeInfo.id = unitTypeInfo.name:upper()
unitTypeInfo.index = i
newEnv.unitTypes.byId[unitTypeInfo.id] = unitTypeInfo
newEnv.unitTypes.idToIndex[unitTypeInfo.id] = unitTypeInfo.index
newEnv.units.byType[unitTypeInfo.index] = {}
end
newEnv.fillTypeGroups = {
byId      = {},
byIndex   = {},
idToIndex = {}
}
newEnv.FILLTYPE_GROUP = newEnv.fillTypeGroups.idToIndex
end
return newEnv
end
function THMain.initializeXMLSchema()
local xmlSchema = THMain.xmlSchema
local unitKey = "map.units.unit(?)"
xmlSchema:register(XMLValueType.STRING, unitKey.."#name", "Name of unit")
xmlSchema:register(XMLValueType.STRING, unitKey.."#type", "Unit type (i.e. volume, weight, etc.)")
xmlSchema:register(XMLValueType.FLOAT,  unitKey.."#factor", "Unit conversion factor")
xmlSchema:register(XMLValueType.INT,    unitKey.."#precision", "Unit precision")
xmlSchema:register(XMLValueType.STRING, unitKey.."#title", "Unit long title")
xmlSchema:register(XMLValueType.STRING, unitKey.."#titleShort", "Unit abbreviated title")
local unitSetKey = "map.unitSets.unitSet(?)"
xmlSchema:register(XMLValueType.STRING, unitSetKey.."#name", "Name of unit set")
xmlSchema:register(XMLValueType.STRING, unitSetKey.."#title", "Unit set title")
local function registerUnits(pBaseKey)
xmlSchema:register(XMLValueType.STRING, pBaseKey..".unit(?)#name", "Name of unit")
end
local defUnitsKey = unitSetKey..".units(?)"
xmlSchema:register(XMLValueType.STRING, defUnitsKey.."#type", "Unit type")
registerUnits(defUnitsKey)
local fillTypeGroupKey = "map.fillTypeGroups.fillTypeGroup(?)"
xmlSchema:register(XMLValueType.STRING, fillTypeGroupKey.."#name", "Name of fillType group")
xmlSchema:register(XMLValueType.STRING, fillTypeGroupKey.."#title", "FillType group title")
local fillTypeKey = "map.fillTypes.fillType(?)"
xmlSchema:register(XMLValueType.STRING, fillTypeKey.."#name", "Name of fillType")
xmlSchema:register(XMLValueType.STRING, fillTypeKey.."#group", "Name of fillType group")
xmlSchema:register(XMLValueType.FLOAT,  fillTypeKey.."#displayMass", "Mass to use for unit display")
local function registerFillTypeUnits(pBaseKey)
local vUnitSetKey = pBaseKey..".unitSet(?)"
xmlSchema:register(XMLValueType.STRING, vUnitSetKey.."#name", "Name of unit set")
registerUnits(vUnitSetKey)
end
registerFillTypeUnits(fillTypeGroupKey)
registerFillTypeUnits(fillTypeKey)
end
function THMain:initializeSettings()
if THMain:superClass().initializeSettings(self) then
local unitSetList = self:getUnitSetList()
if self:addSettingCategory("mainMenu", self.modInfo.title) then
if self:addSetting("currentUnitSet", nil,nil, "mainMenu") then
for _, unitSetInfo in ipairs(unitSetList) do
self:addSettingValue("currentUnitSet", unitSetInfo.id, unitSetInfo.title)
end
end
end
return true
end
return false
end
function THMain:initializeUnits()
self:addUnitSet("usCustomary")
self:addUnitSet("metric")
self:addUnit("liter",         "volume", 1,         0)
self:addUnit("bushel",        "volume", 0.028378,  1)
self:addUnit("cubicMeter",    "volume", 0.001,     2)
self:addUnit("cubicFoot",     "volume", 0.035315,  1)
self:addUnit("cubicYard",     "volume", 0.001308,  2)
self:addUnit("gallon",        "volume", 0.264172,  1)
self:addUnit("fluidOunce",    "volume", 33.814023, 0)
self:addUnit("kilogram",      "weight", 1,         0)
self:addUnit("ounce",         "weight", 35.27396,  0)
self:addUnit("pound",         "weight", 2.204623,  0)
self:addUnit("hundredWeight", "weight", 0.022046,  1)
self:addUnit("tonne",         "weight", 0.001,     2)
self:addUnit("ton",           "weight", 0.0011023, 2)
self:addUnit("animal",        "volume", 1)
self:addUnit("piece",         "volume", 1)
self:addUnit("kilowattHour",  "volume", 1)
if self:initializeUnitTitleMapping() then
return true
end
return false
end
function THMain:initializeUnitTitleMapping()
local titleMap = {}
titleMap.UNIT_LITER        = {name = "unit_liter",        index = self.UNIT.LITER,        isTitleShort = false}
titleMap.UNIT_LITERSHORT   = {name = "unit_literShort",   index = self.UNIT.LITER,        isTitleShort = true}
titleMap.UNIT_CUBIC        = {name = "unit_cubic",        index = self.UNIT.CUBICMETER,   isTitleShort = false}
titleMap.UNIT_CUBICSHORT   = {name = "unit_cubicShort",   index = self.UNIT.CUBICMETER,   isTitleShort = true}
titleMap.UNIT_TONSSHORT    = {name = "unit_tonsShort",    index = self.UNIT.TONNE,        isTitleShort = true}
titleMap.UNIT_KG           = {name = "unit_kg",           index = self.UNIT.KILOGRAM,     isTitleShort = true}
titleMap.UNIT_BUSHELS      = {name = "unit_bushels",      index = self.UNIT.BUSHEL,       isTitleShort = false}
titleMap.UNIT_BUSHELSSHORT = {name = "unit_bushelsShort", index = self.UNIT.BUSHEL,       isTitleShort = true}
titleMap.UNIT_PIECES       = {name = "unit_pieces",       index = self.UNIT.PIECE,        isTitleShort = true}
titleMap.UNIT_KW           = {name = "unit_kw",           index = self.UNIT.KILOWATTHOUR, isTitleShort = true}
for unitTitleId, unitTitleInfo in pairs(titleMap) do
unitTitleInfo.id = unitTitleId
unitTitleInfo.title = g_i18n:getText(unitTitleInfo.name)
end
self.unitTitleMapping = titleMap
return true
end
function THMain:loadUnitsFromXMLFile(xmlFile, customEnv, basePath)
customEnv = g_thUtils:getNoNil(customEnv, self.modName, true)
basePath  = g_thUtils:getNoNil(customEnv, self.modPath, true)
xmlFile:iterate("map.units.unit", function(_, pKey)
local name        = xmlFile:getValue(pKey.."#name")
local unitType    = xmlFile:getValue(pKey.."#type")
local factor      = xmlFile:getValue(pKey.."#factor")
local precision   = xmlFile:getValue(pKey.."#precision")
local title       = xmlFile:getValue(pKey.."#title")
local titleShort  = xmlFile:getValue(pKey.."#titleShort")
self:addUnit(name, unitType, factor, precision, title, titleShort, customEnv, basePath)
end)
xmlFile:iterate("map.unitSets.unitSet", function(_, pKey)
local name  = xmlFile:getValue(pKey.."#name")
local title = xmlFile:getValue(pKey.."#title", name)
local unitSetInfo = self:addUnitSet(name, title, customEnv, basePath)
if unitSetInfo ~= nil then
xmlFile:iterate(pKey..".units", function(_, pKey2)
local unitType = xmlFile:getValue(pKey2.."#type")
local unitTypeInfo = self:getUnitType(unitType, true, false)
if unitTypeInfo ~= nil then
local resetUnits = true
xmlFile:iterate(pKey2..".unit", function(_, pKey3)
local unitName = xmlFile:getValue(pKey3.."#name")
local unitInfo = self:getUnit(unitName)
if unitInfo ~= nil then
if resetUnits then
g_thUtils:clearTable(unitSetInfo.units[unitTypeInfo.index])
g_thUtils:clearTable(unitSetInfo.unitMapping[unitTypeInfo.index])
resetUnits = false
end
if g_thUtils:assert(unitInfo.type == unitType, false, "Unit %q, invalid unit type (%s)", unitInfo.name, unitType) then
self:addDefaultUnit(unitSetInfo, unitInfo)
end
end
end)
end
end)
end
end)
return true
end
function THMain:finalizeUnits()
local unitSetList = self:getUnitSetList()
for _, unitSetInfo in pairs(unitSetList) do
local unitSetId = unitSetInfo.id
for _, unitTypeIndex in pairs(self.UNIT_TYPE) do
if #unitSetInfo.units[unitTypeIndex] == 0 then
if unitTypeIndex == self.UNIT_TYPE.VOLUME then
if unitSetId == "USCUSTOMARY" then
self:addDefaultUnit(unitSetInfo, "CUBICYARD")
else
self:addDefaultUnit(unitSetInfo, "LITER")
end
elseif unitTypeIndex == self.UNIT_TYPE.WEIGHT then
if unitSetId == "USCUSTOMARY" then
self:addDefaultUnit(unitSetInfo, "POUND")
self:addDefaultUnit(unitSetInfo, "TON")
else
self:addDefaultUnit(unitSetInfo, "KILOGRAM")
self:addDefaultUnit(unitSetInfo, "TONNE")
end
end
end
end
end
return true
end
function THMain:addUnit(name, unitType, factor, precision, title, titleShort, customEnv, basePath)
local unitInfo = self:getUnit(name)
if unitInfo == nil then
if g_thUtils:argIsValid(type(name) == "string" and name ~= "", "name", name, false) then
unitType  = g_thUtils:getNoNil(unitType, "VOLUME")
customEnv = g_thUtils:getNoNil(customEnv, self.modName, true)
basePath  = g_thUtils:getNoNil(basePath, self.modPath, true)
local unitTypeInfo = self:getUnitType(unitType, true, false)
local modInfo = self:getLoadedMod(customEnv, true, false)
if unitTypeInfo == nil or modInfo == nil then
return
end
unitInfo = {
id        = name:upper(),
name      = name,
index     = #self.units.byIndex + 1,
type      = unitTypeInfo.index,
factor    = 1,
precision = 0,
customEnv = modInfo.name
}
if g_i18n:hasText("ucUnit_"..unitInfo.name, customEnv) then
unitInfo.title = g_i18n:getText("ucUnit_"..unitInfo.name, customEnv)
else
unitInfo.title = unitInfo.name
end
if g_i18n:hasText("ucUnit_"..unitInfo.name.."Short", customEnv) then
unitInfo.titleShort = g_i18n:getText("ucUnit_"..unitInfo.name.."Short", customEnv)
else
unitInfo.titleShort = ""
end
self.units.byId[unitInfo.id] = unitInfo
self.units.byIndex[unitInfo.index] = unitInfo
self.units.idToIndex[unitInfo.id] = unitInfo.index
table.insert(self.units.byType[unitInfo.type], unitInfo)
end
end
if unitInfo ~= nil then
if factor ~= nil and g_thUtils:argIsValid(type(factor) == "number" and factor > 0 and factor < math.huge, "factor", factor, false) then
unitInfo.factor = factor
end
if precision ~= nil and g_thUtils:argIsValid(type(precision) == "number" and precision >= 0 and precision < math.huge, "precision", precision, false) then
unitInfo.precision = math.floor(precision)
end
if title ~= nil and g_thUtils:argIsValid(type(title) == "string" and title ~= "", "title", title, false) then
unitInfo.title = g_i18n:convertText(title, customEnv)
end
if titleShort ~= nil and g_thUtils:argIsValid(type(titleShort) == "string", "titleShort", titleShort, false) then
unitInfo.titleShort = g_i18n:convertText(titleShort, customEnv)
end
end
return unitInfo
end
function THMain:getUnit(target, verbose, raise)
return g_thUtils:getTargetInfo(self, "units", target, verbose, raise)
end
function THMain:getUnitTitleInfo(title)
local unitTitleInfo = nil
if type(title) == "string" then
unitTitleInfo = self.unitTitleMapping[title:upper()]
if unitTitleInfo == nil then
for _, infoTable in pairs(self.unitTitleMapping) do
if title == infoTable.title then
unitTitleInfo = infoTable
break
end
end
end
elseif title ~= nil then
g_thUtils:errorMsg(nil, THUtils.MSG.ARGUMENT_INVALID, "title", title)
end
return unitTitleInfo
end
function THMain:getUnitList()
return self.units.byIndex
end
function THMain:getUnitListByType(unitType)
local unitTypeInfo = self:getUnitType(unitType, true)
if unitTypeInfo ~= nil then
return self.units.byType[unitTypeInfo.index]
end
end
function THMain:getUnitType(target, verbose, raise)
return g_thUtils:getTargetInfo(self, "unitTypes", target, verbose, raise)
end
function THMain:getUnitTypeList()
return self.unitTypes.byIndex
end
function THMain:addUnitSet(name, title, customEnv, basePath)
local unitSetInfo = self:getUnitSet(name)
if unitSetInfo == nil then
if g_thUtils:argIsValid(type(name) == "string" and name ~= "", "name", name) then
customEnv = g_thUtils:getNoNil(customEnv, self.modName, true)
basePath = g_thUtils:getNoNil(basePath, self.modPath, true)
local modInfo = self:getLoadedMod(customEnv, true, false)
if modInfo ~= nil then
unitSetInfo = {
id          = name:upper(),
name        = name,
index       = #self.unitSets.byIndex + 1,
units       = {},
unitMapping = {},
customEnv   = modInfo.name
}
if g_i18n:hasText("ucUnitSet_"..unitSetInfo.name, customEnv) then
unitSetInfo.title = g_i18n:getText("ucUnitSet_"..unitSetInfo.name, customEnv)
else
unitSetInfo.title = unitSetInfo.name
end
for _, unitTypeIndex in pairs(self.UNIT_TYPE) do
unitSetInfo.units[unitTypeIndex] = {}
unitSetInfo.unitMapping[unitTypeIndex] = {}
end
self.unitSets.byId[unitSetInfo.id] = unitSetInfo
self.unitSets.byIndex[unitSetInfo.index] = unitSetInfo
self.unitSets.idToIndex[unitSetInfo.id] = unitSetInfo.index
end
end
end
if unitSetInfo ~= nil then
if title ~= nil and g_thUtils:argIsValid(type(title) == "string" and title ~= "", "title", title, false) then
unitSetInfo.title = g_i18n:convertText(title, customEnv)
end
end
return unitSetInfo
end
function THMain:getUnitSet(target, verbose, raise)
return g_thUtils:getTargetInfo(self, "unitSets", target, verbose, raise)
end
function THMain:getCurrentUnitSet(getInfo)
local unitSetId = self:getSettingValue("currentUnitSet")
if getInfo then
return self:getUnitSet(unitSetId, true)
end
return self.UNIT_SET[unitSetId]
end
function THMain:getTargetOrCurrentUnitSet(target, getInfo)
if target == nil then
return self:getCurrentUnitSet(getInfo)
end
local unitSetInfo = self:getUnitSet(target, true)
if getInfo then
return unitSetInfo
elseif unitSetInfo ~= nil then
return unitSetInfo.index
end
end
function THMain:getUnitSetList()
return self.unitSets.byIndex
end
function THMain:addDefaultUnit(unitSet, unit)
local unitSetInfo = self:getUnitSet(unitSet, true)
local unitInfo = self:getUnit(unit, true)
if unitSetInfo ~= nil and unitInfo ~= nil then
local unitTypeInfo = self:getUnitType(unitInfo.type, true)
if unitTypeInfo ~= nil then
local unitList = unitSetInfo.units[unitTypeInfo.index]
local unitMapping = unitSetInfo.unitMapping[unitTypeInfo.index]
if unitMapping[unitInfo.index] == nil then
table.insert(unitList, unitInfo)
unitMapping[unitInfo.index] = #unitList
return true
end
g_thUtils:warningMsg("Unit %q already added to unitSet %q", unitInfo.name, unitSetInfo.name)
end
end
return false
end
function THMain:getDefaultUnitList(unitSet, unitType)
local unitSetInfo = self:getUnitSet(unitSet, true)
local unitTypeInfo = self:getUnitType(unitType, true)
if unitSetInfo ~= nil and unitTypeInfo ~= nil then
return unitSetInfo.units[unitTypeInfo.index]
end
end
function THMain:getDefaultMaxNumUnits(unitType, unitSet)
local unitTypeInfo = self:getUnitType(unitType, true)
local unitSetInfo = self:getTargetOrCurrentUnitSet(unitSet, true)
if unitTypeInfo ~= nil and unitSetInfo ~= nil then
return #unitSetInfo.units[unitTypeInfo.index]
end
return 0
end
function THMain:getDefaultUnitData(unitType, index, unitSet)
index = g_thUtils:getNoNil(index, 1)
local unitTypeInfo = self:getUnitType(unitType, true)
local unitSetInfo = self:getTargetOrCurrentUnitSet(unitSet, true)
if unitTypeInfo ~= nil and unitSetInfo ~= nil then
local unitList = unitSetInfo.units[unitTypeInfo.index]
local maxNumUnits = #unitList
if maxNumUnits > 0 then
index = MathUtil.clamp(index, 1, maxNumUnits)
local unit = unitList[index]
local unitInfo = self:getUnit(unit, true)
if unitInfo ~= nil then
return unitInfo, unitInfo.factor, unitInfo.precision
end
end
end
return nil,1,0
end
function THMain:initializeFillTypeGroups()
self:addFillTypeGroup("grain")
self:addFillTypeGroup("solid")
self:addFillTypeGroup("liquid")
self:addFillTypeGroup("piece")
self:addFillTypeGroup("animal")
self:addFillTypeGroup("solidProduct")
self:addFillTypeGroup("liquidProduct")
self:addFillTypeGroup("electricity")
self:addFillTypeGroup("other")
return true
end
function THMain:initializeFillTypes()
local fillTypeList = g_fillTypeManager:getFillTypes()
for _, fillTypeInfo in pairs(fillTypeList) do
local fillTypeData = self:getDataTable(fillTypeInfo)
if not fillTypeData.isInitialized then
fillTypeData:updateDefaultValues(true)
fillTypeData.displayMass = fillTypeInfo.massPerLiter
fillTypeData.units = {}
fillTypeData.unitMapping = {}
fillTypeData.currentUnit = 0
for _, unitSetIndex in pairs(self.UNIT_SET) do
fillTypeData.units[unitSetIndex] = {}
fillTypeData.unitMapping[unitSetIndex] = {}
end
fillTypeData.isInitialized = true
end
end
return true
end
function THMain:loadFillTypesFromXMLFile(xmlFile, customEnv, basePath)
customEnv = g_thUtils:getNoNil(customEnv, self.modName, true)
basePath  = g_thUtils:getNoNil(basePath, self.modPath, true)
local function loadUnitData(pBaseKey, pTargetInfo, pTargetData)
local vTargetIsGroup = false
if pTargetData == nil then
pTargetData = pTargetInfo
vTargetIsGroup = true
end
xmlFile:iterate(pBaseKey..".unitSet", function(_, pKey)
local vUnitSetName = xmlFile:getValue(pKey.."#name")
local vUnitSetInfo = self:getUnitSet(vUnitSetName)
if vUnitSetInfo ~= nil then
local vResetUnits = true
xmlFile:iterate(pKey..".unit", function(_, pKey2)
local vUnitName = xmlFile:getValue(pKey2.."#name")
local vUnitInfo = self:getFillTypeUnit(vUnitName)
if vUnitInfo ~= nil then
if vResetUnits then
g_thUtils:clearTable(pTargetData.units[vUnitSetInfo.index])
g_thUtils:clearTable(pTargetData.unitMapping[vUnitSetInfo.index])
vResetUnits = false
end
self:addFillTypeUnit(pTargetInfo, vUnitSetInfo, vUnitInfo, vTargetIsGroup)
end
end)
end
end)
end
xmlFile:iterate("map.fillTypeGroups.fillTypeGroup", function(_, pKey)
local name  = xmlFile:getValue(pKey.."#name")
local title = xmlFile:getValue(pKey.."#title")
local groupInfo = self:addFillTypeGroup(name, title, customEnv, basePath)
if groupInfo ~= nil then
loadUnitData(pKey, groupInfo)
end
end)
xmlFile:iterate("map.fillTypes.fillType", function(_, pKey)
local name = xmlFile:getValue(pKey.."#name")
local groupName = xmlFile:getValue(pKey.."#group")
local displayMass = xmlFile:getValue(pKey.."#displayMass")
local fillTypeInfo, fillTypeData = self:getFillType(name)
if fillTypeData ~= nil then
local groupInfo = self:getFillTypeGroup(groupName)
if groupInfo ~= nil then
self:setFillTypeGroup(fillTypeInfo, groupInfo)
end
if displayMass ~= nil then
if g_thUtils:assert(displayMass > 0, false, "FillType %q, display mass (%s) must be greater than zero", fillTypeInfo.name, displayMass) then
fillTypeData.displayMass = displayMass
end
end
loadUnitData(pKey, fillTypeInfo, fillTypeData)
end
end)
return true
end
function THMain:finalizeFillTypes()
local fillTypeList = g_fillTypeManager:getFillTypes()
local fillTypeGroupList = self:getFillTypeGroupList()
for _, groupInfo in pairs(fillTypeGroupList) do
for _, unitSetIndex in pairs(self.UNIT_SET) do
if #groupInfo.units[unitSetIndex] == 0 then
self:setFillTypeDefaultUnits(groupInfo, unitSetIndex, true)
end
end
end
for _, fillTypeInfo in pairs(fillTypeList) do
local fillTypeId = fillTypeInfo.name:upper()
local fillTypeData = g_thMain:getDataTable(fillTypeInfo)
local categoryList, numCategories = g_thUtils:getFillTypeCategories(fillTypeInfo.index)
if fillTypeData ~= nil then
if fillTypeData.group == nil then
if fillTypeId == "ELECTRICCHARGE" then
self:setFillTypeGroup(fillTypeId, "ELECTRICITY")
elseif fillTypeId == "SEEDS" or string.find(fillTypeId, "^SEED_")
or fillTypeId == "LETTUCE"
or fillTypeId == "TOMATO"
or fillTypeId == "STRAWBERRY"
or fillTypeId == "OLIVE"
or fillTypeId == "GRAPE"
then
self:setFillTypeGroup(fillTypeId, "GRAIN")
elseif fillTypeId:find("_OIL$")
or fillTypeId == "GRAPEJUICE"
or fillTypeId == "HONEY"
then
self:setFillTypeGroup(fillTypeId, "LIQUIDPRODUCT")
elseif categoryList.ANIMAL then
self:setFillTypeGroup(fillTypeId, "ANIMAL")
elseif categoryList.PIECE and fillTypeId ~= "WOOL" then
self:setFillTypeGroup(fillTypeId, "PIECE")
elseif categoryList.COMBINE then
self:setFillTypeGroup(fillTypeId, "GRAIN")
elseif categoryList.SPRAYER or categoryList.SLURRYTANK or categoryList.LIQUID then
if categoryList.LIQUID and categoryList.PRODUCT then
self:setFillTypeGroup(fillTypeId, "LIQUIDPRODUCT")
else
self:setFillTypeGroup(fillTypeId, "LIQUID")
end
elseif categoryList.PRODUCT then
self:setFillTypeGroup(fillTypeId, "SOLIDPRODUCT")
else
local unitTitleInfo = self:getUnitTitleInfo(fillTypeInfo.unitShort)
if unitTitleInfo ~= nil or numCategories > 0
or fillTypeId == "POPLAR"
then
self:setFillTypeGroup(fillTypeId, "SOLID")
else
self:setFillTypeGroup(fillTypeId, "OTHER")
end
end
end
for _, unitSetIndex in pairs(self.UNIT_SET) do
if #fillTypeData.units[unitSetIndex] == 0 then
local fillTypeMass = self:getFillTypeMass(fillTypeInfo)
if fillTypeMass == 0 then
local groupInfo = self:getFillTypeGroup(fillTypeData.group, true)
for _, unitIndex in ipairs(groupInfo.units[unitSetIndex]) do
local unitInfo = self:getFillTypeUnit(unitIndex, true)
if unitInfo.type == self.UNIT_TYPE.VOLUME then
self:addFillTypeUnit(fillTypeInfo, unitSetIndex, unitInfo, false)
end
end
end
end
end
end
end
return true
end
function THMain:addFillTypeGroup(name, title, customEnv, basePath)
local groupInfo = self:getFillTypeGroup(name)
if groupInfo == nil then
if g_thUtils:argIsValid(type(name) == "string" and name ~= "", "name", name) then
customEnv = g_thUtils:getNoNil(customEnv, self.modName, true)
basePath  = g_thUtils:getNoNil(basePath, self.modPath, true)
local modInfo = self:getLoadedMod(customEnv, true)
if modInfo ~= nil then
groupInfo = {
id          = name:upper(),
name        = name,
index       = #self.fillTypeGroups.byIndex + 1,
units       = {},
unitMapping = {},
customEnv   = modInfo.name
}
if g_i18n:hasText("ucFillTypeGroup_"..groupInfo.name, customEnv) then
groupInfo.title = g_i18n:getText("ucFillTypeGroup_"..groupInfo.name, customEnv)
else
groupInfo.title = groupInfo.name
end
for _, unitSetIndex in pairs(self.UNIT_SET) do
groupInfo.units[unitSetIndex] = {}
groupInfo.unitMapping[unitSetIndex] = {}
end
self.fillTypeGroups.byId[groupInfo.id] = groupInfo
if self:setFillTypeDefaultUnits(groupInfo, nil, true) then
self.fillTypeGroups.byIndex[groupInfo.index] = groupInfo
self.fillTypeGroups.idToIndex[groupInfo.id] = groupInfo.index
else
self.fillTypeGroups.byId = nil
groupInfo = nil
end
end
end
end
if groupInfo ~= nil then
if title ~= nil and g_thUtils:argIsValid(type(title) == "string" and title ~= "", "title", title, false) then
groupInfo.title = g_i18n:convertText(title, customEnv)
end
end
return groupInfo
end
function THMain:setFillTypeGroup(fillType, group)
local _, fillTypeData = self:getFillType(fillType, true)
local groupInfo = self:getFillTypeGroup(group, true)
if fillTypeData ~= nil and groupInfo ~= nil then
fillTypeData.group = groupInfo.index
return true
end
return false
end
function THMain:getFillTypeGroup(target, verbose, raise)
return g_thUtils:getTargetInfo(self, "fillTypeGroups", target, verbose, raise)
end
function THMain:getFillTypeGroupList()
return self.fillTypeGroups.byIndex
end
function THMain:getFillType(target, verbose, raise)
local fillTypeInfo = g_thUtils:getFillType(target, verbose, raise)
local fillTypeData = nil
if fillTypeInfo ~= nil then
fillTypeData = self:getDataTable(fillTypeInfo)
end
return fillTypeInfo, fillTypeData
end
function THMain:getFillTypeIsProduct(fillType)
local _, fillTypeData = self:getFillType(fillType, true)
if fillTypeData ~= nil then
local groupInfo = self:getFillTypeGroup(fillTypeData.group)
if string.find(groupInfo.id, "PRODUCT") then
return true
end
end
return false
end
function THMain:getFillTypeMass(fillType, getRealMass)
local fillTypeInfo, fillTypeData = self:getFillType(fillType, true)
local fillTypeMass = 0
if fillTypeData ~= nil then
if getRealMass then
fillTypeMass = g_thUtils:getNoNil(fillTypeInfo.massPerLiter, 0) * 1000
else
fillTypeMass = g_thUtils:getNoNil(fillTypeData.displayMass, 0) * 1000
end
end
return fillTypeMass
end
function THMain:getHeaviestFillType(fillTypeList, useRealMass)
local listType = type(fillTypeList)
local retFillTypeInfo, retFillTypeData = nil,nil
local maxFillTypeMass = -1
local function processFillType(pFillType)
local vFillTypeInfo, vFillTypeData = self:getFillType(pFillType, true)
if vFillTypeData ~= nil then
local vMass = self:getFillTypeMass(vFillTypeInfo, useRealMass)
if vMass > maxFillTypeMass then
retFillTypeInfo = vFillTypeInfo
retFillTypeData = vFillTypeData
maxFillTypeMass = vMass
end
end
end
if listType == "string" or listType == "number"
or (listType == "table" and fillTypeList.index ~= nil)
then
processFillType(fillTypeList)
else
if g_thUtils:getTableIsArray(fillTypeList) then
for _, fillType in pairs(fillTypeList) do
processFillType(fillType)
end
else
for fillType, isValid in pairs(fillTypeList) do
if isValid == true then
processFillType(fillType)
end
end
end
end
if retFillTypeData ~= nil and maxFillTypeMass >= 0 then
return retFillTypeInfo, retFillTypeData, maxFillTypeMass
end
return nil,nil,0
end
function THMain:addFillTypeUnit(target, unitSet, unit, targetIsGroup)
local targetInfo, targetData = nil,nil
if targetIsGroup then
targetInfo = self:getFillTypeGroup(target, true)
targetData = targetInfo
else
targetInfo, targetData = self:getFillType(target, true)
end
local unitSetInfo = self:getUnitSet(unitSet, true)
local unitInfo = self:getFillTypeUnit(unit, true)
if targetData ~= nil and unitSetInfo ~= nil and unitInfo ~= nil then
local unitList = targetData.units[unitSetInfo.index]
local unitMapping = targetData.unitMapping[unitSetInfo.index]
if unitMapping[unitInfo.index] == nil then
table.insert(unitList, unitInfo.index)
unitMapping[unitInfo.index] = #unitList
return true
end
if targetIsGroup then
g_thUtils:warningMsg("Unit %q already added to fillType group %q", unitInfo.name, targetInfo.name)
else
g_thUtils:warningMsg("Unit %q already added to fillType %q", unitInfo.name, targetInfo.name)
end
end
return false
end
function THMain:setFillTypeDefaultUnits(target, unitSet, targetIsGroup)
local targetInfo, targetData = nil,nil
local unitSetInfo = nil
if targetIsGroup == true then
targetInfo = self:getFillTypeGroup(target, true)
targetData = targetInfo
else
targetInfo, targetData = self:getFillType(target, true)
end
if unitSet ~= nil then
unitSetInfo = self:getUnitSet(unitSet, true)
if unitSetInfo == nil then
return false
end
end
if targetData ~= nil then
local function setUnitData(pUnitSetInfo)
local vUnitSetId = pUnitSetInfo.id
local vUnitSetIndex = pUnitSetInfo.index
g_thUtils:clearTable(targetData.units[vUnitSetIndex])
g_thUtils:clearTable(targetData.unitMapping[vUnitSetIndex])
if targetIsGroup then
local vGroupId = targetInfo.id
local addMassUnits = vGroupId ~= "ELECTRICITY" and vGroupId ~= "OTHER"
if vGroupId == "ELECTRICITY" then
self:addFillTypeUnit(targetInfo, vUnitSetId, "KILOWATTHOUR", true)
elseif vGroupId == "ANIMAL" or vGroupId == "PIECE" then
self:addFillTypeUnit(targetInfo, vUnitSetId, vGroupId, true)
else
if vUnitSetId == "USCUSTOMARY" then
if vGroupId == "GRAIN" then
self:addFillTypeUnit(targetInfo, vUnitSetId, "BUSHEL", true)
elseif vGroupId == "LIQUID" or vGroupId == "LIQUIDPRODUCT" then
self:addFillTypeUnit(targetInfo, vUnitSetId, "GALLON", true)
elseif vGroupId == "SOLIDPRODUCT" then
self:addFillTypeUnit(targetInfo, vUnitSetId, "PIECE", true)
end
end
end
if #targetData.units[vUnitSetIndex] > 0 then
if addMassUnits then
if vUnitSetId == "USCUSTOMARY" then
self:addFillTypeUnit(targetInfo, vUnitSetId, "POUND", true)
self:addFillTypeUnit(targetInfo, vUnitSetId, "TON", true)
end
end
else
local vVolumeUnitList = self:getDefaultUnitList(vUnitSetId, "VOLUME")
local vWeightUnitList = self:getDefaultUnitList(vUnitSetId, "WEIGHT")
for _, vUnitInfo in ipairs(vVolumeUnitList) do
self:addFillTypeUnit(targetInfo, vUnitSetId, vUnitInfo, true)
end
if addMassUnits then
for _, vUnitInfo in ipairs(vWeightUnitList) do
self:addFillTypeUnit(targetInfo, vUnitSetId, vUnitInfo, true)
end
end
end
end
end
if unitSetInfo == nil then
local unitSetList = self:getUnitSetList()
for idx = 1, #unitSetList do
setUnitData(unitSetList[idx])
end
else
setUnitData(unitSetInfo)
end
return true
end
return false
end
function THMain:getFillTypeDefaultUnits(unitSet, unitType)
local unitSetIndex = self:getTargetOrCurrentUnitSet(unitSet)
local unitList = {}
local unitTypeInfo = nil
if unitType ~= nil then
unitTypeInfo = self:getUnitType(unitType, true)
if unitTypeInfo == nil then
return unitList, 0
end
end
if unitSetIndex ~= nil then
local volumeUnits = self:getDefaultUnitList(unitSetIndex, "VOLUME")
local weightUnits = self:getDefaultUnitList(unitSetIndex, "WEIGHT")
if unitTypeInfo == nil or unitTypeInfo.index == self.UNIT_TYPE.VOLUME then
for _, unitSetInfo in ipairs(volumeUnits) do
table.insert(unitList, unitSetInfo)
end
end
if unitTypeInfo == nil or unitTypeInfo.index == self.UNIT_TYPE.WEIGHT then
for _, unitSetInfo in ipairs(weightUnits) do
table.insert(unitList, unitSetInfo)
end
end
end
return unitList, #unitList
end
function THMain:getFillTypeUnit(unit, verbose, raise)
local unitInfo = self:getUnit(unit, verbose, raise)
if unitInfo ~= nil then
if unitInfo.type ~= self.UNIT_TYPE.VOLUME and unitInfo.type ~= self.UNIT_TYPE.WEIGHT then
unitInfo = nil
end
raise = g_thUtils:getNoNil(raise, verbose)
g_thUtils:msgOnTrue(unitInfo == nil and verbose, raise, THUtils.MSG.ARGUMENT_INVALID, "unit", unit)
return unitInfo
end
end
function THMain:getFillTypeUnitType(unitType, verbose, raise)
local unitTypeInfo = self:getUnitType(unitType, verbose, raise)
if unitTypeInfo then
if unitTypeInfo.index ~= self.UNIT_TYPE.VOLUME and unitTypeInfo.index ~= self.UNIT_TYPE.WEIGHT then
unitTypeInfo = nil
end
raise = g_thUtils:getNoNil(raise, verbose)
g_thUtils:msgOnTrue(unitTypeInfo == nil and verbose, raise, THUtils.MSG.ARGUMENT_INVALID, "unit type", unitType)
return unitTypeInfo
end
end
function THMain:getFillTypeMaxNumUnits(fillTypeList, unitSet, unitType, getCombined)
local unitSetIndex = self:getTargetOrCurrentUnitSet(unitSet)
local unitTypeInfo = nil
local _, maxNumUnits = nil, 0
if unitType ~= nil then
unitTypeInfo = self:getUnitType(unitType, true)
if unitTypeInfo == nil then
return maxNumUnits
end
end
if unitSetIndex ~= nil then
if fillTypeList == nil then
_, maxNumUnits = self:getFillTypeDefaultUnits(unitSetIndex, unitTypeInfo)
else
local listType = type(fillTypeList)
local addedUnits = nil
local function processFillType(pFillType)
local _, vFillTypeData = self:getFillType(pFillType, true)
if vFillTypeData ~= nil and vFillTypeData.group ~= self.FILLTYPE_GROUP.OTHER then
local vUnits = vFillTypeData.units[unitSetIndex]
if #vUnits == 0 then
local vGroupInfo = self:getFillTypeGroup(vFillTypeData.group, true)
vUnits = vGroupInfo.units[unitSetIndex]
end
if #vUnits > 0 then
local vNumUnits = 0
for _, vUnitIndex in pairs(vUnits) do
local vUnitInfo = self:getFillTypeUnit(vUnitIndex, true)
if vUnitInfo ~= nil and (unitTypeInfo == nil or vUnitInfo.type == unitTypeInfo.index) then
if getCombined == true then
addedUnits = g_thUtils:getNoNil(addedUnits, {})
if not addedUnits[vUnitInfo.index] then
addedUnits[vUnitInfo.index] = true
maxNumUnits = maxNumUnits + 1
end
else
vNumUnits = vNumUnits + 1
end
end
end
if not getCombined then
maxNumUnits = math.max(maxNumUnits, vNumUnits)
end
end
end
end
if listType == "string" or listType =="number" or (listType == "table" and fillTypeList.index ~= nil) then
processFillType(fillTypeList)
else
if g_thUtils:getTableIsArray(fillTypeList) then
for _, fillType in ipairs(fillTypeList) do
processFillType(fillType)
end
else
for fillType, isValid in pairs(fillTypeList) do
if isValid == true then
processFillType(fillType)
end
end
end
end
end
end
return maxNumUnits
end
function THMain:getFillTypeUnitList(fillTypeList, unitSet, unitType)
local unitSetIndex = self:getTargetOrCurrentUnitSet(unitSet)
local unitTypeInfo = nil
local unitList = {}
local sharedGroupInfo = nil
if unitType ~= nil then
unitTypeInfo = self:getUnitType(unitType, true)
if unitTypeInfo == nil then
return unitList, 0
end
end
if unitSetIndex ~= nil then
if fillTypeList == nil then
unitList = self:getFillTypeDefaultUnits(unitSetIndex, unitTypeInfo)
else
local listType = type(fillTypeList)
local addedUnits = {}
local weightPos = 0
local function processFillType(pFillType)
local _, vFillTypeData = self:getFillType(pFillType, true)
if vFillTypeData ~= nil and vFillTypeData.group ~= self.FILLTYPE_GROUP.OTHER then
local vGroupInfo = self:getFillTypeGroup(vFillTypeData.group, true)
local vUnits = vFillTypeData.units[unitSetIndex]
if sharedGroupInfo == nil then
sharedGroupInfo = vGroupInfo
elseif sharedGroupInfo ~= vGroupInfo then
sharedGroupInfo = false
end
if #vUnits == 0 then
if vGroupInfo ~= nil then
vUnits = vGroupInfo.units[unitSetIndex]
end
end
for _, vUnitIndex in ipairs(vUnits) do
local vUnitInfo = self:getFillTypeUnit(vUnitIndex, true)
if vUnitInfo ~= nil and (unitTypeInfo == nil or vUnitInfo.type == unitTypeInfo.index) then
if not addedUnits[vUnitInfo.index] then
if vUnitInfo.type == self.UNIT_TYPE.VOLUME then
if weightPos == 0 then
table.insert(unitList, vUnitInfo)
else
table.insert(unitList, weightPos, vUnitInfo)
end
else
table.insert(unitList, vUnitInfo)
if weightPos == 0 then
weightPos = #unitList
end
end
addedUnits[vUnitInfo.index] = true
end
end
end
end
end
if listType == "number" or listType == "string" or (listType == "table" and fillTypeList.index ~= nil) then
processFillType(fillTypeList)
else
if g_thUtils:getTableIsArray(fillTypeList) then
for _, fillType in ipairs(fillTypeList) do
processFillType(fillType)
end
else
for fillType, isValid in pairs(fillTypeList) do
if isValid == true then
processFillType(fillType)
end
end
end
end
end
end
return unitList, #unitList, sharedGroupInfo
end
function THMain:getFillTypeUnitData(fillTypeList, index, maxIndex, unitSet, unitType)
local fillTypeInfo, fillTypeData, maxFillTypeMass = self:getHeaviestFillType(fillTypeList)
local unitList, maxNumUnits = self:getFillTypeUnitList(fillTypeList, unitSet, unitType)
if fillTypeData ~= nil and maxNumUnits > 0 then
local listType = type(fillTypeList)
if listType == "string" or listType == "number" or fillTypeList == fillTypeInfo then
index = g_thUtils:getNoNil(index, fillTypeData.currentUnit)
else
index = g_thUtils:getNoNil(index, 1)
end
maxIndex = g_thUtils:getNoNil(maxIndex, maxNumUnits)
if maxIndex > maxNumUnits then
index = index - (maxIndex - maxNumUnits)
end
index = MathUtil.clamp(index, 1, maxNumUnits)
local unitInfo = unitList[index]
if unitInfo ~= nil then
local factor = unitInfo.factor
if unitInfo.type == self.UNIT_TYPE.WEIGHT then
factor = factor * maxFillTypeMass
end
return unitInfo, factor, unitInfo.precision, index, maxNumUnits, maxFillTypeMass
end
end
return nil,1,0,0,0,0
end
THBaseMission = {}
function THBaseMission:hook_loadMapFinished(superFunc, ...)
local function appendFunc(...)
local protectedChunk = function()
if not self.cancelLoading then
g_thMain:loadConfiguration("units", THMain.xmlSchema)
g_thMain:finalizeUnits()
if g_thMain:initializeFillTypes() then
g_thMain:loadConfiguration("fillTypes", THMain.xmlSchema)
g_thMain:finalizeFillTypes()
end
for _, fillUnitInfo in pairs(FillUnit.UNIT) do
local fillUnitData = g_thMain:getDataTable(fillUnitInfo)
if fillUnitData == nil then
fillUnitData = g_thMain:createDataTable(fillUnitInfo)
local defaultConversionFunc = fillUnitData:getDefaultValue("conversionFunc")
if defaultConversionFunc ~= nil then
fillUnitInfo.conversionFunc = function(pValue, ...)
local function vAppendFunc(pRetValue, ...)
if pRetValue ~= nil and pRetValue > 0 then
pRetValue = pValue
end
return pRetValue, ...
end
return vAppendFunc(defaultConversionFunc(pValue, ...))
end
end
end
end
local storeManagerData = g_thMain:getDataTable(g_storeManager, true, THStoreManager)
storeManagerData:initializeStoreItems()
if g_thMain:initializeSettings() then
g_thMain:loadSettings()
end
end
end
g_thMain:call(protectedChunk)
return ...
end
return appendFunc(superFunc(self, ...))
end
THFillTypeManager = {}
function THFillTypeManager:hook_loadFillTypes(superFunc, xmlFile, baseDirectory, isBaseType, customEnv, ...)
local function appendFunc(success, ...)
if success == true then
local protectedChunk = function()
local allowUpdate = g_thUtils:getNoNil(customEnv, "") ~= ""
if allowUpdate then
local xmlFileId = nil
if type(xmlFile) == "table" and xmlFile.handle ~= nil then
xmlFileId = xmlFile.handle
elseif type(xmlFile) == "number" then
xmlFileId = xmlFile
end
if xmlFileId ~= nil then
if g_thMain:initializeFillTypes() then
local idx = 0
while true do
local fillTypeKey = string.format("map.fillTypes.fillType(%d)", idx)
if not hasXMLProperty(xmlFileId, fillTypeKey) then
break
end
local fillTypeName = getXMLString(xmlFileId, fillTypeKey.."#name")
local fillTypeInfo, fillTypeData = g_thMain:getFillType(fillTypeName)
if fillTypeData ~= nil then
if fillTypeData.customEnv == customEnv
or (g_thMain.mapIsMod and customEnv == g_thMain.mapName)
then
local groupName = getXMLString(xmlFileId, fillTypeKey..".unitConvert#group")
local displayMass = getXMLFloat(xmlFileId, fillTypeKey..".unitConvert#displayMass")
if groupName ~= nil then
local groupInfo = g_thMain:getFillTypeGroup(groupName, true, false)
if groupInfo ~= nil then
g_thMain:setFillTypeGroup(fillTypeInfo, groupInfo)
end
end
if displayMass ~= nil and displayMass > 0 then
fillTypeData.displayMass = displayMass
end
end
end
idx = idx + 1
end
end
end
end
end
g_thMain:call(protectedChunk)
end
return success, ...
end
return appendFunc(superFunc(self, xmlFile, baseDirectory, isBaseType, customEnv, ...))
end
function THFillTypeManager:hook_addFillType(superFunc, name, title, showOnPriceTable, pricePerLiter, massPerLiter, maxPhysicalSurfaceAngle, hudOverlayFilename, baseDirectory, customEnv, ...)
local fillTypeIsNew = true
local function prependFunc()
if type(name) == "string" then
if self.nameToFillType[name:upper()] ~= nil then
fillTypeIsNew = false
end
end
end
g_thMain:call(prependFunc)
local function appendFunc(fillTypeDesc, ...)
local protectedChunk = function()
if fillTypeDesc ~= nil then
local fillTypeData = g_thMain:getDataTable(fillTypeDesc, true)
if fillTypeIsNew and g_thUtils:getNoNil(customEnv, "") ~= "" then
fillTypeData.customEnv = customEnv
end
end
end
g_thMain:call(protectedChunk)
return fillTypeDesc, ...
end
return appendFunc(superFunc(self, name, title, showOnPriceTable, pricePerLiter, massPerLiter, maxPhysicalSurfaceAngle, hudOverlayFilename, baseDirectory, customEnv, ...))
end
THTypeManager = {}
function THTypeManager:hook_finalizeTypes(superFunc, ...)
local function prependFunc()
local typeList = self:getTypes()
local specList = g_thMain:getSpecializationsByType(self.typeName)
for typeName, typeEntry in pairs(typeList) do
for _, specInfo in ipairs(specList) do
local internalSpecName = specInfo.entry.name
local parentName = specInfo.parentName
local specClass = specInfo.class
if parentName == nil or typeEntry.specializationsByName[parentName] ~= nil then
if  typeEntry.specializationsByName[internalSpecName] == nil
and specClass.prerequisitesPresent(typeEntry.specializations)
then
self:addSpecialization(typeName, internalSpecName)
end
end
end
end
end
g_thMain:call(prependFunc)
return superFunc(self, ...)
end
g_thMain = THMain:new("thUnitConvert")
if g_thMain ~= nil then
local function runScript()
local globalEnv = g_thUtils:getGlobalEnv()
local modName = g_thMain.modName
local modPath = g_thMain.modPath
local dataKey = g_thMain.dataKey
g_xmlManager:addCreateSchemaFunction(function()
THMain.xmlSchema = XMLSchema.new(dataKey)
end)
g_xmlManager:addInitSchemaFunction(function()
THMain.initializeXMLSchema()
end)
g_thMain:initializeLoadedMods()
g_thMain:initializeUnits()
g_thMain:initializeFillTypeGroups()
g_thMain:setProtectedHook("BaseMission", "loadMapFinished", THBaseMission)
g_thMain:setProtectedHook("FillTypeManager", "loadFillTypes", THFillTypeManager)
g_thMain:setProtectedHook("FillTypeManager", "addFillType",   THFillTypeManager)
g_thMain:setProtectedHook("TypeManager", "finalizeTypes", THTypeManager)
source(modPath.."scripts/misc/I18N.lua")
source(modPath.."scripts/objects/LoadingStation.lua")
source(modPath.."scripts/objects/ProductionPoint.lua")
source(modPath.."scripts/objects/BunkerSilo.lua")
source(modPath.."scripts/objects/Bale.lua")
source(modPath.."scripts/vehicles/Vehicle.lua")
source(modPath.."scripts/farms/FarmStats.lua")
source(modPath.."scripts/gui/Gui.lua")
source(modPath.."scripts/gui/InGameMenuPricesFrame.lua")
source(modPath.."scripts/gui/InGameMenuProductionFrame.lua")
source(modPath.."scripts/gui/InGameMenuStatisticsFrame.lua")
source(modPath.."scripts/gui/InGameMenuGeneralSettingsFrame.lua")
source(modPath.."scripts/shop/StoreManager.lua")
source(modPath.."scripts/shop/ShopController.lua")
source(modPath.."scripts/shop/ShopItemsFrame.lua")
source(modPath.."scripts/shop/ShopConfigScreen.lua")
source(modPath.."scripts/shop/ConstructionScreen.lua")
source(modPath.."scripts/gui/hud/FillLevelsDisplay.lua")
source(modPath.."scripts/gui/dialogs/SiloDialog.lua")
g_thMain:addSpecialization("vehicle", "ucFillUnit", "THFillUnit", "fillUnit", "scripts/vehicles/specializations/FillUnit.lua")
g_thMain:addSpecialization("placeable", "ucPlaceableSilo",          "THPlaceableSilo",          "silo",          "scripts/placeables/specializations/PlaceableSilo.lua")
g_thMain:addSpecialization("placeable", "ucPlaceableSiloExtension", "THPlaceableSiloExtension", "siloExtension", "scripts/placeables/specializations/PlaceableSiloExtension.lua")
globalEnv.THUnitConvert = THMain
globalEnv.g_thUnitConvert = g_thMain
end
g_thMain:call(runScript)
end