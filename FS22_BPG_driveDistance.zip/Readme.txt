FS22 BPG driveDistance Script

Script by Blacky_BPG
Convert FS22: Ifko[nator]


Mit diesem Script seht Ihr unten rechts Euren Tageskilometer sowie die gesamt gefahrenen Kilometer. Der Tageskilometer wird bei jedem Neustart des Spiels zurück gesetzt.

Desweiteren kann man sich das auch auf dem Display anzeigen lassen ( XML Erfahrung vorrausgesetzt )


XML Fahrzeug:

<motorized>
	...
	...
	...

	<dashboards>
		<dashboard displayType="TEXT" valueType="distanceTrip"  node="numbersTrip"     textColor="SHARED_BLACK1" textSize="0.007" textMask="0000.00" font="DIGIT_BOLD" groups="MOTOR_ACTIVE"/>
		<dashboard displayType="TEXT" valueType="distanceTotal" node="numbersDistance" textColor="SHARED_BLACK1" textSize="0.007" textMask="000000"  font="DIGIT_BOLD" groups="MOTOR_ACTIVE"/>
	</dashboards>
</motorized>

<i3dMapping>
	<i3dMapping id="numbersTrip" node="INDEX_IM_GE" />
	<i3dMapping id="numbersDistance" node="INDEX_IM_GE" />
</i3dMapping>


Und nun wünschen wir Euch viel Spass beim Kilometerrobben

MfG
RepiGaming, Blacky_BPG und Ifko[nator]