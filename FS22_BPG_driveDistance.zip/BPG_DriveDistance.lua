-- 
-- Drive distance for vehicles for FS17
-- by Blacky_BPG
-- 
-- Version: 2.0.0.1      |    01.07.2022    fix HUD-position for scaled HUDs
-- Version: 2.0.0.0      |    18.11.2021    initial version for FS22
-- Version: 1.9.0.4      |    01.12.2019    add variance for trip distance display, reset trip distance after day change
-- Version: 1.9.0.3      |    25.11.2019    add dashboard functionality, fix display calculation
-- Version: 1.9.0.2      |    23.11.2019    correct display for total distance in use with TSX EnhancedVehicle mod, remove decimal for total distance, colorize decimal for trip distance
-- Version: 1.9.0.1      |    11.11.2019    initial version for FS19
-- Version: 1.5.3.1      |    28.03.2018    fixed override function for GUI element 
-- Version: 1.4.4.0 D    |    15.03.2017    fixed multiplayer functionality
-- Version: 1.4.4.0 C    |    13.03.2017    fixed multiplayer functionality
-- Version: 1.4.4.0 B    |    12.03.2017    fixed savegame detection
-- Version: 1.4.4.0 A    |    12.03.2017    fixed variable error
-- Version: 1.4.4.0      |    09.03.2017    initial Version for FS17
-- 


BPG_DriveDistance = {}
BPG_DriveDistance.modDir = g_currentModDirectory
BPG_DriveDistance.tripXVariance = 0		-- Tageskilometeranzeige horizontale Verschiebung in Prozent, positiv nach rechts, negativ nach links

function BPG_DriveDistance.initSpecialization()
	local schemaSavegame = Vehicle.xmlSchemaSavegame;

	schemaSavegame:register(XMLValueType.FLOAT, "vehicles.vehicle(?).BPG_DriveDistance#drivenDistance", "Driven distance.", 0);
	schemaSavegame:register(XMLValueType.FLOAT, "vehicles.vehicle(?).BPG_DriveDistance#driveDistanceToday", "Driven distance  today.", 0);
end;

function BPG_DriveDistance.prerequisitesPresent(specializations)
    return SpecializationUtil.hasSpecialization(Motorized, specializations)
end

function BPG_DriveDistance.registerFunctions(vehicleType)
	SpecializationUtil.registerFunction(vehicleType, "add_DriveDistance", BPG_DriveDistance.add_DriveDistance)
	SpecializationUtil.registerFunction(vehicleType, "resetDirvenDistance", BPG_DriveDistance.resetDirvenDistance)
end

function BPG_DriveDistance.registerEventListeners(vehicleType)
	local specFunctions = {"onPostLoad", "onLoad", "onUpdate", "onUpdateTick", "onDraw", "onReadStream", "onWriteStream", "onReadUpdateStream", "onWriteUpdateStream", "onRegisterActionEvents"}
	
	for _, specFunction in ipairs(specFunctions) do
		SpecializationUtil.registerEventListener(vehicleType, specFunction, BPG_DriveDistance)
	end
end

function BPG_DriveDistance:onPostLoad(savegame)
	local spec = self.spec_BPG_DriveDistance
	spec.textSizeS = g_currentMission.inGameMenu.hud.speedMeter.speedUnitTextSize*0.70
	spec.textSizeL = g_currentMission.inGameMenu.hud.speedMeter.speedUnitTextSize*0.85
	spec.textWidth = getTextWidth(spec.textSizeS, "l")

	if savegame ~= nil then
		spec.driveDistanceOverall = savegame.xmlFile:getValue(savegame.key .. ".BPG_DriveDistance#drivenDistance", 0);
		spec.driveDistanceToday = savegame.xmlFile:getValue(savegame.key .. ".BPG_DriveDistance#driveDistanceToday", 0);
	else
		spec.driveDistanceOverall = 0;
		spec.driveDistanceToday = 0;
	end;

	self:add_DriveDistance(0, spec.driveDistanceOverall)
end

function BPG_DriveDistance:onLoad(savegame)
	local spec = self.spec_BPG_DriveDistance
	if g_gameSettings:getValue("useMiles") == true then
		spec.distanceText = "mi"
		spec.distanceFactor = "62.1371192237334"
	else
		spec.distanceText = "km"
		spec.distanceFactor = "100"
	end
	spec.driveDistanceToday = 0
	spec.driveDistanceOverall = 0
	spec.show_driveDistanceToday = 0
	spec.show_driveDistanceOverall = 0
	spec.lastDay = 1

	if self.loadDashboardsFromXML ~= nil then
		self:loadDashboardsFromXML(self.xmlFile, "vehicle.motorized.dashboards", {valueTypeToLoad = "distanceTotal", valueObject = spec, valueFunc = "show_driveDistanceOverall"})
		self:loadDashboardsFromXML(self.xmlFile, "vehicle.motorized.dashboards", {valueTypeToLoad = "distanceTrip", valueObject = spec, valueFunc = "show_driveDistanceToday"})
	end

	spec.sendTimer = 0
end

function BPG_DriveDistance:onRegisterActionEvents(isActiveForInput)
	if self.isClient then
        local spec = self.spec_BPG_DriveDistance
        
		self:clearActionEventsTable(spec.actionEvents);
        
		if self:getIsActiveForInput(true, false) then
			local _, actionEventId = self:addActionEvent(spec.actionEvents, InputAction.RESET_DRIVE_DISTANCE_DAY_BUTTON, self, BPG_DriveDistance.actionEventResetDriveDistanceDay, false, true, false, true, nil);

			g_inputBinding:setActionEventTextPriority(actionEventId, GS_PRIO_HIGH);
			g_inputBinding:setActionEventTextVisibility(actionEventId, spec.driveDistanceToday > 0);
			g_inputBinding:setActionEventActive(actionEventId, spec.driveDistanceToday > 0);
		end;
	end;
end;

function BPG_DriveDistance.actionEventResetDriveDistanceDay(self, actionName, inputValue, callbackState, isAnalog)
	local spec = self.spec_BPG_DriveDistance

	self:resetDirvenDistance(0);
end;

function BPG_DriveDistance:resetDirvenDistance(driveDistanceToday, noEventSend)
	local spec = self.spec_BPG_DriveDistance
	
	if driveDistanceToday ~= spec.driveDistanceToday then
		if not noEventSend then
			if g_server ~= nil then
				g_server:broadcastEvent(BPG_DriveDistanceTodayEvent.new(self), nil, nil, self);
			else
				g_client:getServerConnection():sendEvent(BPG_DriveDistanceTodayEvent.new(self));
			end;
		end;
		
		spec.driveDistanceToday = 0;

		self:add_DriveDistance(0,spec.driveDistanceOverall)
	end;
end;

function BPG_DriveDistance:saveToXMLFile(xmlFile, key)
	local spec = self.spec_BPG_DriveDistance
	xmlFile:setValue(key .. "#drivenDistance", spec.driveDistanceOverall);
	xmlFile:setValue(key .. "#driveDistanceToday", spec.driveDistanceToday);
end

function BPG_DriveDistance:onReadStream(streamId, connection)
	local spec = self.spec_BPG_DriveDistance
	spec.driveDistanceToday = streamReadFloat32(streamId)
	spec.driveDistanceOverall = streamReadFloat32(streamId)
	self:add_DriveDistance(spec.driveDistanceToday,spec.driveDistanceOverall)
end

function BPG_DriveDistance:onWriteStream(streamId, connection)
	local spec = self.spec_BPG_DriveDistance
	streamWriteFloat32(streamId, spec.driveDistanceToday)
	streamWriteFloat32(streamId, spec.driveDistanceOverall)
end

function BPG_DriveDistance:onReadUpdateStream(streamId, timestamp, connection)
	if connection.isServer then
		local spec = self.spec_BPG_DriveDistance
		spec.driveDistanceToday = streamReadFloat32(streamId)
		spec.driveDistanceOverall = streamReadFloat32(streamId)
		self:add_DriveDistance(spec.driveDistanceToday,spec.driveDistanceOverall)
	end
end

function BPG_DriveDistance:onWriteUpdateStream(streamId, connection, dirtyMask)
	if not connection.isServer then
		local spec = self.spec_BPG_DriveDistance
		streamWriteFloat32(streamId, spec.driveDistanceToday)
		streamWriteFloat32(streamId, spec.driveDistanceOverall)
	end
end


function BPG_DriveDistance:onUpdate(dt, isActiveForInput, isActiveForInputIgnoreSelection, isSelected)
	local spec = self.spec_BPG_DriveDistance
	if self:getIsActive() or self:getIsAIActive() then
		local lmD = Utils.getNoNil(self.lastMovedDistance,0)*0.001
		spec.driveDistanceToday = spec.driveDistanceToday + lmD
		spec.driveDistanceOverall = spec.driveDistanceOverall + lmD
		if self:getIsAIActive() then
			if self.lastMovedDistance > 0 then
				g_currentMission:farmStats(self:getOwnerFarmId()):updateStats("traveledDistance", lmD)
			end
		end
	end
end

function BPG_DriveDistance:onUpdateTick(dt, isActiveForInput, isActiveForInputIgnoreSelection, isSelected)
	local spec = self.spec_BPG_DriveDistance
	if self.isServer then
		if g_currentMission.environment.currentDay > spec.lastDay then
			spec.lastDay = g_currentMission.environment.currentDay
			spec.driveDistanceToday = 0
		end
	end
	if self:getIsActive() or self:getIsAIActive() then
		if self.lastMovedDistance ~= nil and self.lastMovedDistance > 0 then
			self:add_DriveDistance(spec.driveDistanceToday, spec.driveDistanceOverall)
		end
	end
	spec.show_driveDistanceToday = math.modf(spec.driveDistanceToday*spec.distanceFactor)/100
	spec.show_driveDistanceOverall = math.modf(spec.driveDistanceOverall*spec.distanceFactor)/100
end

function BPG_DriveDistance:onDraw(isActiveForInput, isActiveForInputIgnoreSelection, isSelected)
	local spec = self.spec_BPG_DriveDistance
	if self.spec_enterable.isEntered then
		local offsetX = g_currentMission.inGameMenu.hud.speedMeter.gaugeCenterX
		local totalOffsetY = g_currentMission.inGameMenu.hud.speedMeter.origY + g_currentMission.inGameMenu.hud.speedMeter.speedTextOffsetY + (g_currentMission.inGameMenu.hud.speedMeter.speedTextSize/1.2)
		local totalOffsetY2 = g_currentMission.inGameMenu.hud.speedMeter.origY + g_currentMission.inGameMenu.hud.speedMeter.speedTextOffsetY - (g_currentMission.inGameMenu.hud.speedMeter.speedTextSize*1.4)

		local tripFront = math.modf(spec.show_driveDistanceToday)
		local tripBack = math.modf((spec.show_driveDistanceToday-tripFront)*100)
		if tripBack < 0 then tripBack = "00" elseif tripBack < 10 then tripBack = "0"..tripBack end
		tripFront = "Trip "..tostring(tripFront).."."
		tripBack = tripBack.." "..spec.distanceText
		local tripWidth = getTextWidth(spec.textSizeL, tripFront..tripBack) / 2
		local tripVariance = getTextWidth(spec.textSizeL, tripFront..tripBack)*(BPG_DriveDistance.tripXVariance/100)

		setTextAlignment(RenderText.ALIGN_LEFT)
		renderText(offsetX-tripWidth+tripVariance,totalOffsetY2,spec.textSizeL,tripFront)

		setTextAlignment(RenderText.ALIGN_RIGHT)
		setTextColor(0.9,0.35,0.35,1)
		renderText(offsetX+tripWidth+tripVariance,totalOffsetY2,spec.textSizeL,tripBack)

		setTextColor(1,1,1,1)
		renderText(offsetX+tripWidth+tripVariance,totalOffsetY2,spec.textSizeL,spec.distanceText)

		setTextBold(true)
		setTextAlignment(RenderText.ALIGN_CENTER)
		if g_modIsLoaded.TSX_EnhancedVehicle ~= nil then
			renderText(offsetX+spec.textWidth,totalOffsetY,spec.textSizeS,string.format("%.0f", tostring(math.modf(spec.show_driveDistanceOverall))).." "..spec.distanceText)
		else
			renderText(offsetX,totalOffsetY,spec.textSizeL,string.format("%.0f", tostring(math.modf(spec.show_driveDistanceOverall))).." "..spec.distanceText)
		end

		setTextBold(false)
	end
end

function BPG_DriveDistance:add_DriveDistance(today, overall, noEventSend)
	local spec = self.spec_BPG_DriveDistance
	if today == nil then today = spec.driveDistanceToday end
	if overall == nil then overall = spec.driveDistanceOverall end
	if spec.sendTimer == 0 then
		spec.sendTimer = math.random(115,130)
		BPG_DriveDistanceEvent.sendEvent(self, today, overall, noEventSend)
	else
		spec.sendTimer = spec.sendTimer - 1
	end
end

-----------------------------------------------------------------------

BPG_DriveDistanceEvent = {}
BPG_DriveDistanceEvent_mt = Class(BPG_DriveDistanceEvent, Event)

InitEventClass(BPG_DriveDistanceEvent, "BPG_DriveDistanceEvent")

function BPG_DriveDistanceEvent.emptyNew()
    local self = Event.new(BPG_DriveDistanceEvent_mt)
    self.className="BPG_DriveDistanceEvent"
    return self
end

function BPG_DriveDistanceEvent.new(vehicle, today, overall)
	local self = BPG_DriveDistanceEvent.emptyNew()
	self.vehicle = vehicle
	self.today = today
	self.overall = overall
	return self
end

function BPG_DriveDistanceEvent:readStream(streamId, connection)
	self.vehicle = NetworkUtil.readNodeObject(streamId)
	self.today = streamReadFloat32(streamId)
	self.overall = streamReadFloat32(streamId)
	self:run(connection)
end

function BPG_DriveDistanceEvent:writeStream(streamId, connection)
	NetworkUtil.writeNodeObject(streamId, self.vehicle)
	streamWriteFloat32(streamId, self.today)
	streamWriteFloat32(streamId, self.overall)
end

function BPG_DriveDistanceEvent:run(connection)
	if self.vehicle ~= nil then
		if self.vehicle.add_DriveDistance ~= nil then
			self.vehicle:add_DriveDistance(self.today, self.overall, true)
		end
		if not connection:getIsServer() then
			g_server:broadcastEvent(BPG_DriveDistanceEvent.new(self.vehicle, self.today, self.overall), nil, connection, self.vehicle)
		end
	end
end

function BPG_DriveDistanceEvent.sendEvent(vehicle, today, overall, noEventSend)
	if noEventSend == nil or noEventSend == false then
		if g_server ~= nil then
			g_server:broadcastEvent(BPG_DriveDistanceEvent.new(vehicle, today, overall), nil, nil, vehicle)
		else
			g_client:getServerConnection():sendEvent(BPG_DriveDistanceEvent.new(vehicle, today, overall))
		end
	end
end

BPG_DriveDistanceTodayEvent = {};
BPG_DriveDistanceTodayEvent_mt = Class(BPG_DriveDistanceTodayEvent, Event);

InitEventClass(BPG_DriveDistanceTodayEvent, "BPG_DriveDistanceTodayEvent");

function BPG_DriveDistanceTodayEvent.emptyNew()
	local self = Event.new(BPG_DriveDistanceTodayEvent_mt);
    
	return self;
end;

function BPG_DriveDistanceTodayEvent.new(vehicle)
	local self = BPG_DriveDistanceTodayEvent.emptyNew();
	
	self.vehicle = vehicle;
	
	return self;
end;

function BPG_DriveDistanceTodayEvent:readStream(streamId, connection)
	self.vehicle = NetworkUtil.readNodeObject(streamId);
	
	self:run(connection);
end;

function BPG_DriveDistanceTodayEvent:writeStream(streamId, connection)
	NetworkUtil.writeNodeObject(streamId, self.vehicle);
end;

function BPG_DriveDistanceTodayEvent:run(connection)
	if not connection:getIsServer() then
		g_server:broadcastEvent(BPG_DriveDistanceTodayEvent.new(self.vehicle), nil, connection, self.vehicle);
	end;
	
    if self.vehicle ~= nil then
        self.vehicle:resetDirvenDistance(0, true);
	end;
end;