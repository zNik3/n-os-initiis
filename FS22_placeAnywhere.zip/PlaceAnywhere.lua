--[[
	PlaceAnywhere.lua
	
	Author: 	Ifko[nator]
	Date:		26.11.2021
	Version:	1.0 
	
	History:	v1.0 @26.11.2021 - initial implementation in FS 22
]]

PlaceAnywhere = {};

function PlaceAnywhere:getHasOverlap(superFunc, x, y, z, rotY, checkFunc)
	return false;
end;

function PlaceAnywhere:getHasOverlapWithPlaces(superFunc, zones, x, y, z, rotY)
	return false;
end;

function PlaceAnywhere:getHasOverlapWithZones(superFunc, zones, x, y, z, rotY)
	return false;
end;

PlaceablePlacement.getHasOverlap = Utils.overwrittenFunction(PlaceablePlacement.getHasOverlap, PlaceAnywhere.getHasOverlap);
PlaceablePlacement.getHasOverlapWithPlaces = Utils.overwrittenFunction(PlaceablePlacement.getHasOverlapWithPlaces, PlaceAnywhere.getHasOverlapWithPlaces);
PlaceablePlacement.getHasOverlapWithZones = Utils.overwrittenFunction(PlaceablePlacement.getHasOverlapWithZones, PlaceAnywhere.getHasOverlapWithZones);